"""
03_build_styled_docx.py
=======================
Converts the publication Markdown manuscript into a Nature-style Word (.docx)
document enforcing all SKILL.md GLOBAL DOCUMENT STYLE rules:
  - US Letter (8.5 x 11 in), single column, 2.54 cm (1.0 in) margins
  - Times New Roman, 12 pt black body text, left-aligned, double-spaced, no first-line indent
  - 16 pt bold title, centered author line with superscript affiliations, 9.5 pt affiliations, 10 pt correspondence
  - Abstract (10.5 pt, single paragraph, double-spaced) and Keywords (10 pt)
  - Unnumbered bold Level-1 (13 pt) and Level-2 (12 pt) headings
  - Top-right PAGE numbers and continuous left-margin line numbers (OOXML w:lnNumType)
  - Editable centered equations with flush-right sequential numbering (1)-(12)
  - Native three-line academic Word tables and embedded 600 DPI PNG figures
  - Nature/Vancouver superscript inline citations [1] and 9.5 pt Reference list

Author: Orchestrator Argon Pipeline (paper40)
"""

import os
import re
import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn, nsdecls

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
MD_PATH = os.path.join(BASE_DIR, "Manuscript_MesoMacro_qEEG_ASD_NatureStyle.md")
DOCX_PATH = os.path.join(BASE_DIR, "Manuscript_MesoMacro_qEEG_ASD_NatureStyle.docx")
FIG_DIR = os.path.join(BASE_DIR, "Figures")

BLACK = RGBColor(0, 0, 0)
FONT_NAME = "Times New Roman"


def set_run_font(run, size_pt=12, bold=False, italic=False, superscript=False, subscript=False):
    run.font.name = FONT_NAME
    rPr = run._r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), FONT_NAME)
    rFonts.set(qn("w:hAnsi"), FONT_NAME)
    rFonts.set(qn("w:cs"), FONT_NAME)
    run.font.size = Pt(size_pt)
    run.font.color.rgb = BLACK
    run.bold = bold
    run.italic = italic
    run.font.superscript = superscript
    run.font.subscript = subscript


def add_page_number_header(section):
    header = section.header
    p = header.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r1 = p.add_run("")
    set_run_font(r1, size_pt=10)
    fldChar1 = parse_xml(r'<w:fldChar %s w:fldCharType="begin"/>' % nsdecls("w"))
    instrText = parse_xml(r'<w:instrText %s xml:space="preserve"> PAGE </w:instrText>' % nsdecls("w"))
    fldChar2 = parse_xml(r'<w:fldChar %s w:fldCharType="separate"/>' % nsdecls("w"))
    fldChar3 = parse_xml(r'<w:fldChar %s w:fldCharType="end"/>' % nsdecls("w"))
    r1._r.append(fldChar1)
    r1._r.append(instrText)
    r1._r.append(fldChar2)
    r1._r.append(fldChar3)


def enable_continuous_line_numbers(section):
    sectPr = section._sectPr
    # Remove any existing lnNumType
    for old in sectPr.findall(qn("w:lnNumType")):
        sectPr.remove(old)
    ln = OxmlElement("w:lnNumType")
    ln.set(qn("w:countBy"), "1")
    ln.set(qn("w:restart"), "continuous")
    # Insert strictly after pgMar if present (ISO OOXML CT_SectPr element order)
    pgMar = sectPr.find(qn("w:pgMar"))
    if pgMar is not None:
        idx = list(sectPr).index(pgMar)
        sectPr.insert(idx + 1, ln)
    else:
        sectPr.append(ln)


# Regex matching inline markdown styling, sup/sub tags, and Nature citation brackets [1], [1,2], [1-3]
INLINE_TOKEN_RE = re.compile(
    r"(\*\*[^*]+\*\*)"           # **bold**
    r"|(\*[^*]+\*)"                # *italic*
    r"|(\^[^^]+\^)"                # ^sup^
    r"|(~[^~]+~)"                  # ~sub~
    r"|(`[^`]+`)"                  # `code`
    r"|(\[\d+(?:[,\-–\s]+\d+)*\])" # [1], [1,2], [1–3] (never matches CIs like [0.1, 0.2]!)
)


def add_formatted_runs(p, text, size_pt=12, base_bold=False, base_italic=False, base_sup=False, base_sub=False):
    # Convert inline LaTeX math ($...$) before tokenizing markdown styles
    if "$" in text and not text.strip().startswith("$$"):
        text = re.sub(r"\$([^$\n]+)\$", lambda m: clean_latex_to_math_text(m.group(1)), text)
    pos = 0
    for m in INLINE_TOKEN_RE.finditer(text):
        if m.start() > pos:
            r = p.add_run(text[pos:m.start()])
            set_run_font(r, size_pt=size_pt, bold=base_bold, italic=base_italic, superscript=base_sup, subscript=base_sub)
        tok = m.group(0)
        if tok.startswith("**") and tok.endswith("**"):
            add_formatted_runs(p, tok[2:-2], size_pt=size_pt, base_bold=True, base_italic=base_italic, base_sup=base_sup, base_sub=base_sub)
        elif tok.startswith("*") and tok.endswith("*"):
            add_formatted_runs(p, tok[1:-1], size_pt=size_pt, base_bold=base_bold, base_italic=True, base_sup=base_sup, base_sub=base_sub)
        elif tok.startswith("^") and tok.endswith("^"):
            add_formatted_runs(p, tok[1:-1], size_pt=size_pt, base_bold=base_bold, base_italic=base_italic, base_sup=True, base_sub=base_sub)
        elif tok.startswith("~") and tok.endswith("~"):
            add_formatted_runs(p, tok[1:-1], size_pt=size_pt, base_bold=base_bold, base_italic=base_italic, base_sup=base_sup, base_sub=True)
        elif tok.startswith("`") and tok.endswith("`"):
            r = p.add_run(tok[1:-1])
            set_run_font(r, size_pt=size_pt, bold=base_bold, italic=base_italic, superscript=base_sup, subscript=base_sub)
        elif tok.startswith("[") and tok.endswith("]"):
            # Superscript Nature citation digits
            cite_nums = tok[1:-1].strip()
            r = p.add_run(cite_nums)
            set_run_font(r, size_pt=size_pt, bold=base_bold, italic=base_italic, superscript=True)
        pos = m.end()
    if pos < len(text):
        r = p.add_run(text[pos:])
        set_run_font(r, size_pt=size_pt, bold=base_bold, italic=base_italic, superscript=base_sup, subscript=base_sub)


def _extract_balanced(s, start_idx):
    """Extract content inside {...} starting at '{' at start_idx, returning (inner, end_idx)."""
    if start_idx >= len(s) or s[start_idx] != "{":
        return None, start_idx
    depth = 0
    for idx in range(start_idx, len(s)):
        if s[idx] == "{":
            depth += 1
        elif s[idx] == "}":
            depth -= 1
            if depth == 0:
                return s[start_idx + 1:idx], idx + 1
    return None, start_idx


def _replace_brace_command(s, cmd, n_args, repl_fn):
    """Repeatedly replace nested brace LaTeX commands like \\frac{a}{b} or \\sqrt{a} cleanly."""
    token = "\\" + cmd
    out = s
    changed = True
    while changed:
        changed = False
        idx = out.find(token)
        while idx != -1:
            after = idx + len(token)
            # Ensure whole command name matched
            if after < len(out) and out[after].isalpha():
                idx = out.find(token, after)
                continue
            pos = after
            while pos < len(out) and out[pos] == " ":
                pos += 1
            args = []
            ok = True
            for _ in range(n_args):
                while pos < len(out) and out[pos] == " ":
                    pos += 1
                arg, pos = _extract_balanced(out, pos)
                if arg is None:
                    ok = False
                    break
                args.append(arg)
            if ok:
                rep = repl_fn(*args)
                out = out[:idx] + rep + out[pos:]
                changed = True
                break
            idx = out.find(token, after)
    return out


def clean_latex_to_math_text(tex):
    """Convert display or inline LaTeX math string into clean editable Unicode + ^sup^/~sub~ markers."""
    s = tex.strip()
    s = re.sub(r"\\begin\{equation\*?\}|\\end\{equation\*?\}", "", s)
    s = re.sub(r"\\tag\{[^}]+\}", "", s)
    s = re.sub(r"\\quad|\\qquad", "   ", s)
    s = re.sub(r"\\left\s*([\(\[\{\|])", r"\1", s)
    s = re.sub(r"\\right\s*([\)\]\}\|])", r"\1", s)
    s = re.sub(r"\\left\s*\\\|", "‖", s)
    s = re.sub(r"\\right\s*\\\|", "‖", s)
    s = re.sub(r"\\[bB]igg?[lr]?\s*", "", s)

    # Handle nested brace macros cleanly inside-out
    s = _replace_brace_command(s, "frac", 2, lambda a, b: f"({a})/({b})")
    s = _replace_brace_command(s, "sqrt", 1, lambda a: f"√({a})")
    s = _replace_brace_command(s, "binom", 2, lambda a, b: f"C({a}, {b})")
    s = _replace_brace_command(s, "boldsymbol", 1, lambda a: a)
    s = _replace_brace_command(s, "mathbf", 1, lambda a: a)
    s = _replace_brace_command(s, "text", 1, lambda a: a)
    s = _replace_brace_command(s, "mathrm", 1, lambda a: a)
    s = _replace_brace_command(s, "operatorname", 1, lambda a: a)
    s = _replace_brace_command(s, "bar", 1, lambda a: f"{a}\u0304")
    s = _replace_brace_command(s, "hat", 1, lambda a: f"{a}\u0302")

    # Greek & operators
    replacements = [
        (r"\\beta", "β"), (r"\\alpha", "α"),
        (r"\\gamma", "γ"), (r"\\delta", "δ"), (r"\\varepsilon", "ε"), (r"\\epsilon", "ε"),
        (r"\\eta", "η"), (r"\\theta", "θ"), (r"\\lambda", "λ"), (r"\\mu", "μ"),
        (r"\\rho", "ρ"), (r"\\kappa", "κ"), (r"\\phi", "φ"), (r"\\psi", "ψ"),
        (r"\\sigma", "σ"), (r"\\tau", "τ"), (r"\\chi", "χ"), (r"\\Omega", "Ω"),
        (r"\\Delta", "Δ"), (r"\\Sigma", "∑"), (r"\\sum", "∑"), (r"\\int", "∫"),
        (r"\\partial", "∂"), (r"\\\|", "‖"), (r"\\langle", "⟨"), (r"\\rangle", "⟩"),
        (r"\\mathbb\{E\}", "E"), (r"\\mathbb\{I\}", "I"), (r"\\mathbb\{R\}", "ℝ"),
        (r"\\mathcal\{([^{}]+)\}", r"\1"),
        (r"\\arg\\max", "argmax"), (r"\\arg\\min", "argmin"),
        (r"\\exp", "exp"), (r"\\log_2", "log₂"), (r"\\log", "log"), (r"\\ln", "ln"),
        (r"\\max", "max"), (r"\\min", "min"), (r"\\cdot", "·"), (r"\\times", "×"), (r"\\pm", "±"),
        (r"\\le", "≤"), (r"\\ge", "≥"), (r"\\neq", "≠"), (r"\\equiv", "≡"),
        (r"\\sim", "∼"), (r"\\approx", "≈"), (r"\\propto", "∝"), (r"\\in", "∈"), (r"\\to", "→"), (r"\\implies", "⇒"),
        (r"\\infty", "∞"), (r"\\pi", "π"), (r"\\ell", "l"),
        (r"\\top", "ᵀ"), (r"\\,", " "), (r"\\;", " "), (r"\\!", ""), (r"\\%", "%"),
    ]
    for pat, rep in replacements:
        s = re.sub(pat, rep, s)
    # Convert single-token ^x / _x (not braced) first, then braced ^{...} / _{...}
    s = re.sub(r"\^([A-Za-z0-9])(?![\w\{])", r"^\1^", s)
    s = re.sub(r"_([A-Za-z0-9])(?![\w\{])", r"~\1~", s)
    s = re.sub(r"\^\{([^{}]+)\}", r"^\1^", s)
    s = re.sub(r"_\{([^{}]+)\}", r"~\1~", s)
    # Remove any leftover braces or backslashes
    s = s.replace("{", "").replace("}", "").replace("\\", "")
    s = re.sub(r"\s{4,}", "   ", s).strip()
    return s


M_NS = "http://schemas.openxmlformats.org/officeDocument/2006/math"
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
XML_NS = "http://www.w3.org/XML/1998/namespace"
MATH_FONT = "Cambria Math"


def _m(tag):
    return f"{{{M_NS}}}{tag}"


def _w(tag):
    return f"{{{W_NS}}}{tag}"


def _make_wrPr(size_half_pt=23, bold=False, italic=False):
    rPr = OxmlElement("w:rPr")
    rFonts = OxmlElement("w:rFonts")
    rFonts.set(qn("w:ascii"), MATH_FONT)
    rFonts.set(qn("w:hAnsi"), MATH_FONT)
    rFonts.set(qn("w:cs"), MATH_FONT)
    rPr.append(rFonts)
    if bold:
        rPr.append(OxmlElement("w:b"))
    if italic:
        rPr.append(OxmlElement("w:i"))
    col = OxmlElement("w:color")
    col.set(qn("w:val"), "000000")
    rPr.append(col)
    sz = OxmlElement("w:sz")
    sz.set(qn("w:val"), str(size_half_pt))
    rPr.append(sz)
    szCs = OxmlElement("w:szCs")
    szCs.set(qn("w:val"), str(size_half_pt))
    rPr.append(szCs)
    return rPr


def _make_ctrlPr(size_half_pt=23):
    ctrl = OxmlElement("m:ctrlPr")
    ctrl.append(_make_wrPr(size_half_pt=size_half_pt))
    return ctrl


def m_r(text, sty=None, sz=23):
    """Create an Office Math run (<m:r>) in black Cambria Math."""
    mr = OxmlElement("m:r")
    if sty is not None:
        mrPr = OxmlElement("m:rPr")
        m_sty = OxmlElement("m:sty")
        m_sty.set(qn("m:val"), sty)
        mrPr.append(m_sty)
        mr.append(mrPr)
    # Match OOXML w:rPr formatting flags to m:sty for consistent Word rendering
    wrPr = _make_wrPr(size_half_pt=sz, bold=(sty in ("b", "bi")), italic=(sty in (None, "bi")))
    mr.append(wrPr)
    mt = OxmlElement("m:t")
    if text != text.strip() or " " in text or "\u2009" in text or "\u2003" in text or "\u2002" in text:
        mt.set(f"{{{XML_NS}}}space", "preserve")
    mt.text = text
    mr.append(mt)
    return mr


def m_txt(text, sz=23):
    return m_r(text, sty="p", sz=sz)


def m_box(*children):
    """Group sequence into a single Office Math argument element (<m:e> or custom)."""
    return list(children)


def _append_items(parent, items):
    if items is None:
        return
    if isinstance(items, (list, tuple)):
        for it in items:
            if isinstance(it, (list, tuple)):
                _append_items(parent, it)
            else:
                parent.append(it)
    else:
        parent.append(items)


def m_frac(num, den, sz=23):
    f = OxmlElement("m:f")
    fPr = OxmlElement("m:fPr")
    t = OxmlElement("m:type")
    t.set(qn("m:val"), "bar")
    fPr.append(t)
    fPr.append(_make_ctrlPr(sz))
    f.append(fPr)
    n_el = OxmlElement("m:num")
    _append_items(n_el, num)
    d_el = OxmlElement("m:den")
    _append_items(d_el, den)
    f.append(n_el)
    f.append(d_el)
    return f


def m_sqrt(body, sz=23):
    rad = OxmlElement("m:rad")
    radPr = OxmlElement("m:radPr")
    degHide = OxmlElement("m:degHide")
    degHide.set(qn("m:val"), "1")
    radPr.append(degHide)
    radPr.append(_make_ctrlPr(sz))
    rad.append(radPr)
    rad.append(OxmlElement("m:deg"))
    e = OxmlElement("m:e")
    _append_items(e, body)
    rad.append(e)
    return rad


def m_nary(chr_sym, sub, sup, body, lim_loc="undOvr", sz=23):
    nary = OxmlElement("m:nary")
    naryPr = OxmlElement("m:naryPr")
    c = OxmlElement("m:chr")
    c.set(qn("m:val"), chr_sym)
    naryPr.append(c)
    ll = OxmlElement("m:limLoc")
    ll.set(qn("m:val"), lim_loc)
    naryPr.append(ll)
    gr = OxmlElement("m:grow")
    gr.set(qn("m:val"), "1")
    naryPr.append(gr)
    sh = OxmlElement("m:subHide")
    sh.set(qn("m:val"), "1" if sub is None else "0")
    naryPr.append(sh)
    uph = OxmlElement("m:supHide")
    uph.set(qn("m:val"), "1" if sup is None else "0")
    naryPr.append(uph)
    naryPr.append(_make_ctrlPr(sz))
    nary.append(naryPr)
    sub_el = OxmlElement("m:sub")
    _append_items(sub_el, sub)
    sup_el = OxmlElement("m:sup")
    _append_items(sup_el, sup)
    e_el = OxmlElement("m:e")
    _append_items(e_el, body)
    nary.append(sub_el)
    nary.append(sup_el)
    nary.append(e_el)
    return nary


def m_delim(body, beg="(", end=")", sz=23):
    d = OxmlElement("m:d")
    dPr = OxmlElement("m:dPr")
    b = OxmlElement("m:begChr")
    b.set(qn("m:val"), beg)
    e = OxmlElement("m:endChr")
    e.set(qn("m:val"), end)
    dPr.append(b)
    dPr.append(e)
    dPr.append(_make_ctrlPr(sz))
    d.append(dPr)
    e_el = OxmlElement("m:e")
    _append_items(e_el, body)
    d.append(e_el)
    return d


def m_sub(base, sub, sz=23):
    el = OxmlElement("m:sSub")
    pr = OxmlElement("m:sSubPr")
    pr.append(_make_ctrlPr(sz))
    el.append(pr)
    e_el = OxmlElement("m:e")
    _append_items(e_el, base)
    s_el = OxmlElement("m:sub")
    _append_items(s_el, sub)
    el.append(e_el)
    el.append(s_el)
    return el


def m_sup(base, sup, sz=23):
    el = OxmlElement("m:sSup")
    pr = OxmlElement("m:sSupPr")
    pr.append(_make_ctrlPr(sz))
    el.append(pr)
    e_el = OxmlElement("m:e")
    _append_items(e_el, base)
    s_el = OxmlElement("m:sup")
    _append_items(s_el, sup)
    el.append(e_el)
    el.append(s_el)
    return el


def m_subsup(base, sub, sup, sz=23):
    el = OxmlElement("m:sSubSup")
    pr = OxmlElement("m:sSubSupPr")
    pr.append(_make_ctrlPr(sz))
    el.append(pr)
    e_el = OxmlElement("m:e")
    _append_items(e_el, base)
    sb_el = OxmlElement("m:sub")
    _append_items(sb_el, sub)
    sp_el = OxmlElement("m:sup")
    _append_items(sp_el, sup)
    el.append(e_el)
    el.append(sb_el)
    el.append(sp_el)
    return el


def m_hat(base, acc_chr="\u0302", sz=23):
    acc = OxmlElement("m:acc")
    accPr = OxmlElement("m:accPr")
    c = OxmlElement("m:chr")
    c.set(qn("m:val"), acc_chr)
    accPr.append(c)
    accPr.append(_make_ctrlPr(sz))
    acc.append(accPr)
    e_el = OxmlElement("m:e")
    _append_items(e_el, base)
    acc.append(e_el)
    return acc


def m_limlow(base, lim, sz=23):
    ll = OxmlElement("m:limLow")
    pr = OxmlElement("m:limLowPr")
    pr.append(_make_ctrlPr(sz))
    ll.append(pr)
    e_el = OxmlElement("m:e")
    _append_items(e_el, base)
    l_el = OxmlElement("m:lim")
    _append_items(l_el, lim)
    ll.append(e_el)
    ll.append(l_el)
    return ll


def m_func(fname_nodes, arg_nodes, sz=23):
    fn = OxmlElement("m:func")
    pr = OxmlElement("m:funcPr")
    pr.append(_make_ctrlPr(sz))
    fn.append(pr)
    fName = OxmlElement("m:fName")
    _append_items(fName, fname_nodes)
    e_el = OxmlElement("m:e")
    _append_items(e_el, arg_nodes)
    fn.append(fName)
    fn.append(e_el)
    return fn


def ensure_math_settings(doc):
    """Configure document-level Office Math properties (Cambria Math, display rules)."""
    settings = doc.settings.element
    for old in settings.findall(_m("mathPr")):
        settings.remove(old)
    mathPr = OxmlElement("m:mathPr")
    for tag, val in [
        ("m:mathFont", MATH_FONT),
        ("m:brkBin", "before"),
        ("m:brkBinSub", "--"),
        ("m:smallFrac", "0"),
    ]:
        child = OxmlElement(tag)
        child.set(qn("m:val"), val)
        mathPr.append(child)
    mathPr.append(OxmlElement("m:dispDef"))
    for tag, val in [
        ("m:lMargin", "0"),
        ("m:rMargin", "0"),
        ("m:defJc", "centerGroup"),
        ("m:wrapIndent", "1440"),
        ("m:intLim", "subSup"),
        ("m:naryLim", "undOvr"),
    ]:
        child = OxmlElement(tag)
        child.set(qn("m:val"), val)
        mathPr.append(child)
    # Insert in ISO CT_Settings sequence after w:rsids or w:compat
    anchors = [settings.find(qn("w:rsids")), settings.find(qn("w:compat"))]
    anchor = next((a for a in anchors if a is not None), None)
    if anchor is not None:
        settings.insert(list(settings).index(anchor) + 1, mathPr)
    else:
        settings.append(mathPr)


def build_equation_omml(eq_num_str, sz=23):
    """Build native Cambria Math <m:oMathPara> for manuscript equations (1)-(12)."""
    MINUS = "\u2212"
    THIN = "\u2009"
    QUAD = "\u2003\u2003"
    MID = "\u2003"

    def fn(nodes):
        om = OxmlElement("m:oMath")
        _append_items(om, nodes)
        omp = OxmlElement("m:oMathPara")
        pr = OxmlElement("m:oMathParaPr")
        jc = OxmlElement("m:jc")
        jc.set(qn("m:val"), "center")
        pr.append(jc)
        omp.append(pr)
        omp.append(om)
        return omp

    key = str(eq_num_str).strip()
    if key == "1":
        # F(s) = \sqrt{ \frac{1}{N} \sum_{t=1}^{N} [ Y(t) - P_{m,s}(t) ]^2 },  F(s) \propto s^H
        nodes = [
            m_r("F", sz=sz), m_delim(m_r("s", sz=sz), sz=sz), m_txt(" = ", sz=sz),
            m_sqrt([
                m_frac(m_txt("1", sz=sz), m_r("N", sz=sz), sz=sz),
                m_nary(
                    "\u2211",
                    [m_r("t", sz=sz), m_txt(" = 1", sz=sz)],
                    m_r("N", sz=sz),
                    m_sup(
                        m_delim([
                            m_r("Y", sz=sz), m_delim(m_r("t", sz=sz), sz=sz),
                            m_txt(f" {MINUS} ", sz=sz),
                            m_sub(m_r("P", sz=sz), [m_r("m", sz=sz), m_txt(",", sz=sz), m_r("s", sz=sz)], sz=sz),
                            m_delim(m_r("t", sz=sz), sz=sz),
                        ], beg="[", end="]", sz=sz),
                        m_txt("2", sz=sz),
                        sz=sz,
                    ),
                    lim_loc="undOvr",
                    sz=sz,
                ),
            ], sz=sz),
            m_txt(f",{QUAD}", sz=sz),
            m_r("F", sz=sz), m_delim(m_r("s", sz=sz), sz=sz), m_txt(" \u221D ", sz=sz),
            m_sup(m_r("s", sz=sz), m_r("H", sz=sz), sz=sz),
        ]
        return fn(nodes)

    if key == "2":
        # D = 2 - H,  SOC band: H \in [0.70, 0.80], D \in [1.20, 1.30]
        nodes = [
            m_r("D", sz=sz), m_txt(f" = 2 {MINUS} ", sz=sz), m_r("H", sz=sz),
            m_txt(f",{QUAD}SOC band:{THIN}", sz=sz),
            m_r("H", sz=sz), m_txt(" \u2208 ", sz=sz),
            m_delim([m_txt("0.70, ", sz=sz), m_txt("0.80", sz=sz)], beg="[", end="]", sz=sz),
            m_txt(f",{MID}", sz=sz),
            m_r("D", sz=sz), m_txt(" \u2208 ", sz=sz),
            m_delim([m_txt("1.20, ", sz=sz), m_txt("1.30", sz=sz)], beg="[", end="]", sz=sz),
        ]
        return fn(nodes)

    if key == "3":
        # p_k = E_k / \sum_{j=1}^K E_j,  S = - 1/\log_2(K) \sum_{k=1}^K p_k \log_2(p_k)
        nodes = [
            m_sub(m_r("p", sz=sz), m_r("k", sz=sz), sz=sz), m_txt(" = ", sz=sz),
            m_frac(
                m_sub(m_r("E", sz=sz), m_r("k", sz=sz), sz=sz),
                m_nary("\u2211", [m_r("j", sz=sz), m_txt("=1", sz=sz)], m_r("K", sz=sz), m_sub(m_r("E", sz=sz), m_r("j", sz=sz), sz=sz), lim_loc="subSup", sz=sz),
                sz=sz,
            ),
            m_txt(f",{QUAD}", sz=sz),
            m_r("S", sz=sz), m_txt(f" = {MINUS}", sz=sz),
            m_frac(
                m_txt("1", sz=sz),
                m_func(m_sub(m_txt("log", sz=sz), m_txt("2", sz=sz), sz=sz), m_delim(m_r("K", sz=sz), sz=sz), sz=sz),
                sz=sz,
            ),
            m_nary(
                "\u2211",
                [m_r("k", sz=sz), m_txt("=1", sz=sz)],
                m_r("K", sz=sz),
                [
                    m_sub(m_r("p", sz=sz), m_r("k", sz=sz), sz=sz),
                    m_txt(THIN, sz=sz),
                    m_func(m_sub(m_txt("log", sz=sz), m_txt("2", sz=sz), sz=sz), m_delim(m_sub(m_r("p", sz=sz), m_r("k", sz=sz), sz=sz), sz=sz), sz=sz),
                ],
                lim_loc="undOvr",
                sz=sz,
            ),
        ]
        return fn(nodes)

    if key == "4":
        # Three integral ratios on one centered line using compact 11pt (sz=22)
        sz4 = min(sz, 22)
        def int_pf(lo, hi):
            return m_nary(
                "\u222B",
                m_txt(lo, sz=sz4),
                m_txt(hi, sz=sz4),
                [m_r("P", sz=sz4), m_delim(m_r("f", sz=sz4), sz=sz4), m_txt(f"{THIN}d", sz=sz4), m_r("f", sz=sz4)],
                lim_loc="subSup",
                sz=sz4,
            )
        nodes = [
            m_sub(m_r("P", sz=sz4), [m_r("\u03B8", sz=sz4), m_txt(",rel", sz=sz4)], sz=sz4),
            m_txt(" = ", sz=sz4),
            m_frac(int_pf("4", "8"), int_pf("0.5", "45"), sz=sz4),
            m_txt(f",{MID}", sz=sz4),
            m_sub(m_r("P", sz=sz4), [m_r("\u03C3", sz=sz4), m_txt(",rel", sz=sz4)], sz=sz4),
            m_txt(" = ", sz=sz4),
            m_frac(int_pf("12", "15"), int_pf("0.5", "45"), sz=sz4),
            m_txt(f",{MID}", sz=sz4),
            m_sub(m_r("R", sz=sz4), [m_r("\u03B1", sz=sz4), m_txt("/", sz=sz4), m_r("\u03B8", sz=sz4)], sz=sz4),
            m_txt(" = ", sz=sz4),
            m_frac(int_pf("8", "12"), int_pf("4", "8"), sz=sz4),
        ]
        return fn(nodes)

    if key == "5":
        # E_glob(G) = 1 / (|V|(|V|-1)) \sum_{u \neq v \in V} 1/d_{uv}
        absV = m_delim(m_r("V", sz=sz), beg="|", end="|", sz=sz)
        absV2 = m_delim(m_r("V", sz=sz), beg="|", end="|", sz=sz)
        nodes = [
            m_sub(m_r("E", sz=sz), m_txt("glob", sz=sz), sz=sz),
            m_delim(m_r("G", sz=sz), sz=sz),
            m_txt(" = ", sz=sz),
            m_frac(
                m_txt("1", sz=sz),
                [absV, m_delim([absV2, m_txt(f" {MINUS} 1", sz=sz)], sz=sz)],
                sz=sz,
            ),
            m_nary(
                "\u2211",
                [m_r("u", sz=sz), m_txt(" \u2260 ", sz=sz), m_r("v", sz=sz), m_txt(" \u2208 ", sz=sz), m_r("V", sz=sz)],
                None,
                m_frac(m_txt("1", sz=sz), m_sub(m_r("d", sz=sz), m_r("uv", sz=sz), sz=sz), sz=sz),
                lim_loc="undOvr",
                sz=sz,
            ),
        ]
        return fn(nodes)

    if key == "6":
        # Q = 1/(2m) \sum_{u,v \in V} [ w_{uv} - (k_u k_v)/(2m) ] \delta(c_u, c_v),  m = 1/2 \sum_{u,v \in V} w_{uv}
        sz6 = min(sz, 22)
        nodes = [
            m_r("Q", sz=sz6), m_txt(" = ", sz=sz6),
            m_frac(m_txt("1", sz=sz6), [m_txt("2", sz=sz6), m_r("m", sz=sz6)], sz=sz6),
            m_nary(
                "\u2211",
                [m_r("u", sz=sz6), m_txt(",", sz=sz6), m_r("v", sz=sz6), m_txt(" \u2208 ", sz=sz6), m_r("V", sz=sz6)],
                None,
                [
                    m_delim([
                        m_sub(m_r("w", sz=sz6), m_r("uv", sz=sz6), sz=sz6),
                        m_txt(f" {MINUS} ", sz=sz6),
                        m_frac(
                            [m_sub(m_r("k", sz=sz6), m_r("u", sz=sz6), sz=sz6), m_txt(THIN, sz=sz6), m_sub(m_r("k", sz=sz6), m_r("v", sz=sz6), sz=sz6)],
                            [m_txt("2", sz=sz6), m_r("m", sz=sz6)],
                            sz=sz6,
                        ),
                    ], beg="[", end="]", sz=sz6),
                    m_txt(THIN, sz=sz6),
                    m_r("\u03B4", sz=sz6),
                    m_delim([m_sub(m_r("c", sz=sz6), m_r("u", sz=sz6), sz=sz6), m_txt(", ", sz=sz6), m_sub(m_r("c", sz=sz6), m_r("v", sz=sz6), sz=sz6)], sz=sz6),
                ],
                lim_loc="undOvr",
                sz=sz6,
            ),
            m_txt(f",{MID}", sz=sz6),
            m_r("m", sz=sz6), m_txt(" = ", sz=sz6),
            m_frac(m_txt("1", sz=sz6), m_txt("2", sz=sz6), sz=sz6),
            m_nary(
                "\u2211",
                [m_r("u", sz=sz6), m_txt(",", sz=sz6), m_r("v", sz=sz6), m_txt(" \u2208 ", sz=sz6), m_r("V", sz=sz6)],
                None,
                m_sub(m_r("w", sz=sz6), m_r("uv", sz=sz6), sz=sz6),
                lim_loc="undOvr",
                sz=sz6,
            ),
        ]
        return fn(nodes)

    if key == "7":
        # C_i^w = 1/(k_i(k_i-1)) \sum_{j,k} ( \hat{w}_{ij} \hat{w}_{jk} \hat{w}_{ki} )^{1/3},  g(v) = \sum_{s \neq v \neq t} \sigma_{st}(v)/\sigma_{st}
        sz7 = min(sz, 22)
        def what(sub_s):
            return m_sub(m_hat(m_r("w", sz=sz7), sz=sz7), m_r(sub_s, sz=sz7), sz=sz7)
        nodes = [
            m_subsup(m_r("C", sz=sz7), m_r("i", sz=sz7), m_r("w", sz=sz7), sz=sz7),
            m_txt(" = ", sz=sz7),
            m_frac(
                m_txt("1", sz=sz7),
                [m_sub(m_r("k", sz=sz7), m_r("i", sz=sz7), sz=sz7), m_delim([m_sub(m_r("k", sz=sz7), m_r("i", sz=sz7), sz=sz7), m_txt(f" {MINUS} 1", sz=sz7)], sz=sz7)],
                sz=sz7,
            ),
            m_nary(
                "\u2211",
                [m_r("j", sz=sz7), m_txt(",", sz=sz7), m_r("k", sz=sz7)],
                None,
                m_sup(
                    m_delim([what("ij"), m_txt(THIN, sz=sz7), what("jk"), m_txt(THIN, sz=sz7), what("ki")], sz=sz7),
                    m_txt("1/3", sz=sz7),
                    sz=sz7,
                ),
                lim_loc="undOvr",
                sz=sz7,
            ),
            m_txt(f",{MID}", sz=sz7),
            m_r("g", sz=sz7), m_delim(m_r("v", sz=sz7), sz=sz7), m_txt(" = ", sz=sz7),
            m_nary(
                "\u2211",
                [m_r("s", sz=sz7), m_txt(" \u2260 ", sz=sz7), m_r("v", sz=sz7), m_txt(" \u2260 ", sz=sz7), m_r("t", sz=sz7)],
                None,
                m_frac(
                    [m_sub(m_r("\u03C3", sz=sz7), m_r("st", sz=sz7), sz=sz7), m_delim(m_r("v", sz=sz7), sz=sz7)],
                    m_sub(m_r("\u03C3", sz=sz7), m_r("st", sz=sz7), sz=sz7),
                    sz=sz7,
                ),
                lim_loc="undOvr",
                sz=sz7,
            ),
        ]
        return fn(nodes)

    if key == "8":
        # y_{ijg}^{ComBat} = (y_{ijg} - \hat{\alpha}_g - X_j \hat{\beta}_g - \hat{\gamma}_{ig}) / \hat{\delta}_{ig} + \hat{\alpha}_g + X_j \hat{\beta}_g
        def term_alpha():
            return m_sub(m_hat(m_r("\u03B1", sz=sz), sz=sz), m_r("g", sz=sz), sz=sz)
        def term_Xbeta():
            return [m_sub(m_r("X", sty="b", sz=sz), m_r("j", sz=sz), sz=sz), m_sub(m_hat(m_r("\u03B2", sty="bi", sz=sz), sz=sz), m_r("g", sz=sz), sz=sz)]
        nodes = [
            m_subsup(m_r("y", sz=sz), m_r("ijg", sz=sz), m_txt("ComBat", sz=sz), sz=sz),
            m_txt(" = ", sz=sz),
            m_frac(
                [
                    m_sub(m_r("y", sz=sz), m_r("ijg", sz=sz), sz=sz),
                    m_txt(f" {MINUS} ", sz=sz),
                    term_alpha(),
                    m_txt(f" {MINUS} ", sz=sz),
                    *term_Xbeta(),
                    m_txt(f" {MINUS} ", sz=sz),
                    m_sub(m_hat(m_r("\u03B3", sz=sz), sz=sz), m_r("ig", sz=sz), sz=sz),
                ],
                m_sub(m_hat(m_r("\u03B4", sz=sz), sz=sz), m_r("ig", sz=sz), sz=sz),
                sz=sz,
            ),
            m_txt(" + ", sz=sz),
            term_alpha(),
            m_txt(" + ", sz=sz),
            *term_Xbeta(),
        ]
        return fn(nodes)

    if key == "9":
        # Y_{jr} = \beta_0 + \beta_{g(j)} + \beta_r + \beta_{g(j),r} + \beta_M M_j + u_{s(j)} + \varepsilon_{jr},  u_{s(j)} \sim \mathcal{N}(0, \sigma_u^2)
        sz9 = min(sz, 22)
        def subj_sub(fn_chr, arg_chr):
            return [m_r(fn_chr, sz=sz9), m_delim(m_r(arg_chr, sz=sz9), sz=sz9)]
        nodes = [
            m_sub(m_r("Y", sz=sz9), m_r("jr", sz=sz9), sz=sz9), m_txt(" = ", sz=sz9),
            m_sub(m_r("\u03B2", sz=sz9), m_txt("0", sz=sz9), sz=sz9), m_txt(" + ", sz=sz9),
            m_sub(m_r("\u03B2", sz=sz9), subj_sub("g", "j"), sz=sz9), m_txt(" + ", sz=sz9),
            m_sub(m_r("\u03B2", sz=sz9), m_r("r", sz=sz9), sz=sz9), m_txt(" + ", sz=sz9),
            m_sub(m_r("\u03B2", sz=sz9), [*subj_sub("g", "j"), m_txt(",", sz=sz9), m_r("r", sz=sz9)], sz=sz9), m_txt(" + ", sz=sz9),
            m_sub(m_r("\u03B2", sz=sz9), m_r("M", sz=sz9), sz=sz9), m_txt(THIN, sz=sz9), m_sub(m_r("M", sz=sz9), m_r("j", sz=sz9), sz=sz9), m_txt(" + ", sz=sz9),
            m_sub(m_r("u", sz=sz9), subj_sub("s", "j"), sz=sz9), m_txt(" + ", sz=sz9),
            m_sub(m_r("\u03B5", sz=sz9), m_r("jr", sz=sz9), sz=sz9),
            m_txt(f",{MID}", sz=sz9),
            m_sub(m_r("u", sz=sz9), subj_sub("s", "j"), sz=sz9),
            m_txt(" \u223C ", sz=sz9),
            m_r("\U0001D4A9", sz=sz9),
            m_delim([m_txt("0, ", sz=sz9), m_subsup(m_r("\u03C3", sz=sz9), m_r("u", sz=sz9), m_txt("2", sz=sz9), sz=sz9)], sz=sz9),
        ]
        return fn(nodes)

    if key == "10":
        # ICC = \sigma_u^2 / (\sigma_u^2 + \sigma_\varepsilon^2)
        nodes = [
            m_txt("ICC = ", sz=sz),
            m_frac(
                m_subsup(m_r("\u03C3", sz=sz), m_r("u", sz=sz), m_txt("2", sz=sz), sz=sz),
                [
                    m_subsup(m_r("\u03C3", sz=sz), m_r("u", sz=sz), m_txt("2", sz=sz), sz=sz),
                    m_txt(" + ", sz=sz),
                    m_subsup(m_r("\u03C3", sz=sz), m_r("\u03B5", sz=sz), m_txt("2", sz=sz), sz=sz),
                ],
                sz=sz,
            ),
        ]
        return fn(nodes)

    if key == "11":
        # z(r) = 1/2 \ln((1+r)/(1-r)),  Z_diff = (z(r_1) - z(r_2)) / \sqrt{ 1/(n_1-3) + 1/(n_2-3) }
        nodes = [
            m_r("z", sz=sz), m_delim(m_r("r", sz=sz), sz=sz), m_txt(" = ", sz=sz),
            m_frac(m_txt("1", sz=sz), m_txt("2", sz=sz), sz=sz),
            m_func(
                m_txt("ln", sz=sz),
                m_delim(
                    m_frac([m_txt("1 + ", sz=sz), m_r("r", sz=sz)], [m_txt(f"1 {MINUS} ", sz=sz), m_r("r", sz=sz)], sz=sz),
                    sz=sz,
                ),
                sz=sz,
            ),
            m_txt(f",{QUAD}", sz=sz),
            m_sub(m_r("Z", sz=sz), m_txt("diff", sz=sz), sz=sz), m_txt(" = ", sz=sz),
            m_frac(
                [
                    m_r("z", sz=sz), m_delim(m_sub(m_r("r", sz=sz), m_txt("1", sz=sz), sz=sz), sz=sz),
                    m_txt(f" {MINUS} ", sz=sz),
                    m_r("z", sz=sz), m_delim(m_sub(m_r("r", sz=sz), m_txt("2", sz=sz), sz=sz), sz=sz),
                ],
                m_sqrt([
                    m_frac(m_txt("1", sz=sz), [m_sub(m_r("n", sz=sz), m_txt("1", sz=sz), sz=sz), m_txt(f" {MINUS} 3", sz=sz)], sz=sz),
                    m_txt(" + ", sz=sz),
                    m_frac(m_txt("1", sz=sz), [m_sub(m_r("n", sz=sz), m_txt("2", sz=sz), sz=sz), m_txt(f" {MINUS} 3", sz=sz)], sz=sz),
                ], sz=sz),
                sz=sz,
            ),
        ]
        return fn(nodes)

    if key == "12":
        # \hat{y}(x) = \operatorname*{arg\,max}_{c \in \mathcal{C}} 1/B \sum_{b=1}^B \mathbb{I}(T_b(x)=c),  MDA(X_m) = 1/B \sum_{b=1}^B ( err_b - err_b^{(m)} )
        sz12 = min(sz, 22)
        nodes = [
            m_hat(m_r("y", sz=sz12), sz=sz12), m_delim(m_r("x", sz=sz12), sz=sz12), m_txt(" = ", sz=sz12),
            m_limlow(
                m_txt(f"arg{THIN}max", sz=sz12),
                [m_r("c", sz=sz12), m_txt(" \u2208 ", sz=sz12), m_r("\U0001D49E", sz=sz12)],
                sz=sz12,
            ),
            m_txt(THIN, sz=sz12),
            m_frac(m_txt("1", sz=sz12), m_r("B", sz=sz12), sz=sz12),
            m_nary(
                "\u2211",
                [m_r("b", sz=sz12), m_txt("=1", sz=sz12)],
                m_r("B", sz=sz12),
                [
                    m_r("\U0001D540", sty="p", sz=sz12),
                    m_delim([m_sub(m_r("T", sz=sz12), m_r("b", sz=sz12), sz=sz12), m_delim(m_r("x", sz=sz12), sz=sz12), m_txt(" = ", sz=sz12), m_r("c", sz=sz12)], sz=sz12),
                ],
                lim_loc="undOvr",
                sz=sz12,
            ),
            m_txt(f",{MID}", sz=sz12),
            m_txt("MDA", sz=sz12), m_delim(m_sub(m_r("X", sz=sz12), m_r("m", sz=sz12), sz=sz12), sz=sz12),
            m_txt(" = ", sz=sz12),
            m_frac(m_txt("1", sz=sz12), m_r("B", sz=sz12), sz=sz12),
            m_nary(
                "\u2211",
                [m_r("b", sz=sz12), m_txt("=1", sz=sz12)],
                m_r("B", sz=sz12),
                m_delim([
                    m_sub(m_txt("err", sz=sz12), m_r("b", sz=sz12), sz=sz12),
                    m_txt(f" {MINUS} ", sz=sz12),
                    m_subsup(m_txt("err", sz=sz12), m_r("b", sz=sz12), m_delim(m_r("m", sz=sz12), sz=sz12), sz=sz12),
                ], sz=sz12),
                lim_loc="undOvr",
                sz=sz12,
            ),
        ]
        return fn(nodes)

    return None


def _style_equation_table_geometry(tbl):
    """Apply fixed 6.50 in (0.45 + 5.60 + 0.45 in) borderless three-column layout."""
    tbl.autofit = False
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tblPr = tbl._tbl.tblPr
    for tag in ("w:tblW", "w:jc", "w:tblBorders", "w:tblLayout", "w:tblCellMar"):
        for old in tblPr.findall(qn(tag)):
            tblPr.remove(old)

    tblW = OxmlElement("w:tblW")
    tblW.set(qn("w:w"), "9360")
    tblW.set(qn("w:type"), "dxa")
    jc = OxmlElement("w:jc")
    jc.set(qn("w:val"), "center")
    borders = parse_xml(
        f'<w:tblBorders {nsdecls("w")}>'
        '<w:top w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:left w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:bottom w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:right w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '</w:tblBorders>'
    )
    layout = OxmlElement("w:tblLayout")
    layout.set(qn("w:type"), "fixed")

    # Insert in strict ISO CT_TblPr order
    tblPr.append(tblW)
    tblPr.append(jc)
    tblPr.append(borders)
    tblPr.append(layout)

    # Set exact gridCol widths
    tblGrid = tbl._tbl.tblGrid
    if tblGrid is not None:
        for old in list(tblGrid):
            tblGrid.remove(old)
        for dxa in (648, 8064, 648):
            gc = OxmlElement("w:gridCol")
            gc.set(qn("w:w"), str(dxa))
            tblGrid.append(gc)

    trPr = tbl.rows[0]._tr.get_or_add_trPr()
    if trPr.find(qn("w:cantSplit")) is None:
        trPr.append(OxmlElement("w:cantSplit"))

    for idx_c, dxa in enumerate((648, 8064, 648)):
        cell = tbl.rows[0].cells[idx_c]
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        tcPr = cell._tc.get_or_add_tcPr()
        for old in tcPr.findall(qn("w:tcW")):
            tcPr.remove(old)
        tcW = OxmlElement("w:tcW")
        tcW.set(qn("w:w"), str(dxa))
        tcW.set(qn("w:type"), "dxa")
        tcPr.insert(0, tcW)
        for old in tcPr.findall(qn("w:tcMar")):
            tcPr.remove(old)
        lr_mar = "0" if idx_c == 1 else ("0" if idx_c == 2 else "40")
        tcPr.append(parse_xml(
            f'<w:tcMar {nsdecls("w")}>'
            '<w:top w:w="60" w:type="dxa"/>'
            f'<w:left w:w="{lr_mar}" w:type="dxa"/>'
            '<w:bottom w:w="60" w:type="dxa"/>'
            f'<w:right w:w="{lr_mar}" w:type="dxa"/>'
            '</w:tcMar>'
        ))


def apply_omml_to_equation_table(tbl, eq_num_str, sz=23):
    """Replace contents of a 1x3 equation table with native centered OMML and right-aligned number."""
    _style_equation_table_geometry(tbl)
    omml_para = build_equation_omml(eq_num_str, sz=sz)
    assert omml_para is not None, f"Unsupported OMML equation number: {eq_num_str}"

    # Left spacer cell
    c0 = tbl.rows[0].cells[0]
    for p in list(c0.paragraphs[1:]):
        p._element.getparent().remove(p._element)
    p0 = c0.paragraphs[0]
    p0.text = ""
    p0.paragraph_format.space_before = Pt(2)
    p0.paragraph_format.space_after = Pt(2)
    p0.paragraph_format.line_spacing = 1.0

    # Center OMML cell
    c1 = tbl.rows[0].cells[1]
    for p in list(c1.paragraphs[1:]):
        p._element.getparent().remove(p._element)
    p1 = c1.paragraphs[0]
    p1_el = p1._element
    for ch in list(p1_el):
        if ch.tag != qn("w:pPr"):
            p1_el.remove(ch)
    p1.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p1.paragraph_format.space_before = Pt(3)
    p1.paragraph_format.space_after = Pt(3)
    p1.paragraph_format.line_spacing = 1.0
    p1_el.append(omml_para)

    # Flush-right equation number cell in upright Times New Roman 11.5 pt
    c2 = tbl.rows[0].cells[2]
    for p in list(c2.paragraphs[1:]):
        p._element.getparent().remove(p._element)
    p2 = c2.paragraphs[0]
    p2.text = ""
    p2.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p2.paragraph_format.space_before = Pt(2)
    p2.paragraph_format.space_after = Pt(2)
    p2.paragraph_format.line_spacing = 1.0
    r_num = p2.add_run(f"({str(eq_num_str).strip()})")
    set_run_font(r_num, size_pt=11.5)


def add_editable_equation_row(doc, eq_text, eq_num_str):
    """Centered native Office Math equation with flush-right equation number in 1x3 layout."""
    tbl = doc.add_table(rows=1, cols=3)
    omml_para = build_equation_omml(eq_num_str)
    if omml_para is not None:
        apply_omml_to_equation_table(tbl, eq_num_str)
    else:
        _style_equation_table_geometry(tbl)
        p_center = tbl.rows[0].cells[1].paragraphs[0]
        p_center.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_center.paragraph_format.space_before = Pt(4)
        p_center.paragraph_format.space_after = Pt(4)
        p_center.paragraph_format.line_spacing = 1.15
        add_formatted_runs(p_center, eq_text, size_pt=11.5)

        p_num = tbl.rows[0].cells[2].paragraphs[0]
        p_num.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p_num.paragraph_format.space_before = Pt(4)
        p_num.paragraph_format.space_after = Pt(4)
        r_num = p_num.add_run(f"({eq_num_str})")
        set_run_font(r_num, size_pt=11.5)

    # Clean vertical breathing room below equation table
    p_sp = doc.add_paragraph()
    p_sp.paragraph_format.space_before = Pt(0)
    p_sp.paragraph_format.space_after = Pt(6)
    p_sp.paragraph_format.line_spacing = 1.0


def apply_three_line_borders(table):
    tblPr = table._tbl.tblPr
    borders = parse_xml(
        f'<w:tblBorders {nsdecls("w")}>'
        '<w:top w:val="single" w:sz="12" w:space="0" w:color="000000"/>'
        '<w:left w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:bottom w:val="single" w:sz="12" w:space="0" w:color="000000"/>'
        '<w:right w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:insideH w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '<w:insideV w:val="none" w:sz="0" w:space="0" w:color="auto"/>'
        '</w:tblBorders>'
    )
    tblPr.append(borders)
    # Add bottom border under header row
    hdr_cells = table.rows[0].cells
    for cell in hdr_cells:
        tcPr = cell._tc.get_or_add_tcPr()
        tcB = parse_xml(
            f'<w:tcBorders {nsdecls("w")}>'
            '<w:bottom w:val="single" w:sz="6" w:space="0" w:color="000000"/>'
            '</w:tcBorders>'
        )
        tcPr.append(tcB)


def build_docx():
    with open(MD_PATH, "r", encoding="utf-8") as f:
        lines = f.read().splitlines()

    doc = Document()
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11.0)
    section.top_margin = Inches(1.0)
    section.bottom_margin = Inches(1.0)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)

    add_page_number_header(section)
    enable_continuous_line_numbers(section)
    ensure_math_settings(doc)

    normal_style = doc.styles["Normal"]
    normal_style.font.name = FONT_NAME
    normal_style.font.size = Pt(12)
    normal_style.font.color.rgb = BLACK

    current_section = "TitleBlock"
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i].rstrip()
        stripped = line.strip()

        if not stripped or stripped == "---":
            i += 1
            continue

        # 1. Title (# ...)
        if stripped.startswith("# ") and not stripped.startswith("## "):
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.space_after = Pt(10)
            p.paragraph_format.line_spacing = 1.2
            add_formatted_runs(p, stripped[2:].strip(), size_pt=16, base_bold=True)
            i += 1
            continue

        # 2. Level-1 Heading (## ...)
        if stripped.startswith("## "):
            h_txt = stripped[3:].strip()
            current_section = h_txt
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_before = Pt(14)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.line_spacing = 1.5
            p.paragraph_format.keep_with_next = True
            add_formatted_runs(p, h_txt, size_pt=13, base_bold=True)
            i += 1
            continue

        # 3. Level-2 Heading (### ...)
        if stripped.startswith("### "):
            h_txt = stripped[4:].strip()
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.space_before = Pt(10)
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.line_spacing = 1.5
            p.paragraph_format.keep_with_next = True
            add_formatted_runs(p, h_txt, size_pt=12, base_bold=True)
            i += 1
            continue

        # 4. Display Equation Block ($$ ... $$)
        if stripped.startswith("$$"):
            eq_lines = [stripped]
            if not (stripped.endswith("$$") and len(stripped) > 2):
                i += 1
                while i < n:
                    eq_lines.append(lines[i].strip())
                    if lines[i].strip().endswith("$$"):
                        break
                    i += 1
            full_eq = " ".join(eq_lines).strip("$").strip()
            m_tag = re.search(r"\\tag\{([^}]+)\}", full_eq)
            eq_num = m_tag.group(1) if m_tag else ""
            eq_clean = clean_latex_to_math_text(full_eq)
            if not eq_num:
                m_paren = re.search(r"\((\d+[a-z]?)\)\s*$", eq_clean)
                if m_paren:
                    eq_num = m_paren.group(1)
                    eq_clean = eq_clean[:m_paren.start()].strip()
            add_editable_equation_row(doc, eq_clean, eq_num if eq_num else " ")
            i += 1
            continue

        # 5. Embedded Figure (![caption](path))
        if stripped.startswith("![") and "](" in stripped and stripped.endswith(")"):
            m_img = re.match(r"!\[([^\]]*)\]\(([^)]+)\)", stripped)
            if m_img:
                cap, rel_p = m_img.group(1), m_img.group(2)
                img_fname = os.path.basename(rel_p).replace(".pdf", ".png")
                img_path = os.path.join(FIG_DIR, img_fname)
                if os.path.exists(img_path):
                    p_img = doc.add_paragraph()
                    p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    p_img.paragraph_format.space_before = Pt(8)
                    p_img.paragraph_format.space_after = Pt(4)
                    p_img.paragraph_format.keep_with_next = True
                    p_img.add_run().add_picture(img_path, width=Inches(6.35))
                    if cap:
                        p_cap = doc.add_paragraph()
                        p_cap.alignment = WD_ALIGN_PARAGRAPH.LEFT
                        p_cap.paragraph_format.space_before = Pt(2)
                        p_cap.paragraph_format.space_after = Pt(12)
                        p_cap.paragraph_format.line_spacing = 1.15
                        add_formatted_runs(p_cap, cap, size_pt=10)
            i += 1
            continue

        # 6. Markdown Table (| col | col |)
        if stripped.startswith("|") and stripped.endswith("|"):
            table_lines = []
            while i < n and lines[i].strip().startswith("|") and lines[i].strip().endswith("|"):
                table_lines.append(lines[i].strip())
                i += 1
            # Parse header + data rows (skipping |---| separator row)
            parsed_rows = []
            for tl in table_lines:
                cells = [c.strip() for c in tl.strip("|").split("|")]
                if all(re.match(r"^[:\-\s]+$", c) for c in cells):
                    continue
                parsed_rows.append(cells)
            if parsed_rows:
                nrows = len(parsed_rows)
                ncols = max(len(r) for r in parsed_rows)
                tbl = doc.add_table(rows=nrows, cols=ncols)
                tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
                for r_idx, row_vals in enumerate(parsed_rows):
                    for c_idx in range(ncols):
                        val = row_vals[c_idx] if c_idx < len(row_vals) else ""
                        cell = tbl.rows[r_idx].cells[c_idx]
                        p_c = cell.paragraphs[0]
                        p_c.alignment = WD_ALIGN_PARAGRAPH.LEFT if c_idx == 0 else WD_ALIGN_PARAGRAPH.CENTER
                        p_c.paragraph_format.space_before = Pt(2)
                        p_c.paragraph_format.space_after = Pt(2)
                        p_c.paragraph_format.line_spacing = 1.05
                        if r_idx == 0:
                            p_c.paragraph_format.keep_with_next = True
                        add_formatted_runs(p_c, val, size_pt=9.0 if ncols >= 7 else 9.5, base_bold=(r_idx == 0))
                apply_three_line_borders(tbl)
                p_sp = doc.add_paragraph()
                p_sp.paragraph_format.space_before = Pt(0)
                p_sp.paragraph_format.space_after = Pt(8)
                p_sp.paragraph_format.line_spacing = 1.0
            continue

        # 7. TitleBlock metadata vs Sections vs Body
        p = doc.add_paragraph()
        if current_section == "TitleBlock":
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.line_spacing = 1.15
            if stripped.startswith("*Correspondence"):
                p.paragraph_format.space_before = Pt(4)
                p.paragraph_format.space_after = Pt(4)
                add_formatted_runs(p, stripped, size_pt=10)
            elif stripped.startswith("**Running title"):
                p.paragraph_format.space_before = Pt(2)
                p.paragraph_format.space_after = Pt(14)
                add_formatted_runs(p, stripped, size_pt=10)
            elif re.match(r"^\^\d+\^", stripped):
                p.paragraph_format.space_before = Pt(1)
                p.paragraph_format.space_after = Pt(2)
                add_formatted_runs(p, stripped, size_pt=9.5, base_italic=True)
            else:
                p.paragraph_format.space_before = Pt(2)
                p.paragraph_format.space_after = Pt(4)
                add_formatted_runs(p, stripped, size_pt=12)
        elif current_section == "Abstract":
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.line_spacing = 2.0
            p.paragraph_format.space_after = Pt(12)
            add_formatted_runs(p, stripped, size_pt=10.5)
        elif current_section == "Keywords":
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.line_spacing = 1.5
            p.paragraph_format.space_after = Pt(12)
            add_formatted_runs(p, stripped, size_pt=10)
        elif current_section == "References":
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            p.paragraph_format.line_spacing = 1.15
            p.paragraph_format.left_indent = Inches(0.32)
            p.paragraph_format.first_line_indent = Inches(-0.32)
            p.paragraph_format.space_after = Pt(4)
            add_formatted_runs(p, stripped, size_pt=9.5)
        else:
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            if re.match(r"^\*\*Table\s+\d+", stripped):
                p.paragraph_format.line_spacing = 1.15
                p.paragraph_format.space_before = Pt(10)
                p.paragraph_format.space_after = Pt(4)
                p.paragraph_format.keep_with_next = True
                add_formatted_runs(p, stripped, size_pt=10.5)
            elif re.match(r"^\*\*Figure\s+\d+\.", stripped):
                p.paragraph_format.line_spacing = 1.15
                p.paragraph_format.space_before = Pt(6)
                p.paragraph_format.space_after = Pt(8)
                add_formatted_runs(p, stripped, size_pt=10.5)
            elif re.match(r"^\*Note:", stripped) or stripped.startswith("Note:"):
                p.paragraph_format.line_spacing = 1.15
                p.paragraph_format.space_before = Pt(2)
                p.paragraph_format.space_after = Pt(10)
                add_formatted_runs(p, stripped, size_pt=9.5)
            else:
                p.paragraph_format.line_spacing = 2.0
                p.paragraph_format.first_line_indent = Inches(0)
                p.paragraph_format.space_before = Pt(0)
                p.paragraph_format.space_after = Pt(12)
                add_formatted_runs(p, stripped, size_pt=12)
        i += 1

    doc.save(DOCX_PATH)
    print(f"[DONE] Styled Nature-format Word manuscript written to: {DOCX_PATH}")


if __name__ == "__main__":
    build_docx()
