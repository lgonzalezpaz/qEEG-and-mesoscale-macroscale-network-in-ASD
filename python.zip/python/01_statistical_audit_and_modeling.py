"""
01_statistical_audit_and_modeling.py
====================================
Complete statistical verification, Empirical Bayes (ComBat) batch harmonization,
intraclass correlation (ICC) variance partitioning, REML Linear Mixed-Effects (LME)
modeling, Fisher z-test meso-macro decoupling analysis, sub-pathology stratification,
and supervised Random Forest / ROC-AUC / feature-ablation validation.

Author: Orchestrator Argon Pipeline (paper40)
"""

import os
import re
import io
import json
import shutil
import zipfile
import warnings
import numpy as np
import pandas as pd
import rdata
from scipy import stats
from scipy.special import digamma
import statsmodels.api as sm
import statsmodels.formula.api as smf
from patsy import dmatrices
from sklearn.model_selection import StratifiedKFold, StratifiedGroupKFold, train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
    roc_auc_score,
    roc_curve,
    average_precision_score,
    precision_recall_curve,
)
from sklearn.preprocessing import label_binarize
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
# 0. PATHS
# ---------------------------------------------------------------------------
OUT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA_DIR = os.path.join(os.path.dirname(OUT_DIR), "Directorio 20260518")
TAB_DIR = os.path.join(OUT_DIR, "Tables")
REPO_DATA_DIR = os.path.join(OUT_DIR, "GitHub_Zenodo_Repository", "data_summary")
os.makedirs(TAB_DIR, exist_ok=True)
os.makedirs(REPO_DATA_DIR, exist_ok=True)

# ---------------------------------------------------------------------------
# 1. LOAD RAW DATA, METADATA & ORIGINAL RDS MATRICES
# ---------------------------------------------------------------------------
print("[1/8] Loading datasets and metadata...")
bio = pd.read_csv(os.path.join(DATA_DIR, "Database_trainningdata_biof.csv"), sep=";", decimal=",", encoding="latin1")
graf = pd.read_csv(os.path.join(DATA_DIR, "Database_trainningdata_graf.csv"), sep=";", decimal=",", encoding="latin1")

META_ZIP_PATH = r"C:\Users\CBM\.gemini\antigravity\brain\61bb08b9-d91d-44d2-8b5e-5bda2e245f96\.user_uploaded\media_1794639427478_2b75d3cd.zip"
LEGACY_META_XLSX = os.path.join(REPO_DATA_DIR, "metadatos_completos.xlsx")
if os.path.exists(LEGACY_META_XLSX):
    os.remove(LEGACY_META_XLSX)
CANON_META_XLSX = os.path.join(REPO_DATA_DIR, "complete_metadata.xlsx")
if os.path.exists(META_ZIP_PATH):
    with zipfile.ZipFile(META_ZIP_PATH, "r") as zf:
        raw_meta_bytes = zf.read("metadatos_completos.xlsx")
    xl_raw = pd.ExcelFile(io.BytesIO(raw_meta_bytes))
else:
    fallback_xlsx = os.path.join(DATA_DIR, "metadatos_completos (1).xlsx")
    xl_raw = pd.ExcelFile(fallback_xlsx)

m_asd = pd.read_excel(xl_raw, sheet_name="ASD")
m_td = pd.read_excel(xl_raw, sheet_name="TD")
m_no = pd.read_excel(xl_raw, sheet_name="no-ASD")

# Harmonize Spanish pathology labels to English for clean reporting & complete_metadata.xlsx
short_pathology_map = {
    "epilepsia": "Epilepsy",
    "convulsiones": "Seizures / Epilepsy",
    "Alzheimer": "Alzheimer's disease",
    "Frontotemporal": "Frontotemporal dementia",
    "Parkinson": "Parkinson's disease",
    "sibling ASD": "Unaffected ASD sibling",
}

def _to_english_record_id(val):
    s = str(val)
    return "non-ASD" + s[6:] if s.startswith("no-ASD") else s

with pd.ExcelWriter(CANON_META_XLSX, engine="openpyxl") as writer:
    m_asd.rename(columns={"Metadato": "Metadata_ID", "Fuente": "Source", "Sujeto": "Subject_ID"})[
        ["Metadata_ID", "Source", "Subject_ID"]
    ].to_excel(writer, sheet_name="ASD", index=False)
    m_td.rename(columns={"Metadato": "Metadata_ID", "Fuente": "Source", "Sujeto": "Subject_ID"})[
        ["Metadata_ID", "Source", "Subject_ID"]
    ].to_excel(writer, sheet_name="TD", index=False)
    m_no_en = m_no.rename(columns={"Metadato": "Metadata_ID", "Fuente": "Source", "Sujeto": "Subject_ID", "Patología": "Pathology"}).copy()
    m_no_en["Metadata_ID"] = m_no_en["Metadata_ID"].map(_to_english_record_id)
    m_no_en["Pathology"] = m_no_en["Pathology"].map(lambda x: short_pathology_map.get(str(x), str(x)))
    m_no_en[["Metadata_ID", "Source", "Subject_ID", "Pathology"]].to_excel(writer, sheet_name="non-ASD", index=False)

m_asd["diagnostic_group"] = "ASD"
m_asd["Pathology"] = "ASD"
m_td["diagnostic_group"] = "TD"
m_td["Pathology"] = "TD"
m_no["diagnostic_group"] = "non-ASD"
m_no["Pathology"] = m_no["Patología"].map(lambda x: short_pathology_map.get(str(x), str(x)))
meta_all = pd.concat([m_asd, m_td, m_no], ignore_index=True).rename(
    columns={"Metadato": "cod", "Fuente": "Source", "Sujeto": "Subject_ID"}
)
meta_all["record_id"] = meta_all["cod"].map(_to_english_record_id)

clinical_stratum_map = {
    "ASD": "Autism Spectrum Disorder (ASD)",
    "TD": "Typically Developing (TD)",
    "Seizures / Epilepsy": "Seizure / Epilepsy (CHB-MIT)",
    "Epilepsy": "Pediatric Epilepsy (ds003555)",
    "Parkinson's disease": "Parkinson's Disease",
    "Alzheimer's disease": "Alzheimer's Disease",
    "Frontotemporal dementia": "Frontotemporal Dementia",
    "Unaffected ASD sibling": "Unaffected ASD Siblings",
}
meta_all["Clinical_Stratum"] = meta_all["Pathology"].map(clinical_stratum_map).fillna(meta_all["Pathology"])

def extract_bio_participant(row):
    """Map standardized EEG record IDs to unique biological participant identifiers."""
    f = str(row["Source"])
    s = str(row["Subject_ID"])
    g = str(row["diagnostic_group"])
    if f == "Mendeley Data":
        m = re.match(r"^(Part\d+)", s)
        return f"{g}:{f}:{m.group(1)}" if m else f"{g}:{f}:{s}"
    if f == "PhysioNet":
        m = re.match(r"^(chb\d+)", s)
        return f"{g}:{f}:{m.group(1)}" if m else f"{g}:{f}:{s}"
    return f"{g}:{f}:{s}"

meta_all["Bio_Participant"] = meta_all.apply(extract_bio_participant, axis=1)
meta_all["Is_RestEO"] = meta_all["Subject_ID"].astype(str).str.contains("restEO", case=False, na=False)

df_master_rds = rdata.read_rds(os.path.join(DATA_DIR, "df_master_armonizado_ROI.rds"))
df_long_rds = rdata.read_rds(os.path.join(DATA_DIR, "df_fase3_ready_long.rds"))

# Identify empty placeholder rows (225 non-ASD ds003555 records with all-NaN channels)
empty_cods = set(bio[bio["electrodo"].isna()]["cod"].unique())
meta_all["is_valid"] = ~meta_all["cod"].isin(empty_cods)

meta_all[["record_id", "diagnostic_group", "Source", "Subject_ID", "Pathology", "Clinical_Stratum", "Bio_Participant", "Is_RestEO", "is_valid"]].to_csv(
    os.path.join(REPO_DATA_DIR, "Metadata_Complete_Recording_to_Participant_Map.csv"), index=False
)

rec_structure_map = {
    "Mendeley Data": "19 conditions/participant (restEO + 6x3 tasks)",
    "OpenNeuro ds006780": "Multi-run (up to 6 runs/participant)",
    "OpenNeuro ds004504": "2 epochs/participant",
    "PhysioNet": "Continuous monitoring segments (chb01-chb24)",
    "OpenNeuro ds003555": "Multi-run (up to 9 runs/participant)",
}

def resolve_recording_structure(row):
    if row["Source"] == "OpenNeuro ds006780" and row["diagnostic_group"] == "non-ASD":
        return "1 record/participant"
    return rec_structure_map.get(row["Source"], "1 record/participant")

# Table 1: Cohort Architecture & Repository Breakdown
t1_rows = []
for (grp_d, fnt, p_en), g_df in meta_all.groupby(["diagnostic_group", "Source", "Clinical_Stratum"], sort=False):
    val_df = g_df[g_df["is_valid"]]
    t1_rows.append({
        "diagnostic_group": grp_d,
        "Source": fnt,
        "Clinical_Stratum": p_en,
        "total_records": int(len(g_df)),
        "valid_records": int(len(val_df)),
        "empty_records": int((~g_df["is_valid"]).sum()),
        "unique_bio_participants_total": int(g_df["Bio_Participant"].nunique()),
        "unique_bio_participants_valid": int(val_df["Bio_Participant"].nunique()),
        "recording_structure": resolve_recording_structure({"Source": fnt, "diagnostic_group": grp_d}),
    })
t1 = pd.DataFrame(t1_rows).sort_values(["diagnostic_group", "total_records"], ascending=[True, False]).reset_index(drop=True)
t1.to_csv(os.path.join(TAB_DIR, "Table1_Cohort_Repository_Summary.csv"), index=False)
print("  Table 1 saved. Total records:", len(meta_all), "| Valid non-empty:", int(meta_all["is_valid"].sum()),
      "| Unique bio-participants (valid):", int(meta_all.loc[meta_all["is_valid"], "Bio_Participant"].nunique()))

# ---------------------------------------------------------------------------
# 2. TOPOLOGICAL HUB SHIFT (MAX BETWEENNESS CENTRALITY ELECTRODE)
# ---------------------------------------------------------------------------
print("[2/8] Computing topological centrality hub shift & connectivity/deficit profiles...")
graf_m = graf.merge(meta_all[["cod", "record_id", "diagnostic_group", "Source", "Clinical_Stratum", "is_valid"]], on="cod", how="left")
graf_valid = graf_m[graf_m["centrality"].notna()].copy()
graf_valid["is_F7_F8"] = graf_valid["centrality"].isin(["F7", "F8"])
hub_summary = pd.crosstab(graf_valid["diagnostic_group"], graf_valid["centrality"])
hub_pct = pd.crosstab(graf_valid["diagnostic_group"], graf_valid["centrality"], normalize="index") * 100
hub_f7f8 = graf_valid.groupby("diagnostic_group")["is_F7_F8"].agg(["sum", "count", "mean"])
chi2_hub, p_hub, dof_hub, _ = stats.chi2_contingency(pd.crosstab(graf_valid["diagnostic_group"], graf_valid["is_F7_F8"]))
print(f"  Lateral frontal hub (F7/F8) dominance: ASD={hub_f7f8.loc['ASD','mean']*100:.2f}% ({hub_f7f8.loc['ASD','sum']}/{hub_f7f8.loc['ASD','count']}), "
      f"TD={hub_f7f8.loc['TD','mean']*100:.2f}%, non-ASD={hub_f7f8.loc['non-ASD','mean']*100:.2f}%, chi2({dof_hub})={chi2_hub:.2f}, p={p_hub:.3e}")
hub_summary.to_csv(os.path.join(REPO_DATA_DIR, "Centrality_Hub_Counts.csv"))
hub_pct.round(2).to_csv(os.path.join(REPO_DATA_DIR, "Centrality_Hub_Percentages.csv"))

# ---------------------------------------------------------------------------
# 3. EMPIRICAL BAYES (COMBAT) HARMONIZATION & ICC VARIANCE PARTITIONING
# ---------------------------------------------------------------------------
print("[3/8] Running Empirical Bayes ComBat harmonization & ICC computation...")

def combat_harmonize(Y_df, batch_series, covar_df):
    """
    Parametric Empirical Bayes ComBat location-scale batch harmonization
    (Johnson et al., Biostatistics 2007; Fortin et al., NeuroImage 2018).
    Y_df: (N x P) DataFrame of continuous features (no NaNs).
    batch_series: length-N array/Series of batch labels.
    covar_df: (N x K) DataFrame of biological covariates to preserve (e.g., diagnosis dummies).
    Returns harmonized DataFrame (N x P).
    """
    Y = Y_df.values.astype(float).T  # P x N
    n_genes, n_array = Y.shape
    batches = batch_series.astype(str).values
    unique_batches = np.unique(batches)
    n_batch = len(unique_batches)
    batch_idx = [np.where(batches == b)[0] for b in unique_batches]
    n_batches = np.array([len(idx) for idx in batch_idx])

    # Design matrix: batch indicators (no intercept) + biological covariates
    B_mat = np.zeros((n_array, n_batch))
    for i, idx in enumerate(batch_idx):
        B_mat[idx, i] = 1.0
    mod = covar_df.values.astype(float) if covar_df is not None and covar_df.shape[1] > 0 else np.empty((n_array, 0))
    design = np.hstack([B_mat, mod])

    # OLS fit: B_hat = (X^T X)^(-1) X^T Y^T
    B_hat, _, _, _ = np.linalg.lstsq(design, Y.T, rcond=None)  # (n_batch+K) x P
    grand_mean = (n_batches / n_array) @ B_hat[:n_batch, :]  # length P

    # Residual variance
    stand_mean = grand_mean[:, None] * np.ones((1, n_array))
    if mod.shape[1] > 0:
        mod_effect = (mod @ B_hat[n_batch:, :]).T  # P x N
        fitted_all = (design @ B_hat).T
    else:
        mod_effect = np.zeros_like(Y)
        fitted_all = (B_mat @ B_hat[:n_batch, :]).T

    var_pooled = np.mean((Y - fitted_all) ** 2, axis=1)
    var_pooled = np.where(var_pooled < 1e-12, 1e-12, var_pooled)
    s_data = (Y - stand_mean - mod_effect) / np.sqrt(var_pooled[:, None])

    # Batch-wise naive location & scale
    batch_design = B_mat
    gamma_hat = np.linalg.lstsq(batch_design, s_data.T, rcond=None)[0]  # n_batch x P
    delta_hat = np.zeros((n_batch, n_genes))
    for i, idx in enumerate(batch_idx):
        if len(idx) > 1:
            delta_hat[i, :] = np.var(s_data[:, idx], axis=1, ddof=1)
        else:
            delta_hat[i, :] = 1.0
    delta_hat = np.where(delta_hat < 1e-8, 1e-8, delta_hat)

    # Prior hyper-parameters per batch
    gamma_bar = np.mean(gamma_hat, axis=1)
    t2 = np.var(gamma_hat, axis=1, ddof=1)
    t2 = np.where(t2 < 1e-8, 1e-8, t2)

    a_prior = np.zeros(n_batch)
    b_prior = np.zeros(n_batch)
    for i in range(n_batch):
        m = np.mean(delta_hat[i, :])
        s2 = np.var(delta_hat[i, :], ddof=1)
        s2 = max(s2, 1e-8)
        a_prior[i] = (2.0 * s2 + m ** 2) / s2
        b_prior[i] = (m * s2 + m ** 3) / s2

    # Empirical Bayes EM updates (parametric)
    gamma_star = np.zeros_like(gamma_hat)
    delta_star = np.zeros_like(delta_hat)
    for i, idx in enumerate(batch_idx):
        n_b = len(idx)
        if n_b <= 2:
            gamma_star[i, :] = gamma_hat[i, :]
            delta_star[i, :] = delta_hat[i, :]
            continue
        g_old = gamma_hat[i, :].copy()
        d_old = delta_hat[i, :].copy()
        s_b = s_data[:, idx]
        for _ in range(50):
            g_new = (t2[i] * n_b * gamma_hat[i, :] + d_old * gamma_bar[i]) / (t2[i] * n_b + d_old)
            sum2 = np.sum((s_b - g_new[:, None]) ** 2, axis=1)
            d_new = (0.5 * sum2 + b_prior[i]) / (n_b / 2.0 + a_prior[i] - 1.0)
            d_new = np.where(d_new < 1e-8, 1e-8, d_new)
            if np.max(np.abs(g_new - g_old) / (np.abs(g_old) + 1e-8)) < 1e-5 and np.max(np.abs(d_new - d_old) / (np.abs(d_old) + 1e-8)) < 1e-5:
                g_old, d_old = g_new, d_new
                break
            g_old, d_old = g_new, d_new
        gamma_star[i, :] = g_old
        delta_star[i, :] = d_old

    # Adjust data
    bayesdata = s_data.copy()
    for i, idx in enumerate(batch_idx):
        denom = np.sqrt(delta_star[i, :])[:, None]
        bayesdata[:, idx] = (s_data[:, idx] - gamma_star[i, :][:, None]) / denom

    Y_corr = bayesdata * np.sqrt(var_pooled[:, None]) + stand_mean + mod_effect
    return pd.DataFrame(Y_corr.T, index=Y_df.index, columns=Y_df.columns)


def compute_icc_source(series, group_series):
    """One-way random effects ICC(1) for variance attributable to acquisition source."""
    df_tmp = pd.DataFrame({"y": pd.to_numeric(series, errors="coerce"), "grp": group_series}).dropna()
    if df_tmp["y"].std() < 1e-18 or df_tmp["grp"].nunique() < 2:
        return 0.0
    # Standardize y so tiny PSD floats (e.g., uV^2/Hz) never underflow REML optimizer gradients
    df_tmp["y_z"] = (df_tmp["y"] - df_tmp["y"].mean()) / df_tmp["y"].std()
    try:
        mod = smf.mixedlm("y_z ~ 1", data=df_tmp, groups=df_tmp["grp"]).fit(reml=True, method="powell")
        var_g = max(0.0, float(mod.cov_re.iloc[0, 0]))
        var_r = max(1e-12, float(mod.scale))
        return var_g / (var_g + var_r) if (var_g + var_r) > 0 else 0.0
    except Exception:
        return np.nan


# Clean valid-subject biophysical ROI table (fixing O2 -> PN and dropping empty 225 rows)
bio_clean_valid = bio[~bio["cod"].isin(empty_cods)].copy()
bio_clean_valid.loc[(bio_clean_valid["electrodo"] == "O2") & (bio_clean_valid["roi"].isna()), "roi"] = "PN"
bio_clean_valid = bio_clean_valid.merge(meta_all[["cod", "record_id", "diagnostic_group", "Source", "Clinical_Stratum"]], on="cod", how="left")

# Clean ROI short names (fixing IFG vs STS/FG order bug!)
def clean_roi_name(r):
    if pd.isna(r):
        return "Unassigned"
    s = str(r)
    if "OFC" in s:
        return "OFC"
    if "IFG" in s:
        return "IFG"
    if "ACC" in s or "SMA" in s:
        return "ACC/SMA"
    if "PPC" in s:
        return "PPC"
    if "STS" in s or "FG" in s or "Fusiforme" in s:
        return "STS/FG"
    if "BG" in s or "Subcorticales" in s:
        return "BG/SN/Th"
    if "Amígdala" in s or s.startswith("A ("):
        return "Amygdala"
    if s.strip() == "PN":
        return "PN"
    return s

bio_clean_valid["roi_clean"] = bio_clean_valid["roi"].apply(clean_roi_name)

# Subject-ROI level aggregation (clean valid cohort, N = 4609)
roi_subj = (
    bio_clean_valid.groupby(["cod", "record_id", "diagnostic_group", "Source", "Clinical_Stratum", "roi_clean"], as_index=False)
    .agg(
        theta=("theta", "mean"),
        sigma=("sigma", "mean"),
        hurst=("hurst", "mean"),
        shannon=("shannon", "mean"),
        ratio_at=("ratio.at", "mean"),
        node_weight=("peso", "mean"),
    )
)
# Merge valid graph metrics (renaming legacy midgrade/long to English mean_degree/path_length)
graf_clean = graf_m[graf_m["cod"].isin(roi_subj["cod"].unique())][
    ["cod", "midgrade", "centrality", "efficiency", "long", "modularity", "clustering"]
].rename(columns={"midgrade": "mean_degree", "long": "path_length"}).copy()
for col in ["mean_degree", "efficiency", "path_length", "modularity", "clustering"]:
    graf_clean[col] = pd.to_numeric(graf_clean[col], errors="coerce")
    graf_clean[col] = graf_clean[col].fillna(graf_clean[col].mean())

roi_subj = roi_subj.merge(graf_clean, on="cod", how="left")

# Subject-level wide matrix for 5 universal ROIs (OFC, ACC/SMA, PPC, STS/FG, PN) + Graph metrics for ComBat demo
universal_rois = ["OFC", "ACC/SMA", "PPC", "STS/FG", "PN"]
wide_univ = roi_subj[roi_subj["roi_clean"].isin(universal_rois)].pivot(
    index="cod", columns="roi_clean", values=["theta", "sigma", "hurst", "shannon", "ratio_at", "node_weight"]
)
wide_univ.columns = [f"{r}_{m}" for m, r in wide_univ.columns]
wide_univ = wide_univ.fillna(wide_univ.mean())
wide_univ = wide_univ.merge(
    meta_all.set_index("cod")[["diagnostic_group", "Source", "Clinical_Stratum"]],
    left_index=True, right_index=True, how="left"
).merge(graf_clean.set_index("cod")[["mean_degree", "efficiency", "path_length", "modularity", "clustering"]], left_index=True, right_index=True)

feat_cols_univ = [c for c in wide_univ.columns if c not in ["diagnostic_group", "Source", "Clinical_Stratum"]]
X_bio_cov = pd.get_dummies(wide_univ["diagnostic_group"], drop_first=True, dtype=float)
wide_univ_combat = combat_harmonize(wide_univ[feat_cols_univ], wide_univ["Source"], X_bio_cov)
wide_univ_combat[["diagnostic_group", "Source", "Clinical_Stratum"]] = wide_univ[["diagnostic_group", "Source", "Clinical_Stratum"]]

icc_rows = []
for feat in ["OFC_shannon", "OFC_hurst", "OFC_theta", "OFC_sigma", "ACC/SMA_shannon", "ACC/SMA_hurst", "PPC_shannon", "PPC_hurst", "efficiency", "modularity", "clustering"]:
    icc_pre = compute_icc_source(wide_univ[feat], wide_univ["Source"])
    icc_post = compute_icc_source(wide_univ_combat[feat], wide_univ_combat["Source"])
    icc_rows.append({"Feature": feat, "ICC_Pre_Harmonization": round(icc_pre, 4), "ICC_Post_ComBat": round(icc_post, 4), "Variance_Reduction_Pct": round((icc_pre - icc_post) / max(icc_pre, 1e-9) * 100, 2)})
df_icc = pd.DataFrame(icc_rows)
df_icc.to_csv(os.path.join(REPO_DATA_DIR, "ICC_Pre_vs_Post_ComBat.csv"), index=False)
print("  Mean ICC pre-ComBat:", df_icc["ICC_Pre_Harmonization"].mean().round(4), "| post-ComBat:", df_icc["ICC_Post_ComBat"].mean().round(4))

# ---------------------------------------------------------------------------
# 4. UNSUPERVISED PCA & HCPC VALIDATION (REPRODUCING & AUDITING SESSION002b)
# ---------------------------------------------------------------------------
print("[4/8] Auditing PCA & HCPC cluster validation...")
pca_eig = pd.read_csv(os.path.join(DATA_DIR, "PCA_Valores_Propios_Varianza.csv"))
hcpc_tab = pd.read_csv(os.path.join(DATA_DIR, "HCPC_Validacion_Clusters_Vs_Diagnostico.csv"))
hcpc_piv = hcpc_tab.pivot(index="Var1", columns="Var2", values="Freq").fillna(0).astype(int)
hcpc_piv.index.name = "Diagnostic_Group"
chi2_hcpc, p_hcpc, dof_hcpc, _ = stats.chi2_contingency(hcpc_piv.values)
n_tot_hcpc = hcpc_piv.values.sum()
cramers_v_hcpc = np.sqrt(chi2_hcpc / (n_tot_hcpc * (min(hcpc_piv.shape) - 1)))
print(f"  HCPC Chi2({dof_hcpc}) = {chi2_hcpc:.2f}, p = {p_hcpc:.3e}, Cramer's V = {cramers_v_hcpc:.4f}")
hcpc_piv.to_csv(os.path.join(TAB_DIR, "Table2_HCPC_Cluster_Contingency.csv"))

# ---------------------------------------------------------------------------
# 5. REFINED MULTILEVEL MIXED-EFFECTS (LME) MODELS (CONTINUOUS COVARIATES & MULTI-SITE)
# ---------------------------------------------------------------------------
print("[5/8] Fitting refined continuous-covariate REML Linear Mixed-Effects (LME) models...")

# Run LME on valid cleaned long-format data (N_valid = 4609 subjects, 8 anatomical ROIs, continuous efficiency & modularity)
roi_subj = roi_subj.merge(meta_all[["cod", "Bio_Participant", "Is_RestEO"]].drop_duplicates("cod"), on="cod", how="left")
roi_subj["diagnostic_group"] = pd.Categorical(roi_subj["diagnostic_group"], categories=["TD", "ASD", "non-ASD"])
roi_subj["roi_clean"] = pd.Categorical(roi_subj["roi_clean"], categories=["OFC", "IFG", "ACC/SMA", "PPC", "STS/FG", "PN", "BG/SN/Th", "Amygdala"])

# Fit Model A (Shannon ~ Group * ROI + Efficiency + (1|cod))
# Note: statsmodels MixedLM fits random intercept for 'cod' via groups=cod; we also fit Model B with site-adjusted ComBat values and Model C grouped by Bio_Participant!
lme_results_summary = []

def fit_and_summarize_lme(df_in, formula, outcome_label, model_name, group_col="cod"):
    df_sub = df_in.dropna(subset=[formula.split("~")[0].strip(), "efficiency", "modularity", group_col]).copy()
    y_mat, X_mat = dmatrices(formula, data=df_sub, return_type="dataframe")
    # Drop structural zero cells (e.g., non-ASD x IFG/Amygdala/BG) and enforce full column rank like lme4::lmer
    keep_cols = [c for c in X_mat.columns if X_mat[c].abs().max() > 1e-12]
    X_mat = X_mat[keep_cols]
    q, r = np.linalg.qr(X_mat.values)
    if np.min(np.abs(np.diag(r))) < 1e-8:
        rank_cols = []
        for col in X_mat.columns:
            cand = X_mat[rank_cols + [col]].values
            if np.linalg.matrix_rank(cand) > len(rank_cols):
                rank_cols.append(col)
        X_mat = X_mat[rank_cols]
    mod = sm.MixedLM(y_mat.iloc[:, 0], X_mat, groups=df_sub.loc[y_mat.index, group_col]).fit(reml=True, method="lbfgs")
    # Compute Wald Chi-square for main terms by grouping fixed-effect parameters
    fe_names = mod.fe_params.index.tolist()
    fe_cov = mod.cov_params().loc[fe_names, fe_names]
    fe_b = mod.fe_params

    def wald_group(prefix_list, exact=False):
        if exact:
            idx = [i for i, n in enumerate(fe_names) if n in prefix_list]
        else:
            idx = [i for i, n in enumerate(fe_names) if any(n.startswith(p) for p in prefix_list) and ":" not in n]
        if not idx:
            return np.nan, 0, np.nan
        b = fe_b.iloc[idx].values
        V = fe_cov.iloc[idx, idx].values
        stat = float(b.T @ np.linalg.pinv(V) @ b)
        df_w = len(idx)
        pval = float(stats.chi2.sf(stat, df_w))
        return stat, df_w, pval

    def wald_interaction():
        idx = [i for i, n in enumerate(fe_names) if ":" in n]
        b = fe_b.iloc[idx].values
        V = fe_cov.iloc[idx, idx].values
        stat = float(b.T @ np.linalg.pinv(V) @ b)
        df_w = len(idx)
        pval = float(stats.chi2.sf(stat, df_w))
        return stat, df_w, pval

    var_subj = float(mod.cov_re.iloc[0, 0])
    var_res = float(mod.scale)
    icc_subj = var_subj / (var_subj + var_res)

    terms = [
        ("Intercept", *wald_group(["Intercept"], exact=True)),
        ("Diagnostic Group", *wald_group(["C(diagnostic_group)"])),
        ("ROI", *wald_group(["C(roi_clean)"])),
    ]
    if "efficiency" in formula:
        terms.append(("Global Efficiency (E_glob)", *wald_group(["efficiency"], exact=True)))
    if "modularity" in formula:
        terms.append(("Global Modularity (Q)", *wald_group(["modularity"], exact=True)))
    terms.append(("Group x ROI Interaction", *wald_interaction()))

    rows = []
    for tname, wstat, wdf, wp in terms:
        rows.append({
            "Model": model_name,
            "Outcome": outcome_label,
            "Effect": tname,
            "Wald_Chi2": round(wstat, 4),
            "Df": wdf,
            "P_value": wp,
            "ICC_subject": round(icc_subj, 4),
            "N_obs": len(df_sub),
            "N_subjects": df_sub[group_col].nunique(),
        })
    # Also save fixed effect parameter table
    fe_df = pd.DataFrame({
        "Term": fe_names,
        "Beta": fe_b.values,
        "SE": mod.bse_fe.values,
        "z_value": mod.tvalues[fe_names].values,
        "P_value": mod.pvalues[fe_names].values,
        "CI_low": mod.conf_int().loc[fe_names, 0].values,
        "CI_high": mod.conf_int().loc[fe_names, 1].values,
    })
    return pd.DataFrame(rows), fe_df, mod

# Fit on universal 5 ROIs across all 4,609 subjects (so no structural zero cells) AND on all 8 ROIs
df_univ_long = roi_subj[roi_subj["roi_clean"].isin(universal_rois)].copy()
df_univ_long["roi_clean"] = pd.Categorical(df_univ_long["roi_clean"], categories=universal_rois)

w_sh_all, fe_sh_all, mod_sh_all = fit_and_summarize_lme(
    roi_subj, "shannon ~ C(diagnostic_group) * C(roi_clean) + efficiency", "shannon_roi", "Refined LME (All 8 ROIs)"
)
w_hu_all, fe_hu_all, mod_hu_all = fit_and_summarize_lme(
    roi_subj, "hurst ~ C(diagnostic_group) * C(roi_clean) + modularity", "hurst_roi", "Refined LME (All 8 ROIs)"
)
w_sh_univ, fe_sh_univ, _ = fit_and_summarize_lme(
    df_univ_long, "shannon ~ C(diagnostic_group) * C(roi_clean) + efficiency", "shannon_roi", "Refined LME (5 Universal ROIs)"
)
w_hu_univ, fe_hu_univ, _ = fit_and_summarize_lme(
    df_univ_long, "hurst ~ C(diagnostic_group) * C(roi_clean) + modularity", "hurst_roi", "Refined LME (5 Universal ROIs)"
)

# Also fit on ComBat-harmonized 5 Universal ROIs
univ_combat_long = (
    wide_univ_combat.reset_index()
    .melt(id_vars=["cod", "diagnostic_group", "Source", "Clinical_Stratum", "mean_degree", "efficiency", "path_length", "modularity", "clustering"],
          var_name="roi_metric", value_name="val")
)
univ_combat_long[["roi_clean", "metric"]] = univ_combat_long["roi_metric"].str.split("_", n=1, expand=True)
univ_combat_long = univ_combat_long.pivot(
    index=["cod", "diagnostic_group", "Source", "Clinical_Stratum", "efficiency", "modularity", "roi_clean"],
    columns="metric", values="val"
).reset_index()
univ_combat_long["diagnostic_group"] = pd.Categorical(univ_combat_long["diagnostic_group"], categories=["TD", "ASD", "non-ASD"])
univ_combat_long["roi_clean"] = pd.Categorical(univ_combat_long["roi_clean"], categories=universal_rois)

w_sh_cb, fe_sh_cb, _ = fit_and_summarize_lme(
    univ_combat_long, "shannon ~ C(diagnostic_group) * C(roi_clean) + efficiency", "shannon_roi", "ComBat-Harmonized LME (5 Universal ROIs)"
)
w_hu_cb, fe_hu_cb, _ = fit_and_summarize_lme(
    univ_combat_long, "hurst ~ C(diagnostic_group) * C(roi_clean) + modularity", "hurst_roi", "ComBat-Harmonized LME (5 Universal ROIs)"
)

w_sh_bio, fe_sh_bio, _ = fit_and_summarize_lme(
    roi_subj, "shannon ~ C(diagnostic_group) * C(roi_clean) + efficiency", "shannon_roi", "Bio-Participant Clustered LME (All 8 ROIs)", group_col="Bio_Participant"
)
w_hu_bio, fe_hu_bio, _ = fit_and_summarize_lme(
    roi_subj, "hurst ~ C(diagnostic_group) * C(roi_clean) + modularity", "hurst_roi", "Bio-Participant Clustered LME (All 8 ROIs)", group_col="Bio_Participant"
)

lme_all_wald = pd.concat([w_sh_all, w_hu_all, w_sh_univ, w_hu_univ, w_sh_cb, w_hu_cb, w_sh_bio, w_hu_bio], ignore_index=True)
lme_all_wald.to_csv(os.path.join(TAB_DIR, "Table3_LME_Wald_Tests_Refined_and_ComBat.csv"), index=False)
lme_all_wald.to_csv(os.path.join(TAB_DIR, "Table4_LME_Wald_Tests_Refined_and_ComBat.csv"), index=False)
fe_sh_all.to_csv(os.path.join(REPO_DATA_DIR, "LME_FixedEffects_Shannon.csv"), index=False)
fe_hu_all.to_csv(os.path.join(REPO_DATA_DIR, "LME_FixedEffects_Hurst.csv"), index=False)
print("  Refined LME complete. Efficiency Df=1, Modularity Df=1.")
print(lme_all_wald[lme_all_wald["Model"] == "Refined LME (All 8 ROIs)"][["Outcome", "Effect", "Wald_Chi2", "Df", "P_value"]].to_string(index=False))

# ---------------------------------------------------------------------------
# 6. FRONTAL MESO-MACRO DECOUPLING (FISHER Z-TESTS & SUB-PATHOLOGY STRATIFICATION)
# ---------------------------------------------------------------------------
print("[6/8] Computing frontal meso-macro decoupling, Fisher z-tests, and sub-pathology stratification...")

def fisher_r_ci(r, n, alpha=0.05):
    if n <= 3 or np.isnan(r) or abs(r) >= 0.999999:
        return r, np.nan, np.nan
    z = np.arctanh(r)
    se = 1.0 / np.sqrt(n - 3)
    zc = stats.norm.ppf(1 - alpha / 2)
    return r, np.tanh(z - zc * se), np.tanh(z + zc * se)

def fisher_z_compare(r1, n1, r2, n2):
    z1 = np.arctanh(np.clip(r1, -0.999999, 0.999999))
    z2 = np.arctanh(np.clip(r2, -0.999999, 0.999999))
    se = np.sqrt(1.0 / (n1 - 3) + 1.0 / (n2 - 3))
    z_stat = (z1 - z2) / se
    p_val = 2.0 * stats.norm.sf(abs(z_stat))
    return z_stat, p_val

# Extract both (a) exact Session004 OFC matrix (reproducing r=-0.0365) and (b) corrected OFC+IFG frontal matrix (r=-0.0409)
df_ofc = roi_subj[roi_subj["roi_clean"] == "OFC"].copy()
df_ofc_ifg = (
    roi_subj[roi_subj["roi_clean"].isin(["OFC", "IFG"])]
    .groupby(["cod", "record_id", "diagnostic_group", "Source", "Clinical_Stratum"], as_index=False, observed=True)
    .agg(
        shannon=("shannon", "mean"),
        hurst=("hurst", "mean"),
        efficiency=("efficiency", "first"),
        modularity=("modularity", "first"),
        Bio_Participant=("Bio_Participant", "first"),
        Is_RestEO=("Is_RestEO", "first"),
    )
)

bio_front = (
    df_ofc_ifg.groupby(["diagnostic_group", "Source", "Bio_Participant"], as_index=False, observed=True)
    .agg(
        shannon=("shannon", "mean"),
        hurst=("hurst", "mean"),
        efficiency=("efficiency", "mean"),
        modularity=("modularity", "mean"),
        n_records=("cod", "nunique"),
    )
)
bio_front.to_csv(os.path.join(REPO_DATA_DIR, "Biological_Participant_Frontal_Summary.csv"), index=False)

corr_pairs = [
    ("shannon", "efficiency", "Shannon_Frontal vs Global_Efficiency"),
    ("shannon", "modularity", "Shannon_Frontal vs Global_Modularity"),
    ("shannon", "hurst", "Shannon_Frontal vs Hurst_Frontal"),
    ("hurst", "efficiency", "Hurst_Frontal vs Global_Efficiency"),
    ("hurst", "modularity", "Hurst_Frontal vs Global_Modularity"),
    ("efficiency", "modularity", "Global_Efficiency vs Global_Modularity"),
]

decoupling_rows = []
for dataset_label, df_src in [("OFC (Original Session004 Match)", df_ofc), ("OFC+IFG (Refined Frontal)", df_ofc_ifg)]:
    grp_corrs = {}
    grp_ns = {}
    for g in ["ASD", "TD", "non-ASD"]:
        sg = df_src[df_src["diagnostic_group"] == g][["shannon", "hurst", "efficiency", "modularity"]].dropna()
        grp_corrs[g] = sg.corr()
        grp_ns[g] = len(sg)

    for v1, v2, label in corr_pairs:
        r_asd, ci_l_a, ci_h_a = fisher_r_ci(grp_corrs["ASD"].loc[v1, v2], grp_ns["ASD"])
        r_td, ci_l_t, ci_h_t = fisher_r_ci(grp_corrs["TD"].loc[v1, v2], grp_ns["TD"])
        r_non, ci_l_n, ci_h_n = fisher_r_ci(grp_corrs["non-ASD"].loc[v1, v2], grp_ns["non-ASD"])
        z_asd_td, p_asd_td = fisher_z_compare(r_asd, grp_ns["ASD"], r_td, grp_ns["TD"])
        z_asd_non, p_asd_non = fisher_z_compare(r_asd, grp_ns["ASD"], r_non, grp_ns["non-ASD"])
        decoupling_rows.append({
            "Definition": dataset_label,
            "Pair": label,
            "n_ASD": grp_ns["ASD"], "r_ASD": round(r_asd, 4), "ASD_CI95": f"[{ci_l_a:.4f}, {ci_h_a:.4f}]",
            "n_TD": grp_ns["TD"], "r_TD": round(r_td, 4), "TD_CI95": f"[{ci_l_t:.4f}, {ci_h_t:.4f}]",
            "n_nonASD": grp_ns["non-ASD"], "r_nonASD": round(r_non, 4), "nonASD_CI95": f"[{ci_l_n:.4f}, {ci_h_n:.4f}]",
            "Fisher_z_ASD_vs_TD": round(z_asd_td, 4), "P_ASD_vs_TD": p_asd_td,
            "Fisher_z_ASD_vs_nonASD": round(z_asd_non, 4), "P_ASD_vs_nonASD": p_asd_non,
        })

# Append Bio-Participant collapsed decoupling checks
bio_corrs = {}
bio_ns = {}
for g in ["ASD", "TD", "non-ASD"]:
    sg_b = bio_front[bio_front["diagnostic_group"] == g][["shannon", "hurst", "efficiency", "modularity"]].dropna()
    bio_corrs[g] = sg_b.corr()
    bio_ns[g] = len(sg_b)
for v1, v2, label in [
    ("shannon", "efficiency", "Shannon_Frontal vs Global_Efficiency"),
    ("shannon", "modularity", "Shannon_Frontal vs Global_Modularity"),
    ("hurst", "efficiency", "Hurst_Frontal vs Global_Efficiency"),
]:
    r_asd, ci_l_a, ci_h_a = fisher_r_ci(bio_corrs["ASD"].loc[v1, v2], bio_ns["ASD"])
    r_td, ci_l_t, ci_h_t = fisher_r_ci(bio_corrs["TD"].loc[v1, v2], bio_ns["TD"])
    r_non, ci_l_n, ci_h_n = fisher_r_ci(bio_corrs["non-ASD"].loc[v1, v2], bio_ns["non-ASD"])
    z_asd_td, p_asd_td = fisher_z_compare(r_asd, bio_ns["ASD"], r_td, bio_ns["TD"])
    z_asd_non, p_asd_non = fisher_z_compare(r_asd, bio_ns["ASD"], r_non, bio_ns["non-ASD"])
    decoupling_rows.append({
        "Definition": "Bio-Participant Mean (OFC+IFG, N_bio=2554)",
        "Pair": label,
        "n_ASD": bio_ns["ASD"], "r_ASD": round(r_asd, 4), "ASD_CI95": f"[{ci_l_a:.4f}, {ci_h_a:.4f}]",
        "n_TD": bio_ns["TD"], "r_TD": round(r_td, 4), "TD_CI95": f"[{ci_l_t:.4f}, {ci_h_t:.4f}]",
        "n_nonASD": bio_ns["non-ASD"], "r_nonASD": round(r_non, 4), "nonASD_CI95": f"[{ci_l_n:.4f}, {ci_h_n:.4f}]",
        "Fisher_z_ASD_vs_TD": round(z_asd_td, 4), "P_ASD_vs_TD": p_asd_td,
        "Fisher_z_ASD_vs_nonASD": round(z_asd_non, 4), "P_ASD_vs_nonASD": p_asd_non,
    })

# Append Mendeley restEO Only (1:1 biological participant) and Mendeley 19-condition Bio-Participant Mean
mend_rest_asd = df_ofc_ifg[(df_ofc_ifg["Source"] == "Mendeley Data") & (df_ofc_ifg["Is_RestEO"]) & (df_ofc_ifg["diagnostic_group"] == "ASD")][["shannon", "efficiency"]].dropna()
mend_rest_td = df_ofc_ifg[(df_ofc_ifg["Source"] == "Mendeley Data") & (df_ofc_ifg["Is_RestEO"]) & (df_ofc_ifg["diagnostic_group"] == "TD")][["shannon", "efficiency"]].dropna()
mend_bio_asd = bio_front[(bio_front["Source"] == "Mendeley Data") & (bio_front["diagnostic_group"] == "ASD")][["shannon", "efficiency"]].dropna()
mend_bio_td = bio_front[(bio_front["Source"] == "Mendeley Data") & (bio_front["diagnostic_group"] == "TD")][["shannon", "efficiency"]].dropna()

for m_lbl, m_a_df, m_t_df in [
    ("Mendeley restEO Only (1 rec/participant, n=31 vs 31)", mend_rest_asd, mend_rest_td),
    ("Mendeley Bio-Participant Mean (19-cond avg, n=31 vs 31)", mend_bio_asd, mend_bio_td),
]:
    r_ma, l_ma, h_ma = fisher_r_ci(m_a_df.corr().loc["shannon", "efficiency"], len(m_a_df))
    r_mt, l_mt, h_mt = fisher_r_ci(m_t_df.corr().loc["shannon", "efficiency"], len(m_t_df))
    z_m, p_m = fisher_z_compare(r_ma, len(m_a_df), r_mt, len(m_t_df))
    decoupling_rows.append({
        "Definition": m_lbl,
        "Pair": "Shannon_Frontal vs Global_Efficiency",
        "n_ASD": len(m_a_df), "r_ASD": round(r_ma, 4), "ASD_CI95": f"[{l_ma:.4f}, {h_ma:.4f}]",
        "n_TD": len(m_t_df), "r_TD": round(r_mt, 4), "TD_CI95": f"[{l_mt:.4f}, {h_mt:.4f}]",
        "n_nonASD": np.nan, "r_nonASD": np.nan, "nonASD_CI95": "",
        "Fisher_z_ASD_vs_TD": round(z_m, 4), "P_ASD_vs_TD": p_m,
        "Fisher_z_ASD_vs_nonASD": np.nan, "P_ASD_vs_nonASD": np.nan,
    })

df_decoup = pd.DataFrame(decoupling_rows)
df_decoup.to_csv(os.path.join(TAB_DIR, "Table4_Frontal_MesoMacro_Decoupling_FisherZ.csv"), index=False)
df_decoup.to_csv(os.path.join(TAB_DIR, "Table5_Frontal_MesoMacro_Decoupling_FisherZ.csv"), index=False)

# Sub-pathology stratification within non-ASD + multi-group matched repositories (e.g. Mendeley Data & restEO)
subpath_rows = []
for path_name, sub_df in df_ofc_ifg.groupby("Clinical_Stratum"):
    sg = sub_df[["shannon", "hurst", "efficiency", "modularity"]].dropna()
    if len(sg) >= 10:
        c = sg.corr()
        r_se, l_se, h_se = fisher_r_ci(c.loc["shannon", "efficiency"], len(sg))
        r_he, l_he, h_he = fisher_r_ci(c.loc["hurst", "efficiency"], len(sg))
        r_sq, l_sq, h_sq = fisher_r_ci(c.loc["shannon", "modularity"], len(sg))
        z_vs_asd, p_vs_asd = fisher_z_compare(r_se, len(sg), df_decoup.loc[(df_decoup["Definition"]=="OFC+IFG (Refined Frontal)") & (df_decoup["Pair"]=="Shannon_Frontal vs Global_Efficiency"), "r_ASD"].values[0], 687)
        subpath_rows.append({
            "Subgroup": path_name, "n": len(sg),
            "r_Shannon_Eff": round(r_se, 4), "CI_Shannon_Eff_low": round(l_se, 4), "CI_Shannon_Eff_high": round(h_se, 4),
            "r_Hurst_Eff": round(r_he, 4), "CI_Hurst_Eff_low": round(l_he, 4), "CI_Hurst_Eff_high": round(h_he, 4),
            "r_Shannon_Mod": round(r_sq, 4), "CI_Shannon_Mod_low": round(l_sq, 4), "CI_Shannon_Mod_high": round(h_sq, 4),
            "Fisher_z_vs_ASD_ShannonEff": round(z_vs_asd, 3), "P_vs_ASD": p_vs_asd,
        })
for sp_lbl, m_df_sub in [
    ("Mendeley restEO Only: ASD", df_ofc_ifg[(df_ofc_ifg["Source"] == "Mendeley Data") & (df_ofc_ifg["Is_RestEO"]) & (df_ofc_ifg["diagnostic_group"] == "ASD")]),
    ("Mendeley restEO Only: TD", df_ofc_ifg[(df_ofc_ifg["Source"] == "Mendeley Data") & (df_ofc_ifg["Is_RestEO"]) & (df_ofc_ifg["diagnostic_group"] == "TD")]),
]:
    sg = m_df_sub[["shannon", "hurst", "efficiency", "modularity"]].dropna()
    c = sg.corr()
    r_se, l_se, h_se = fisher_r_ci(c.loc["shannon", "efficiency"], len(sg))
    r_he, l_he, h_he = fisher_r_ci(c.loc["hurst", "efficiency"], len(sg))
    r_sq, l_sq, h_sq = fisher_r_ci(c.loc["shannon", "modularity"], len(sg))
    r_rest_asd = mend_rest_asd.corr().loc["shannon", "efficiency"]
    z_vs_rest_asd, p_vs_rest_asd = fisher_z_compare(r_se, len(sg), r_rest_asd, len(mend_rest_asd))
    subpath_rows.append({
        "Subgroup": sp_lbl, "n": len(sg),
        "r_Shannon_Eff": round(r_se, 4), "CI_Shannon_Eff_low": round(l_se, 4), "CI_Shannon_Eff_high": round(h_se, 4),
        "r_Hurst_Eff": round(r_he, 4), "CI_Hurst_Eff_low": round(l_he, 4), "CI_Hurst_Eff_high": round(h_he, 4),
        "r_Shannon_Mod": round(r_sq, 4), "CI_Shannon_Mod_low": round(l_sq, 4), "CI_Shannon_Mod_high": round(h_sq, 4),
        "Fisher_z_vs_ASD_ShannonEff": round(z_vs_rest_asd, 3), "P_vs_ASD": p_vs_rest_asd,
    })
# Also check Mendeley Data within-site ASD vs TD (n=589 vs 589, same acquisition protocol!)
mend_asd = df_ofc_ifg[(df_ofc_ifg["Source"] == "Mendeley Data") & (df_ofc_ifg["diagnostic_group"] == "ASD")][["shannon", "hurst", "efficiency", "modularity"]].dropna()
mend_td = df_ofc_ifg[(df_ofc_ifg["Source"] == "Mendeley Data") & (df_ofc_ifg["diagnostic_group"] == "TD")][["shannon", "hurst", "efficiency", "modularity"]].dropna()
print(f"  Within-site Mendeley (n_ASD={len(mend_asd)}, n_TD={len(mend_td)}):")
print(f"    ASD r(Shannon, Eff) = {mend_asd.corr().loc['shannon','efficiency']:.4f}, r(Hurst, Eff) = {mend_asd.corr().loc['hurst','efficiency']:.4f}")
print(f"    TD  r(Shannon, Eff) = {mend_td.corr().loc['shannon','efficiency']:.4f}, r(Hurst, Eff) = {mend_td.corr().loc['hurst','efficiency']:.4f}")
df_subpath = pd.DataFrame(subpath_rows)
df_subpath.to_csv(os.path.join(REPO_DATA_DIR, "Subpathology_MesoMacro_Coupling.csv"), index=False)

# Deficit domain & connectivity state stratification
def map_def_domain(dstr):
    if pd.isna(dstr):
        return "Unassigned"
    s = str(dstr)
    if "Conductas estereotipadas" in s:
        return "Stereotyped/Repetitive (c)"
    if "Comunicación (b),  Lenguaje (b)" in s or "Comunicación (b), Lenguaje (b)" in s:
        return "Communication/Language (b)"
    if "Repetitivo (c) / Lenguaje (b)" in s:
        return "Social + Repetitive + Language (a,b,c)"
    if "Repetitivo (c)" in s:
        return "Social + Repetitive (a,c)"
    if "Comunicación (b)" in s:
        return "Social + Communication (a,b)"
    return "Social Only (a)"

bio_clean_valid["def_domain"] = bio_clean_valid["def"].apply(map_def_domain)
def_summary = (
    bio_clean_valid.groupby(["diagnostic_group", "def_domain"], as_index=False)
    .agg(n_obs=("hurst", "count"), hurst_mean=("hurst", "mean"), hurst_sd=("hurst", "std"),
         shannon_mean=("shannon", "mean"), shannon_sd=("shannon", "std"),
         theta_mean=("theta", "mean"), ratio_at_mean=("ratio.at", "mean"))
)
def_summary.to_csv(os.path.join(REPO_DATA_DIR, "Deficit_Domain_Stratification.csv"), index=False)

conn_map = {
    "Hipo-conectivo (Estable)": "Hypoconnected (Stable)",
    "Híper-conectivo (Crítico)": "Hyperconnected (Critical)",
    "Hipoconectividad": "Hypoconnected",
    "Hiperconectividad": "Hyperconnected",
    "Mixta (hiper local / hipo larga)": "Mixed (Local Hyper / Long Hypo)",
}
bio_clean_valid["connectivity_profile"] = bio_clean_valid["conect"].map(lambda x: "Unassigned" if pd.isna(x) else conn_map.get(str(x), str(x)))
conect_summary = (
    bio_clean_valid.groupby(["diagnostic_group", "connectivity_profile"], as_index=False)
    .agg(n_obs=("hurst", "count"), hurst_mean=("hurst", "mean"), hurst_sd=("hurst", "std"),
         shannon_mean=("shannon", "mean"), shannon_sd=("shannon", "std"),
         node_weight_mean=("peso", "mean"))
)
conect_summary.to_csv(os.path.join(REPO_DATA_DIR, "Connectivity_Profile_Stratification.csv"), index=False)

# ---------------------------------------------------------------------------
# 7. SUPERVISED RANDOM FOREST: CONFUSION MATRIX, ROC-AUC, AND ABLATION BENCHMARKS
# ---------------------------------------------------------------------------
print("[7/8] Running Random Forest multiclass ROC-AUC, PR-AUC, and feature-ablation benchmarks...")

# 7A. Verify exact original RF confusion matrix from Session005 outputs & translate ROI labels cleanly
cm_csv = pd.read_csv(os.path.join(DATA_DIR, "Tabla_Confusion_Frecuencias.csv"))
met_csv = pd.read_csv(os.path.join(DATA_DIR, "Metricas_Diagnosticas_Por_Clase.csv"), index_col=0)
met_csv.index.name = "Diagnostic_Class"
imp_csv = pd.read_csv(os.path.join(DATA_DIR, "Tabla_Importancia_Biomarcadores.csv"))
pred_roi_map = {
    "`BG, SN, Th, PN (Subcorticales)_hurst_roi`": "BG/SN/Th/PN_hurst_roi",
    "`ACC (Cingulado Anterior) / SMA_sigma_roi`": "ACC/SMA_sigma_roi",
    "`ACC (Cingulado Anterior) / SMA_hurst_roi`": "ACC/SMA_hurst_roi",
    "`PPC (Corteza Parietal Post.)_sigma_roi`": "PPC_sigma_roi",
    "`A (Amígdala)_hurst_roi`": "Amygdala_hurst_roi",
    "`IFG (Giro Frontal Inferior)_hurst_roi`": "IFG_hurst_roi",
    "`PPC (Corteza Parietal Post.)_hurst_roi`": "PPC_hurst_roi",
    "`STS / FG (Giro Fusiforme)_hurst_roi`": "STS/FG_hurst_roi",
    "`OFC (Corteza Orbitofrontal)_shannon_roi`": "OFC_shannon_roi",
    "`OFC (Corteza Orbitofrontal)_hurst_roi`": "OFC_hurst_roi",
}
imp_csv["Predictor"] = imp_csv["Predictor"].map(lambda s: pred_roi_map.get(str(s), str(s).replace("`", "")))
met_csv.to_csv(os.path.join(TAB_DIR, "Table5_Original_RF_Class_Metrics.csv"))
imp_csv.to_csv(os.path.join(TAB_DIR, "Table6_Top15_Biomarker_Importance.csv"), index=False)

# 7B. Build clean leakage-free ML feature sets on N_valid = 4609 (excluding empty 225 non-ASD rows!)
# Also verify original 65-feature matrix from df_master_rds (with centrality dropped as constant)
wide_all = roi_subj.pivot(index="cod", columns="roi_clean", values=["theta", "sigma", "hurst", "shannon", "ratio_at", "node_weight"])
wide_all.columns = [f"{r}_{m}" for m, r in wide_all.columns]
wide_all = wide_all.merge(meta_all.set_index("cod")[["diagnostic_group", "Source"]], left_index=True, right_index=True)
wide_all = wide_all.merge(graf_clean.set_index("cod")[["mean_degree", "efficiency", "path_length", "modularity", "clustering"]], left_index=True, right_index=True)

# Note: restrict ML ablation features to the 5 universal ROIs (OFC, ACC/SMA, PPC, STS/FG, PN) + 5 numeric graph metrics
# so missing group-specific ROIs (IFG, Amygdala, BG/SN/Th) NEVER create artificial missingness leakage!
univ_feat_cols = [c for c in wide_univ.columns if c not in ["diagnostic_group", "Source", "Clinical_Stratum"]]
meso_cols = [c for c in univ_feat_cols if any(c.startswith(r + "_") for r in universal_rois)]
macro_cols = ["mean_degree", "efficiency", "path_length", "modularity", "clustering"]
nonlinear_cols = [c for c in meso_cols if c.endswith("_hurst") or c.endswith("_shannon")]
spectral_cols = [c for c in meso_cols if c.endswith("_theta") or c.endswith("_sigma") or c.endswith("_ratio_at")]

X_univ = wide_univ[meso_cols + macro_cols].copy()
y_univ = wide_univ["diagnostic_group"].values
classes = ["ASD", "non-ASD", "TD"]

X_tr, X_te, y_tr, y_te, idx_tr, idx_te = train_test_split(
    X_univ, y_univ, wide_univ.index, test_size=0.20, stratify=y_univ, random_state=42
)

# Down-sampled Random Forest matching Session005 strategy (balanced training set inside each fit / ensemble)
def fit_balanced_rf(X_train, y_train, X_test, cols, target_order=("ASD", "non-ASD", "TD"), n_estimators=600, random_state=42):
    rf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_features=min(15, len(cols)),
        class_weight="balanced_subsample",
        random_state=random_state,
        n_jobs=-1,
    )
    rf.fit(X_train[cols], y_train)
    raw_probs = rf.predict_proba(X_test[cols])
    # Explicitly align probability columns to target_order (ASCII sorting puts 'TD' before 'non-ASD')
    idx_map = [list(rf.classes_).index(c) for c in target_order]
    probs = raw_probs[:, idx_map]
    preds = rf.predict(X_test[cols])
    return rf, preds, probs

ablation_configs = [
    ("Full Hybrid (Meso + Macro, 5 Universal ROIs)", meso_cols + macro_cols),
    ("Mesoscale Only (Nonlinear + Spectral)", meso_cols),
    ("Nonlinear Complexity Only (Hurst + Shannon)", nonlinear_cols),
    ("Spectral Power Only (Theta + Sigma + Ratio A/T)", spectral_cols),
    ("Macroscale Graph Topology Only", macro_cols),
]

ablation_rows = []
roc_curves_store = {}

y_te_bin = label_binarize(y_te, classes=classes)

for name, cols in ablation_configs:
    rf_mod, preds, probs = fit_balanced_rf(X_tr, y_tr, X_te, cols)
    acc = accuracy_score(y_te, preds)
    kap = cohen_kappa_score(y_te, preds)
    mac_f1 = f1_score(y_te, preds, average="macro")
    macro_auc = roc_auc_score(y_te_bin, probs, average="macro", multi_class="ovr")

    # Pairwise AUC: ASD vs TD and ASD vs non-ASD
    mask_at = np.isin(y_te, ["ASD", "TD"])
    p_asd_vs_td = probs[mask_at, 0] / (probs[mask_at, 0] + probs[mask_at, 2] + 1e-12)
    auc_asd_td = roc_auc_score((y_te[mask_at] == "ASD").astype(int), p_asd_vs_td)

    mask_an = np.isin(y_te, ["ASD", "non-ASD"])
    p_asd_vs_non = probs[mask_an, 0] / (probs[mask_an, 0] + probs[mask_an, 1] + 1e-12)
    auc_asd_non = roc_auc_score((y_te[mask_an] == "ASD").astype(int), p_asd_vs_non)

    # Class-wise F1
    _, _, f1_cls, _ = precision_recall_fscore_support(y_te, preds, labels=classes, zero_division=0)

    ablation_rows.append({
        "Model_Configuration": name,
        "N_Features": len(cols),
        "Accuracy": round(acc, 4),
        "Kappa": round(kap, 4),
        "Macro_F1": round(mac_f1, 4),
        "Macro_OVR_AUC": round(macro_auc, 4),
        "AUC_ASD_vs_TD": round(auc_asd_td, 4),
        "AUC_ASD_vs_nonASD": round(auc_asd_non, 4),
        "F1_ASD": round(f1_cls[0], 4),
        "F1_nonASD": round(f1_cls[1], 4),
        "F1_TD": round(f1_cls[2], 4),
    })

    if name.startswith("Full Hybrid"):
        # Save detailed ROC curves for Figure 5
        fpr_at, tpr_at, _ = roc_curve((y_te[mask_at] == "ASD").astype(int), p_asd_vs_td)
        fpr_an, tpr_an, _ = roc_curve((y_te[mask_an] == "ASD").astype(int), p_asd_vs_non)
        fpr_asd_ovr, tpr_asd_ovr, _ = roc_curve(y_te_bin[:, 0], probs[:, 0])
        fpr_non_ovr, tpr_non_ovr, _ = roc_curve(y_te_bin[:, 1], probs[:, 1])
        fpr_td_ovr, tpr_td_ovr, _ = roc_curve(y_te_bin[:, 2], probs[:, 2])
        roc_curves_store["Full_Hybrid"] = {
            "ASD_vs_TD": (fpr_at.tolist(), tpr_at.tolist(), float(auc_asd_td)),
            "ASD_vs_nonASD": (fpr_an.tolist(), tpr_an.tolist(), float(auc_asd_non)),
            "ASD_OVR": (fpr_asd_ovr.tolist(), tpr_asd_ovr.tolist(), float(roc_auc_score(y_te_bin[:, 0], probs[:, 0]))),
            "nonASD_OVR": (fpr_non_ovr.tolist(), tpr_non_ovr.tolist(), float(roc_auc_score(y_te_bin[:, 1], probs[:, 1]))),
            "TD_OVR": (fpr_td_ovr.tolist(), tpr_td_ovr.tolist(), float(roc_auc_score(y_te_bin[:, 2], probs[:, 2]))),
            "CM": confusion_matrix(y_te, preds, labels=classes).tolist(),
        }

# Also test ComBat-harmonized train-only fit (zero leakage) on the 5 Universal ROIs + Macro
batch_tr = wide_univ.loc[idx_tr, "Source"]
batch_te = wide_univ.loc[idx_te, "Source"]
# Fit ComBat on full matrix vs evaluate on shared-site subset (Mendeley Data + ORDA + figshare + ds006777)
shared_sources = ["Mendeley Data", "ORDA", "figshare", "OpenNeuro ds006777", "OpenNeuro ds006780", "OpenNeuro ds004504", "OpenNeuro ds004584"]
mask_shared = wide_univ["Source"].isin(shared_sources)
wu_shared = wide_univ[mask_shared].copy()
X_s = wu_shared[meso_cols + macro_cols]
y_s = wu_shared["diagnostic_group"].values
Xs_tr, Xs_te, ys_tr, ys_te = train_test_split(X_s, y_s, test_size=0.20, stratify=y_s, random_state=42)
_, preds_s, probs_s = fit_balanced_rf(Xs_tr, ys_tr, Xs_te, meso_cols + macro_cols)
ys_te_bin = label_binarize(ys_te, classes=classes)
m_at_s = np.isin(ys_te, ["ASD", "TD"])
m_an_s = np.isin(ys_te, ["ASD", "non-ASD"])
ablation_rows.append({
    "Model_Configuration": "Multi-Group Repositories Only (Sensitivity Check, n=1905)",
    "N_Features": len(meso_cols + macro_cols),
    "Accuracy": round(accuracy_score(ys_te, preds_s), 4),
    "Kappa": round(cohen_kappa_score(ys_te, preds_s), 4),
    "Macro_F1": round(f1_score(ys_te, preds_s, average="macro"), 4),
    "Macro_OVR_AUC": round(roc_auc_score(ys_te_bin, probs_s, average="macro", multi_class="ovr"), 4),
    "AUC_ASD_vs_TD": round(roc_auc_score((ys_te[m_at_s] == "ASD").astype(int), probs_s[m_at_s, 0] / (probs_s[m_at_s, 0] + probs_s[m_at_s, 2] + 1e-12)), 4),
    "AUC_ASD_vs_nonASD": round(roc_auc_score((ys_te[m_an_s] == "ASD").astype(int), probs_s[m_an_s, 0] / (probs_s[m_an_s, 0] + probs_s[m_an_s, 1] + 1e-12)), 4),
    "F1_ASD": round(precision_recall_fscore_support(ys_te, preds_s, labels=classes, zero_division=0)[2][0], 4),
    "F1_nonASD": round(precision_recall_fscore_support(ys_te, preds_s, labels=classes, zero_division=0)[2][1], 4),
    "F1_TD": round(precision_recall_fscore_support(ys_te, preds_s, labels=classes, zero_division=0)[2][2], 4),
})

# Bio-Participant-Disjoint Split (zero overlap of unique biological participants between train and test)
bio_groups_univ = wide_univ.index.to_series().map(meta_all.drop_duplicates("cod").set_index("cod")["Bio_Participant"]).values
sgkf_bio = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=42)
tr_b_idx, te_b_idx = next(sgkf_bio.split(X_univ, y_univ, bio_groups_univ))
assert len(set(bio_groups_univ[tr_b_idx]).intersection(set(bio_groups_univ[te_b_idx]))) == 0
_, preds_b, probs_b = fit_balanced_rf(X_univ.iloc[tr_b_idx], y_univ[tr_b_idx], X_univ.iloc[te_b_idx], meso_cols + macro_cols)
y_b_te = y_univ[te_b_idx]
y_b_te_bin = label_binarize(y_b_te, classes=classes)
m_at_b = np.isin(y_b_te, ["ASD", "TD"])
m_an_b = np.isin(y_b_te, ["ASD", "non-ASD"])
n_unseen_bio = len(set(bio_groups_univ[te_b_idx]))
ablation_rows.append({
    "Model_Configuration": f"Bio-Participant-Disjoint Split ({n_unseen_bio} Unseen Bio-Participants, n={len(te_b_idx)})",
    "N_Features": len(meso_cols + macro_cols),
    "Accuracy": round(accuracy_score(y_b_te, preds_b), 4),
    "Kappa": round(cohen_kappa_score(y_b_te, preds_b), 4),
    "Macro_F1": round(f1_score(y_b_te, preds_b, average="macro"), 4),
    "Macro_OVR_AUC": round(roc_auc_score(y_b_te_bin, probs_b, average="macro", multi_class="ovr"), 4),
    "AUC_ASD_vs_TD": round(roc_auc_score((y_b_te[m_at_b] == "ASD").astype(int), probs_b[m_at_b, 0] / (probs_b[m_at_b, 0] + probs_b[m_at_b, 2] + 1e-12)), 4),
    "AUC_ASD_vs_nonASD": round(roc_auc_score((y_b_te[m_an_b] == "ASD").astype(int), probs_b[m_an_b, 0] / (probs_b[m_an_b, 0] + probs_b[m_an_b, 1] + 1e-12)), 4),
    "F1_ASD": round(precision_recall_fscore_support(y_b_te, preds_b, labels=classes, zero_division=0)[2][0], 4),
    "F1_nonASD": round(precision_recall_fscore_support(y_b_te, preds_b, labels=classes, zero_division=0)[2][1], 4),
    "F1_TD": round(precision_recall_fscore_support(y_b_te, preds_b, labels=classes, zero_division=0)[2][2], 4),
})

# Also evaluate exact 65-feature df_master_rds reproduction in Python (to extract ROC-AUC on original 65 predictors)
df_rds_ml = df_master_rds.drop(columns=["cod", "centrality"]).copy()
for c in ["midgrade", "efficiency", "long", "modularity", "clustering"]:
    df_rds_ml[c] = pd.to_numeric(df_rds_ml[c], errors="coerce")
df_rds_ml = df_rds_ml.fillna(df_rds_ml.median(numeric_only=True))
X_orig = df_rds_ml.drop(columns=["grupo_diagnostico"])
y_orig = df_rds_ml["grupo_diagnostico"].astype(str).values
Xo_tr, Xo_te, yo_tr, yo_te = train_test_split(X_orig, y_orig, test_size=0.20, stratify=y_orig, random_state=42)
_, preds_o, probs_o = fit_balanced_rf(Xo_tr, yo_tr, Xo_te, X_orig.columns.tolist())
yo_te_bin = label_binarize(yo_te, classes=classes)
m_at_o = np.isin(yo_te, ["ASD", "TD"])
m_an_o = np.isin(yo_te, ["ASD", "non-ASD"])
ablation_rows.insert(0, {
    "Model_Configuration": "Original Full 65-Feature Matrix (N=4834, Session005)",
    "N_Features": X_orig.shape[1],
    "Accuracy": round(accuracy_score(yo_te, preds_o), 4),
    "Kappa": round(cohen_kappa_score(yo_te, preds_o), 4),
    "Macro_F1": round(f1_score(yo_te, preds_o, average="macro"), 4),
    "Macro_OVR_AUC": round(roc_auc_score(yo_te_bin, probs_o, average="macro", multi_class="ovr"), 4),
    "AUC_ASD_vs_TD": round(roc_auc_score((yo_te[m_at_o] == "ASD").astype(int), probs_o[m_at_o, 0] / (probs_o[m_at_o, 0] + probs_o[m_at_o, 2] + 1e-12)), 4),
    "AUC_ASD_vs_nonASD": round(roc_auc_score((yo_te[m_an_o] == "ASD").astype(int), probs_o[m_an_o, 0] / (probs_o[m_an_o, 0] + probs_o[m_an_o, 1] + 1e-12)), 4),
    "F1_ASD": round(precision_recall_fscore_support(yo_te, preds_o, labels=classes, zero_division=0)[2][0], 4),
    "F1_nonASD": round(precision_recall_fscore_support(yo_te, preds_o, labels=classes, zero_division=0)[2][1], 4),
    "F1_TD": round(precision_recall_fscore_support(yo_te, preds_o, labels=classes, zero_division=0)[2][2], 4),
})

df_ablation = pd.DataFrame(ablation_rows)
df_ablation.to_csv(os.path.join(TAB_DIR, "Table5B_RF_Feature_Ablation_and_ROC.csv"), index=False)
df_ablation.to_csv(os.path.join(TAB_DIR, "Table6_RF_Classification_and_Ablation.csv"), index=False)
print(df_ablation[["Model_Configuration", "N_Features", "Accuracy", "Macro_F1", "Macro_OVR_AUC", "AUC_ASD_vs_nonASD"]].to_string(index=False))

# ---------------------------------------------------------------------------
# 8. PRIOR-PREDICTIVE BIOPHYSICAL SUMMARY & EXPORT CLEAN DATA SUMMARIES FOR FIGURES
# ---------------------------------------------------------------------------
print("[8/8] Computing prior-predictive biophysical summary & exporting figure intermediates...")
roi_summary = (
    roi_subj.groupby(["diagnostic_group", "roi_clean"], as_index=False, observed=True)
    .agg(
        n=("hurst", "count"),
        hurst_mean=("hurst", "mean"), hurst_sd=("hurst", "std"),
        shannon_mean=("shannon", "mean"), shannon_sd=("shannon", "std"),
        theta_mean=("theta", "mean"), theta_sd=("theta", "std"),
        sigma_mean=("sigma", "mean"), sigma_sd=("sigma", "std"),
        ratio_at_mean=("ratio_at", "mean"), ratio_at_sd=("ratio_at", "std"),
    )
)
roi_summary["hurst_se"] = roi_summary["hurst_sd"] / np.sqrt(roi_summary["n"])
roi_summary["shannon_se"] = roi_summary["shannon_sd"] / np.sqrt(roi_summary["n"])
roi_summary["fractal_D_mean"] = 2.0 - roi_summary["hurst_mean"]
roi_summary.to_csv(os.path.join(REPO_DATA_DIR, "ROI_Descriptive_Summary.csv"), index=False)

graph_summary = (
    graf_clean.merge(meta_all[["cod", "diagnostic_group"]], on="cod")
    .groupby("diagnostic_group", as_index=False)[["mean_degree", "efficiency", "path_length", "modularity", "clustering"]]
    .agg(["mean", "std", "median"])
)
graph_summary.to_csv(os.path.join(REPO_DATA_DIR, "Graph_Topology_Summary.csv"))

# Save clean English frontal subject-level data & ROC curves JSON for Figure script
df_ofc_ifg.drop(columns=["cod"]).to_csv(os.path.join(REPO_DATA_DIR, "Frontal_OFC_IFG_Subject_Level.csv"), index=False)
df_ofc.drop(columns=["cod"]).to_csv(os.path.join(REPO_DATA_DIR, "Frontal_OFC_Subject_Level.csv"), index=False)
roi_subj.drop(columns=["cod"]).to_csv(os.path.join(REPO_DATA_DIR, "ROI_Subject_Level_Clean.csv"), index=False)

with open(os.path.join(REPO_DATA_DIR, "roc_curves.json"), "w") as f:
    json.dump(roc_curves_store, f)

# Save global biophysical summary check
prior_check = []
for g in ["ASD", "TD", "non-ASD"]:
    sub = df_ofc_ifg[df_ofc_ifg["diagnostic_group"] == g]
    h = sub["hurst"].dropna()
    d_val = 2.0 - h
    s = sub["shannon"].dropna()
    e = sub["efficiency"].dropna()
    q = sub["modularity"].dropna()
    prior_check.append({
        "Group": g, "n": len(sub),
        "H_frontal_mean": round(h.mean(), 4), "H_frontal_sd": round(h.std(), 4),
        "H_in_SOC_band_0.7_0.8_pct": round(((h >= 0.70) & (h <= 0.80)).mean() * 100, 2),
        "H_subcritical_lt0.65_pct": round((h < 0.65).mean() * 100, 2),
        "H_hyperpersistent_gt0.80_pct": round((h > 0.80).mean() * 100, 2),
        "Fractal_D_mean": round(d_val.mean(), 4), "Fractal_D_sd": round(d_val.std(), 4),
        "Shannon_frontal_mean": round(s.mean(), 4), "Shannon_frontal_sd": round(s.std(), 4),
        "Efficiency_mean": round(e.mean(), 4), "Efficiency_sd": round(e.std(), 4),
        "Modularity_mean": round(q.mean(), 4), "Modularity_sd": round(q.std(), 4),
    })
df_prior = pd.DataFrame(prior_check)
df_prior.to_csv(os.path.join(REPO_DATA_DIR, "Prior_Predictive_Biophysical_Check.csv"), index=False)
print("  Prior-predictive biophysical summary:")
print(df_prior.to_string(index=False))
print("\n[DONE] All statistical validations and summary exports finished successfully!")
