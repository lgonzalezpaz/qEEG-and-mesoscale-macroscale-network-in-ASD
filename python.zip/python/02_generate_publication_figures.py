"""
02_generate_publication_figures.py
===================================
Generates six publication-quality multi-panel figures (PDF vector + 600 DPI PNG)
with Okabe-Ito colorblind-safe palettes, distinct grayscale-legible markers/linestyles,
and verified quantitative annotations for the Nature-style manuscript.

Author: Orchestrator Argon Pipeline (paper40)
"""

import os
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Circle, Polygon
from scipy import stats

# ---------------------------------------------------------------------------
# GLOBAL PUBLICATION STYLE
# ---------------------------------------------------------------------------
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "DejaVu Sans", "Helvetica"],
    "font.size": 8.5,
    "axes.titlesize": 9.5,
    "axes.titleweight": "bold",
    "axes.labelsize": 8.5,
    "xtick.labelsize": 7.8,
    "ytick.labelsize": 7.8,
    "legend.fontsize": 7.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 0.8,
    "xtick.major.width": 0.8,
    "ytick.major.width": 0.8,
    "savefig.dpi": 600,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

# Colorblind-safe Okabe-Ito group styling
COLORS = {
    "ASD": "#D55E00",      # Vermilion
    "TD": "#0072B2",       # Blue
    "non-ASD": "#009E73",  # Bluish green
    "Neutral": "#4D4D4D",
    "Accent": "#E69F00",   # Orange
    "Purple": "#CC79A7",
    "Sky": "#56B4E9",
}
MARKERS = {"ASD": "o", "TD": "s", "non-ASD": "^"}
LINESTYLES = {"ASD": "-", "TD": "--", "non-ASD": "-."}

BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
ORIG_DIR = os.path.join(os.path.dirname(BASE_DIR), "Directorio 20260518")
TAB_DIR = os.path.join(BASE_DIR, "Tables")
DATA_DIR = os.path.join(BASE_DIR, "GitHub_Zenodo_Repository", "data_summary")
FIG_DIR = os.path.join(BASE_DIR, "Figures")
os.makedirs(FIG_DIR, exist_ok=True)


def add_panel_label(ax, letter, x=-0.14, y=1.08):
    ax.text(
        x, y, letter, transform=ax.transAxes,
        fontsize=11.5, fontweight="bold", va="top", ha="left", color="black"
    )


def save_fig(fig, stem):
    fig.savefig(os.path.join(FIG_DIR, f"{stem}.pdf"), bbox_inches="tight", facecolor="white")
    fig.savefig(os.path.join(FIG_DIR, f"{stem}.png"), dpi=600, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  Saved {stem}.pdf and {stem}.png")


def clean_var_label(raw):
    s = str(raw).replace("`", "")
    repl = [
        ("ACC (Cingulado Anterior) / SMA", "ACC/SMA"),
        ("BG, SN, Th, PN (Subcorticales)", "BG/SN/Th/PN"),
        ("IFG (Giro Frontal Inferior)", "IFG"),
        ("OFC (Corteza Orbitofrontal)", "OFC"),
        ("PPC (Corteza Parietal Post.)", "PPC"),
        ("STS / FG (Giro Fusiforme)", "STS/FG"),
        ("A (Amígdala)", "Amygdala"),
        ("_shannon_roi", " Shannon"),
        ("_hurst_roi", " Hurst"),
        ("_theta_roi", " Theta"),
        ("_sigma_roi", " Sigma"),
        ("_ratio.at_roi", " Alpha/Theta"),
        ("_node_weight_roi", " Weight"),
        ("_peso_roi", " Weight"),
        ("_shannon", " Shannon"),
        ("_hurst", " Hurst"),
        ("_theta", " Theta"),
        ("_sigma", " Sigma"),
        ("efficiency", "Global Eff. (E_glob)"),
        ("modularity", "Modularity (Q)"),
        ("clustering", "Clustering (C)"),
        ("mean_degree", "Mean Degree"),
        ("midgrade", "Mean Degree"),
    ]
    for old, new in repl:
        s = s.replace(old, new)
    if s.startswith("NA "):
        s = "Missing-ROI " + s[3:] + " [Artifact]"
    elif s.startswith("nan "):
        s = "Unassigned " + s[4:] + " [Artifact]"
    return s.strip()


# ===========================================================================
# FIGURE 1: COHORT ARCHITECTURE, COMBAT HARMONIZATION & HUB SHIFT
# ===========================================================================
def make_fig1():
    print("Generating Figure 1...")
    t1 = pd.read_csv(os.path.join(TAB_DIR, "Table1_Cohort_Repository_Summary.csv"))
    icc = pd.read_csv(os.path.join(DATA_DIR, "ICC_Pre_vs_Post_ComBat.csv"))
    hub_pct = pd.read_csv(os.path.join(DATA_DIR, "Centrality_Hub_Percentages.csv")).set_index("diagnostic_group")

    fig = plt.figure(figsize=(13.5, 9.2))
    gs = gridspec.GridSpec(2, 2, height_ratios=[1.15, 1.05], width_ratios=[1.18, 1.0], hspace=0.38, wspace=0.34)

    # Panel A: Repository Cohort Composition
    ax_a = fig.add_subplot(gs[0, 0])
    t1["label"] = t1.apply(lambda r: f"{r['Source']} ({r['Clinical_Stratum'].split('(')[0].strip()})"
                           if r["diagnostic_group"] == "non-ASD"
                           else f"{r['Source']} [{r['diagnostic_group']}]", axis=1)
    # Order nicely by diagnostic group then valid_records
    grp_order = {"TD": 0, "ASD": 1, "non-ASD": 2}
    t1["g_ord"] = t1["diagnostic_group"].map(grp_order)
    t1 = t1.sort_values(["g_ord", "total_records"], ascending=[False, True]).reset_index(drop=True)

    y_pos = np.arange(len(t1))
    bar_colors = [COLORS[g] for g in t1["diagnostic_group"]]
    ax_a.barh(y_pos, t1["valid_records"], color=bar_colors, edgecolor="black", linewidth=0.5, alpha=0.9, label="Valid channels")
    # Plot empty rows stacked where empty_records > 0
    empty_mask = t1["empty_records"] > 0
    if empty_mask.any():
        ax_a.barh(
            y_pos[empty_mask], t1.loc[empty_mask, "empty_records"],
            left=t1.loc[empty_mask, "valid_records"],
            color="#CCCCCC", edgecolor="black", linewidth=0.5, hatch="///",
            label="Empty channel records (ds003555)"
        )
    ax_a.set_yticks(y_pos)
    ax_a.set_yticklabels(t1["label"], fontsize=7.0)
    ax_a.set_xlabel("Subject-level EEG recordings (n) & unique biological participants")
    ax_a.set_xlim(0, t1["total_records"].max() * 1.44)
    ax_a.set_title("Multi-repository cohort (4,834 records; 4,609 valid; 2,569 bio-subjects)")
    for i, row in t1.iterrows():
        n_bio_v = int(row["unique_bio_participants_valid"]) if "unique_bio_participants_valid" in t1.columns else int(row["valid_records"])
        if row["empty_records"] > 0:
            txt = f"{row['valid_records']} rec (+{row['empty_records']} empty) / {n_bio_v} subj"
        else:
            txt = f"{row['valid_records']} rec / {n_bio_v} subj"
        ax_a.text(row["total_records"] + 25, i, txt, va="center", ha="left", fontsize=6.6, fontweight="bold" if row["diagnostic_group"] == "ASD" else "normal")
    # Custom legend for groups
    from matplotlib.patches import Patch
    leg_handles = [
        Patch(facecolor=COLORS["TD"], edgecolor="black", linewidth=0.5, label="TD (n = 2,953 rec / 2,198 bio-subj)"),
        Patch(facecolor=COLORS["ASD"], edgecolor="black", linewidth=0.5, label="ASD (n = 702 rec / 144 bio-subj)"),
        Patch(facecolor=COLORS["non-ASD"], edgecolor="black", linewidth=0.5, label="non-ASD (n = 954 valid rec / 227 bio-subj)"),
        Patch(facecolor="#CCCCCC", edgecolor="black", linewidth=0.5, hatch="///", label="Excluded all-NaN rows (n = 225)"),
    ]
    ax_a.legend(handles=leg_handles, loc="lower right", frameon=True, framealpha=0.92, fontsize=6.9)
    ax_a.grid(axis="x", alpha=0.25)
    add_panel_label(ax_a, "A", x=-0.34, y=1.06)

    # Panel B: Pre- vs Post-ComBat Site Variance (ICC)
    ax_b = fig.add_subplot(gs[0, 1])
    icc_plot = icc.sort_values("ICC_Pre_Harmonization", ascending=True).reset_index(drop=True)
    y_icc = np.arange(len(icc_plot))
    for i, row in icc_plot.iterrows():
        ax_b.plot([row["ICC_Post_ComBat"], row["ICC_Pre_Harmonization"]], [i, i], color="#888888", lw=1.4, zorder=1)
    ax_b.scatter(icc_plot["ICC_Pre_Harmonization"], y_icc, color="#D55E00", marker="o", s=48, zorder=3, edgecolor="black", lw=0.5, label="Pre-ComBat site ICC")
    ax_b.scatter(icc_plot["ICC_Post_ComBat"], y_icc, color="#0072B2", marker="s", s=46, zorder=4, edgecolor="black", lw=0.5, label="Post-ComBat site ICC")
    ax_b.set_yticks(y_icc)
    ax_b.set_yticklabels([clean_var_label(f) for f in icc_plot["Feature"]], fontsize=7.5)
    ax_b.set_xlabel("Site-level Intraclass Correlation Coefficient (ICC)")
    ax_b.set_xlim(-0.04, 0.96)
    ax_b.set_title("Empirical Bayes ComBat site harmonization")
    mean_pre = icc["ICC_Pre_Harmonization"].mean()
    mean_post = icc["ICC_Post_ComBat"].mean()
    ax_b.axvline(mean_pre, color="#D55E00", ls=":", lw=1.1, alpha=0.8)
    ax_b.axvline(mean_post, color="#0072B2", ls=":", lw=1.1, alpha=0.8)
    ax_b.text(0.54, 1.4, f"Mean ICC:\n{mean_pre:.4f} -> {mean_post:.4f}", fontsize=7.4, bbox=dict(boxstyle="round,pad=0.3", fc="#F7F7F7", ec="#BBBBBB"))
    ax_b.legend(loc="lower right", frameon=True, framealpha=0.92, fontsize=7.2)
    ax_b.grid(axis="x", alpha=0.25)
    add_panel_label(ax_b, "B", x=-0.26, y=1.06)

    # Panel C: 10-20 Scalp Topological Hub Shift (Three-head grid in bottom row)
    gs_c = gridspec.GridSpecFromSubplotSpec(1, 3, subplot_spec=gs[1, :], wspace=0.18)
    # Standard 2D normalized 10-20 coordinates (nose up at +1)
    coords_1020 = {
        "Fp1": (-0.31, 0.88), "Fp2": (0.31, 0.88),
        "F7": (-0.78, 0.50),  "F3": (-0.38, 0.45), "Fz": (0.0, 0.43),  "F4": (0.38, 0.45), "F8": (0.78, 0.50),
        "T7": (-0.93, 0.00),  "C3": (-0.45, 0.00), "Cz": (0.0, 0.00),  "C4": (0.45, 0.00), "T8": (0.93, 0.00),
        "P7": (-0.78, -0.50), "P3": (-0.38, -0.45),"Pz": (0.0, -0.43), "P4": (0.38, -0.45),"P8": (0.78, -0.50),
        "O1": (-0.31, -0.88), "O2": (0.31, -0.88),
    }

    cmap = plt.cm.YlOrRd
    norm = matplotlib.colors.Normalize(vmin=0, vmax=65)
    group_specs = [
        ("ASD", "ASD (n = 702)\nF7 + F8 = 88.03% lateral frontal hub"),
        ("TD", "TD (n = 2,953)\nFp1 = 26.76%, F7 + F8 = 24.75%"),
        ("non-ASD", "non-ASD (n = 954)\nP3 = 24.00%, Fp1 = 20.13%, F7 + F8 = 7.02%"),
    ]

    for idx_g, (grp, subtitle) in enumerate(group_specs):
        ax_h = fig.add_subplot(gs_c[0, idx_g])
        # Draw head circle, nose, and ears
        head = Circle((0, 0), 1.0, facecolor="#FAFAFA", edgecolor="#222222", lw=1.4, zorder=1)
        ax_h.add_patch(head)
        nose = Polygon([[-0.12, 0.99], [0.0, 1.13], [0.12, 0.99]], closed=True, facecolor="#FAFAFA", edgecolor="#222222", lw=1.3, zorder=1)
        ax_h.add_patch(nose)
        ear_l = Polygon([[-1.0, 0.14], [-1.09, 0.08], [-1.09, -0.08], [-1.0, -0.14]], closed=True, facecolor="#F0F0F0", edgecolor="#222222", lw=1.1, zorder=0)
        ear_r = Polygon([[1.0, 0.14], [1.09, 0.08], [1.09, -0.08], [1.0, -0.14]], closed=True, facecolor="#F0F0F0", edgecolor="#222222", lw=1.1, zorder=0)
        ax_h.add_patch(ear_l)
        ax_h.add_patch(ear_r)

        # Plot electrodes
        row_pct = hub_pct.loc[grp]
        for elec, (ex, ey) in coords_1020.items():
            val = float(row_pct[elec]) if elec in row_pct.index else 0.0
            size = 55 + val * 14.0
            col = cmap(norm(val)) if val > 0.0 else "#E8E8E8"
            ew = 1.6 if elec in ["F7", "F8"] and grp == "ASD" else 0.7
            ec = COLORS[grp] if (elec in ["F7", "F8"] and grp == "ASD") else "#222222"
            ax_h.scatter(ex, ey, s=size, color=col, edgecolor=ec, linewidth=ew, zorder=3)
            # Label high-frequency hubs or key landmarks cleanly
            if val >= 8.0:
                dy = -0.22 if val >= 30.0 else (-0.18 if ey >= 0 else -0.17)
                ax_h.text(ex, ey + dy, f"{elec}\n{val:.1f}%", ha="center", va="top", fontsize=6.5, fontweight="bold",
                          color="#111111", zorder=5, bbox=dict(boxstyle="round,pad=0.10", fc="white", ec="none", alpha=0.82))
            elif elec in ["F7", "F8", "Fp1", "P3", "Fz", "Cz", "Pz"]:
                ax_h.text(ex, ey, elec, ha="center", va="center", fontsize=5.8, color="#333333", zorder=4)

        ax_h.set_xlim(-1.22, 1.22)
        ax_h.set_ylim(-1.18, 1.22)
        ax_h.set_aspect("equal")
        ax_h.axis("off")
        ax_h.set_title(subtitle, fontsize=8.4, fontweight="bold", color=COLORS[grp], pad=4)
        if idx_g == 0:
            add_panel_label(ax_h, "C", x=-0.10, y=1.08)

    # Shared colorbar below Panel C
    sm_cb = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm_cb.set_array([])
    cbar_ax = fig.add_axes([0.33, 0.055, 0.36, 0.016])
    cbar = fig.colorbar(sm_cb, cax=cbar_ax, orientation="horizontal")
    cbar.set_label("Percentage of subjects whose maximum betweenness centrality node occurs at electrode (%)", fontsize=7.8)

    save_fig(fig, "Fig1_Study_Architecture_and_Cohort_Harmonization")


# ===========================================================================
# FIGURE 2: UNSUPERVISED PCA & HCPC PHENOTYPE CLUSTERING
# ===========================================================================
def make_fig2():
    print("Generating Figure 2...")
    eig = pd.read_csv(os.path.join(ORIG_DIR, "PCA_Valores_Propios_Varianza.csv"))
    contrib = pd.read_csv(os.path.join(ORIG_DIR, "PCA_Tabla_Contribucion_Variables.csv"))
    hcpc = pd.read_csv(os.path.join(TAB_DIR, "Table2_HCPC_Cluster_Contingency.csv")).set_index("Diagnostic_Group").T
    hcpc.index = hcpc.index.astype(int)

    fig, axes = plt.subplots(1, 3, figsize=(15.6, 4.7), gridspec_kw={"width_ratios": [1.0, 1.05, 1.05], "wspace": 0.65})

    # Panel A: PCA Scree Plot (First 15 PCs)
    ax = axes[0]
    top_n = 15
    e15 = eig.iloc[:top_n].copy()
    dims = np.arange(1, top_n + 1)
    bars = ax.bar(dims, e15["percentage of variance"], color="#56B4E9", edgecolor="black", linewidth=0.5, alpha=0.85, label="Individual PC variance")
    ax.set_xlabel("Principal component")
    ax.set_ylabel("Variance explained (%)", color="#005580")
    ax.set_xticks(dims)
    ax.set_ylim(0, 20)
    ax2 = ax.twinx()
    ax2.spines["top"].set_visible(False)
    ax2.plot(dims, e15["cumulative percentage of variance"], color="#D55E00", marker="o", ms=4.2, lw=1.6, label="Cumulative variance")
    ax2.axhline(80.0, color="#666666", ls="--", lw=0.9)
    ax2.text(10.5, 81.8, "80% threshold", fontsize=7.0, color="#444444")
    ax2.set_ylabel("Cumulative variance (%)", color="#D55E00")
    ax2.set_ylim(0, 102)
    ax.set_title("PCA eigenvalue spectrum (65 variables)")
    ax.text(1.5, 17.5, f"PC1+PC2 = {e15.loc[1, 'cumulative percentage of variance']:.1f}%\n13 PCs eig > 1 ({e15.loc[12, 'cumulative percentage of variance']:.1f}%)",
            fontsize=7.2, bbox=dict(boxstyle="round,pad=0.3", fc="#F7F7F7", ec="#CCCCCC"))
    add_panel_label(ax, "A", x=-0.16, y=1.10)

    # Panel B: Top 15 Contributors to PC1 & PC2
    ax = axes[1]
    c_top = contrib.sort_values("Dim.1", ascending=True).tail(15).copy()
    y_c = np.arange(len(c_top))
    h = 0.38
    ax.barh(y_c + h / 2, c_top["Dim.1"], height=h, color="#0072B2", edgecolor="black", lw=0.4, label="PC1 (15.96%)")
    ax.barh(y_c - h / 2, c_top["Dim.2"], height=h, color="#E69F00", edgecolor="black", lw=0.4, hatch="///", label="PC2 (15.36%)")
    ax.axvline(100.0 / 65.0, color="#333333", ls=":", lw=1.0, label="Uniform expectation (1.54%)")
    ax.set_yticks(y_c)
    ax.set_yticklabels([clean_var_label(v) for v in c_top["Variable"]], fontsize=7.1)
    ax.set_xlabel("Variable contribution (%)")
    ax.set_xlim(0, 9.0)
    ax.set_title("Top 15 biophysical & graph loadings")
    ax.legend(loc="lower right", fontsize=6.8, framealpha=0.92)
    ax.grid(axis="x", alpha=0.25)
    add_panel_label(ax, "B", x=-0.42, y=1.10)

    # Panel C: HCPC 7-Cluster Composition by Diagnostic Group
    ax = axes[2]
    clusters = hcpc.index.tolist()
    pct_df = hcpc[["ASD", "TD", "non-ASD"]].div(hcpc[["ASD", "TD", "non-ASD"]].sum(axis=1), axis=0) * 100.0
    x_cl = np.arange(len(clusters))
    bottom = np.zeros(len(clusters))
    for grp, hatch in [("ASD", "///"), ("TD", ""), ("non-ASD", "...")]:
        vals = pct_df[grp].values
        ax.bar(x_cl, vals, bottom=bottom, color=COLORS[grp], edgecolor="black", lw=0.5, hatch=hatch, label=grp)
        bottom += vals
    # Annotate total n and ASD enrichment in Cluster 4
    totals = hcpc[["ASD", "TD", "non-ASD"]].sum(axis=1).values
    for i, tot in enumerate(totals):
        ax.text(i, 101.8, f"n={tot}", ha="center", va="bottom", fontsize=6.8)
    asd_c4_pct = hcpc.loc[4, "ASD"] / hcpc["ASD"].sum() * 100.0
    ax.annotate(f"Cluster 4 captures\n{hcpc.loc[4,'ASD']}/{hcpc['ASD'].sum()} ASD ({asd_c4_pct:.1f}%)",
                xy=(3, 52), xytext=(3.8, 22),
                fontsize=7.1, fontweight="bold", color="#111111",
                bbox=dict(boxstyle="round,pad=0.3", fc="#FFF7EC", ec="#D55E00"),
                arrowprops=dict(arrowstyle="->", color="#D55E00", lw=1.2))
    ax.set_xticks(x_cl)
    ax.set_xticklabels([f"C{c}" for c in clusters])
    ax.set_xlabel("HCPC Ward cluster")
    ax.set_ylabel("Within-cluster diagnostic composition (%)")
    ax.set_ylim(0, 114)
    ax.set_title("HCPC phenotyping (Chi2(12) = 1,920.05)")
    ax.legend(loc="lower left", fontsize=7.0, framealpha=0.92)
    add_panel_label(ax, "C", x=-0.16, y=1.10)

    save_fig(fig, "Fig2_Unsupervised_PCA_and_HCPC_Phenotypes")


# ===========================================================================
# FIGURE 3: REGIONAL BIOPHYSICAL COMPLEXITY, SOC BAND & REFINED LME
# ===========================================================================
def make_fig3():
    print("Generating Figure 3...")
    roi_sum = pd.read_csv(os.path.join(DATA_DIR, "ROI_Descriptive_Summary.csv"))
    prior = pd.read_csv(os.path.join(DATA_DIR, "Prior_Predictive_Biophysical_Check.csv")).set_index("Group")
    fe_sh = pd.read_csv(os.path.join(DATA_DIR, "LME_FixedEffects_Shannon.csv"))
    fe_hu = pd.read_csv(os.path.join(DATA_DIR, "LME_FixedEffects_Hurst.csv"))

    roi_order = ["OFC", "IFG", "ACC/SMA", "PPC", "STS/FG", "PN", "BG/SN/Th", "Amygdala"]
    fig, axes = plt.subplots(2, 2, figsize=(12.6, 8.9), gridspec_kw={"hspace": 0.48, "wspace": 0.28})

    # Panel A: Regional Hurst exponent H (Mean +/- 95% CI) + Critical SOC Band
    ax = axes[0, 0]
    ax.axhspan(0.70, 0.80, color="#E5F5E0", alpha=0.85, zorder=0, label="Physiological SOC band (H = 0.70-0.80)")
    ax.axhline(0.50, color="#888888", ls=":", lw=0.9, label="White-noise boundary (H = 0.50)")
    x_base = np.arange(len(roi_order))
    offsets = {"ASD": -0.22, "TD": 0.0, "non-ASD": 0.22}
    for grp in ["ASD", "TD", "non-ASD"]:
        sub = roi_sum[roi_sum["diagnostic_group"] == grp].set_index("roi_clean")
        xs, ys, errs = [], [], []
        for idx_r, r in enumerate(roi_order):
            if r in sub.index and sub.loc[r, "n"] > 0:
                xs.append(idx_r + offsets[grp])
                ys.append(sub.loc[r, "hurst_mean"])
                errs.append(1.96 * sub.loc[r, "hurst_se"])
        ax.errorbar(xs, ys, yerr=errs, fmt=MARKERS[grp], color=COLORS[grp], ms=5.5, lw=1.2, capsize=2.5,
                    markeredgecolor="black", markeredgewidth=0.4, label=f"{grp} (mean ± 95% CI)")
    ax.set_xticks(x_base)
    ax.set_xticklabels(roi_order, rotation=24, ha="right")
    ax.set_ylabel("Hurst exponent, H (dimensionless)")
    ax.set_ylim(0.32, 0.92)
    ax.set_title("Regional long-range temporal correlations (H)")
    ax.legend(loc="lower left", fontsize=6.7, ncol=2, framealpha=0.92)
    ax.grid(axis="y", alpha=0.25)
    add_panel_label(ax, "A", x=-0.14, y=1.08)

    # Panel B: Regional Shannon entropy S (Mean +/- 95% CI)
    ax = axes[0, 1]
    for grp in ["ASD", "TD", "non-ASD"]:
        sub = roi_sum[roi_sum["diagnostic_group"] == grp].set_index("roi_clean")
        xs, ys, errs = [], [], []
        for idx_r, r in enumerate(roi_order):
            if r in sub.index and sub.loc[r, "n"] > 0:
                xs.append(idx_r + offsets[grp])
                ys.append(sub.loc[r, "shannon_mean"])
                errs.append(1.96 * sub.loc[r, "shannon_se"])
        ax.errorbar(xs, ys, yerr=errs, fmt=MARKERS[grp], color=COLORS[grp], ms=5.5, lw=1.2, capsize=2.5,
                    markeredgecolor="black", markeredgewidth=0.4, label=grp)
    ax.set_xticks(x_base)
    ax.set_xticklabels(roi_order, rotation=24, ha="right")
    ax.set_ylabel("Spectral Shannon entropy, S (normalized)")
    ax.set_title("Regional spectral complexity across ROIs")
    ax.legend(loc="lower right", fontsize=7.2, framealpha=0.92)
    ax.grid(axis="y", alpha=0.25)
    add_panel_label(ax, "B", x=-0.14, y=1.08)

    # Panel C: Prior-Predictive Criticality Regime Percentages (Stacked Bar)
    ax = axes[1, 0]
    groups_c = ["TD", "ASD", "non-ASD"]
    subcrit = [prior.loc[g, "H_subcritical_lt0.65_pct"] for g in groups_c]
    mid_trans = [100.0 - prior.loc[g, "H_subcritical_lt0.65_pct"] - prior.loc[g, "H_in_SOC_band_0.7_0.8_pct"] - prior.loc[g, "H_hyperpersistent_gt0.80_pct"] for g in groups_c]
    soc_band = [prior.loc[g, "H_in_SOC_band_0.7_0.8_pct"] for g in groups_c]
    hyper = [prior.loc[g, "H_hyperpersistent_gt0.80_pct"] for g in groups_c]

    x_g = np.arange(len(groups_c))
    b1 = ax.bar(x_g, subcrit, color="#CC79A7", edgecolor="black", lw=0.5, hatch="///", label="Subcritical noisy (H < 0.65)")
    b2 = ax.bar(x_g, mid_trans, bottom=subcrit, color="#E69F00", edgecolor="black", lw=0.5, label="Transitional (0.65 <= H < 0.70)")
    bot3 = np.array(subcrit) + np.array(mid_trans)
    b3 = ax.bar(x_g, soc_band, bottom=bot3, color="#009E73", edgecolor="black", lw=0.5, label="Critical SOC target (0.70-0.80)")
    bot4 = bot3 + np.array(soc_band)
    b4 = ax.bar(x_g, hyper, bottom=bot4, color="#0072B2", edgecolor="black", lw=0.5, hatch="...", label="Hyper-persistent (H > 0.80)")

    for i, g in enumerate(groups_c):
        segs = [
            (0.0, subcrit[i], "white"),
            (subcrit[i], mid_trans[i], "black"),
            (bot3[i], soc_band[i], "white"),
            (bot4[i], hyper[i], "white"),
        ]
        for b0, h_val, tcol in segs:
            if h_val >= 10.0:
                ax.text(i, b0 + h_val / 2.0, f"{h_val:.1f}%", ha="center", va="center", fontsize=7.4, fontweight="bold", color=tcol)
        ax.text(i, 101.8, f"D = {prior.loc[g, 'Fractal_D_mean']:.2f}", ha="center", va="bottom", fontsize=7.4, fontweight="bold")
    ax.set_xticks(x_g)
    ax.set_xticklabels([f"{g}\n(n={int(prior.loc[g,'n'])})" for g in groups_c])
    ax.set_ylabel("Frontal cohort distribution (%)")
    ax.set_ylim(0, 128)
    ax.set_title("Prior-predictive biophysical regime & fractal D = 2 - H")
    ax.legend(loc="upper center", ncol=2, fontsize=6.5, framealpha=0.94)
    add_panel_label(ax, "C", x=-0.14, y=1.08)

    # Panel D: Refined LME Fixed-Effect Interaction Forest Plot (ASD vs TD by ROI)
    ax = axes[1, 1]
    fe_sh_int = fe_sh[fe_sh["Term"].str.contains("C\\(diagnostic_group\\)\\[T\\.ASD\\]:C\\(roi_clean\\)")].copy()
    fe_hu_int = fe_hu[fe_hu["Term"].str.contains("C\\(diagnostic_group\\)\\[T\\.ASD\\]:C\\(roi_clean\\)")].copy()
    fe_sh_int["ROI"] = fe_sh_int["Term"].str.extract(r"C\(roi_clean\)\[T\.([^\]]+)\]")
    fe_hu_int["ROI"] = fe_hu_int["Term"].str.extract(r"C\(roi_clean\)\[T\.([^\]]+)\]")
    fe_sh_int = fe_sh_int.set_index("ROI")
    fe_hu_int = fe_hu_int.set_index("ROI")

    int_rois = [r for r in ["IFG", "ACC/SMA", "PPC", "STS/FG", "PN", "BG/SN/Th", "Amygdala"] if r in fe_sh_int.index]
    y_i = np.arange(len(int_rois))
    ax.axvline(0.0, color="#666666", ls="--", lw=1.0)
    # Plot Shannon interaction beta on bottom x-axis and Hurst interaction alpha on top x-axis (scales differ by ~15x)
    ax.errorbar(
        [fe_sh_int.loc[r, "Beta"] for r in int_rois], y_i + 0.14,
        xerr=[1.96 * fe_sh_int.loc[r, "SE"] for r in int_rois],
        fmt="o", color="#D55E00", ms=5.2, lw=1.2, capsize=2.5, label="Shannon beta (ASD x ROI, bottom)"
    )
    ax.set_yticks(y_i)
    ax.set_yticklabels(int_rois)
    ax.set_xlabel("Shannon entropy interaction, beta (± 95% CI)", color="#D55E00")
    ax.set_xlim(-0.48, 0.14)

    ax_top = ax.twiny()
    ax_top.spines["right"].set_visible(False)
    ax_top.axvline(0.0, color="#0072B2", ls=":", lw=0.9, alpha=0.6)
    ax_top.errorbar(
        [fe_hu_int.loc[r, "Beta"] for r in int_rois], y_i - 0.14,
        xerr=[1.96 * fe_hu_int.loc[r, "SE"] for r in int_rois],
        fmt="s", color="#0072B2", ms=5.0, lw=1.2, capsize=2.5, label="Hurst alpha (ASD x ROI, top)"
    )
    ax_top.set_xlabel("Hurst exponent interaction, alpha (± 95% CI)", color="#0072B2")
    ax_top.set_xlim(-0.004, 0.028)
    ax.set_ylim(-1.55, 6.55)
    ax.set_title("REML LME interaction shifts (ref: TD, OFC)", pad=22)
    from matplotlib.lines import Line2D
    ax.legend(handles=[
        Line2D([0], [0], marker="o", color="#D55E00", lw=1.2, label="Shannon beta (ASD x ROI, bottom)"),
        Line2D([0], [0], marker="s", color="#0072B2", lw=1.2, label="Hurst alpha (ASD x ROI, top)"),
    ], loc="lower left", fontsize=6.7, framealpha=0.94)
    ax.grid(axis="x", alpha=0.25)
    add_panel_label(ax, "D", x=-0.16, y=1.18)

    save_fig(fig, "Fig3_Regional_Biophysical_Complexity_Profiles")


# ===========================================================================
# FIGURE 4: FRONTAL MESO-MACRO DECOUPLING & CLINICAL STRATIFICATION
# ===========================================================================
def make_fig4():
    print("Generating Figure 4...")
    df_front = pd.read_csv(os.path.join(DATA_DIR, "Frontal_OFC_IFG_Subject_Level.csv"))
    df_decoup = pd.read_csv(os.path.join(TAB_DIR, "Table4_Frontal_MesoMacro_Decoupling_FisherZ.csv"))
    df_subp = pd.read_csv(os.path.join(DATA_DIR, "Subpathology_MesoMacro_Coupling.csv"))

    fig = plt.figure(figsize=(15.4, 9.2))
    gs = gridspec.GridSpec(2, 2, hspace=0.38, wspace=0.62)

    # Panel A: Shannon vs Global Efficiency Scatter + Regression Lines
    ax = axes_a = fig.add_subplot(gs[0, 0])
    for grp, zord, alp in [("TD", 1, 0.16), ("non-ASD", 2, 0.25), ("ASD", 3, 0.35)]:
        sub = df_front[df_front["diagnostic_group"] == grp][["shannon", "efficiency"]].dropna()
        ax.scatter(sub["efficiency"], sub["shannon"], s=11, color=COLORS[grp], marker=MARKERS[grp], alpha=alp, edgecolors="none")
        # OLS line
        slope, intercept, r_val, _, _ = stats.linregress(sub["efficiency"], sub["shannon"])
        xs_line = np.linspace(sub["efficiency"].quantile(0.01), sub["efficiency"].quantile(0.99), 80)
        ax.plot(xs_line, slope * xs_line + intercept, color=COLORS[grp], ls=LINESTYLES[grp], lw=2.2, zorder=5,
                label=f"{grp} (n={len(sub)}, r = {r_val:.4f})")
    ax.set_xlabel("Macroscale global efficiency, E_glob")
    ax.set_ylabel("Frontal Shannon entropy, S (OFC + IFG)")
    ax.set_title("Mesoscale-macroscale functional decoupling in ASD")
    ax.legend(loc="lower left", fontsize=7.3, framealpha=0.94)
    ax.grid(alpha=0.22)
    add_panel_label(ax, "A", x=-0.14, y=1.07)

    # Panel B: Hurst vs Global Efficiency Scatter + Regression Lines
    ax = fig.add_subplot(gs[0, 1])
    for grp, zord, alp in [("TD", 1, 0.16), ("non-ASD", 2, 0.25), ("ASD", 3, 0.35)]:
        sub = df_front[df_front["diagnostic_group"] == grp][["hurst", "efficiency"]].dropna()
        ax.scatter(sub["efficiency"], sub["hurst"], s=11, color=COLORS[grp], marker=MARKERS[grp], alpha=alp, edgecolors="none")
        slope, intercept, r_val, _, _ = stats.linregress(sub["efficiency"], sub["hurst"])
        xs_line = np.linspace(sub["efficiency"].quantile(0.01), sub["efficiency"].quantile(0.99), 80)
        ax.plot(xs_line, slope * xs_line + intercept, color=COLORS[grp], ls=LINESTYLES[grp], lw=2.2, zorder=5,
                label=f"{grp} (n={len(sub)}, r = {r_val:+.4f})")
    ax.set_xlabel("Macroscale global efficiency, E_glob")
    ax.set_ylabel("Frontal Hurst exponent, H (OFC + IFG)")
    ax.set_title("Attenuated criticality-efficiency coupling in ASD")
    ax.legend(loc="upper left", fontsize=7.3, framealpha=0.94)
    ax.grid(alpha=0.22)
    add_panel_label(ax, "B", x=-0.14, y=1.07)

    # Panel C: Pairwise Correlation Matrix Heatmap across Groups (3 stacked side-by-side mini-heatmaps)
    gs_c = gridspec.GridSpecFromSubplotSpec(1, 3, subplot_spec=gs[1, 0], wspace=0.14)
    vars_hm = ["shannon", "hurst", "efficiency", "modularity"]
    lbls_hm = ["S", "H", "E_glob", "Q"]
    for idx_g, grp in enumerate(["ASD", "TD", "non-ASD"]):
        ax_hm = fig.add_subplot(gs_c[0, idx_g])
        corr_m = df_front[df_front["diagnostic_group"] == grp][vars_hm].dropna().corr().values
        im = ax_hm.imshow(corr_m, cmap="RdBu_r", vmin=-0.85, vmax=0.85, aspect="equal")
        for r_i in range(4):
            for c_i in range(4):
                val = corr_m[r_i, c_i]
                tcol = "white" if abs(val) > 0.50 else "black"
                ax_hm.text(c_i, r_i, f"{val:.2f}", ha="center", va="center", fontsize=6.8, color=tcol, fontweight="bold" if (r_i == 0 and c_i == 2) else "normal")
        ax_hm.set_xticks(range(4))
        ax_hm.set_xticklabels(lbls_hm, fontsize=7.2)
        ax_hm.set_yticks(range(4))
        ax_hm.set_yticklabels(lbls_hm if idx_g == 0 else [], fontsize=7.2)
        ax_hm.set_title(grp, fontsize=8.8, fontweight="bold", color=COLORS[grp])
        if idx_g == 0:
            add_panel_label(ax_hm, "C", x=-0.38, y=1.18)

    # Panel D: Sub-pathology & Within-Site Mendeley Coupling Forest Plot
    ax = fig.add_subplot(gs[1, 1])
    # Compute within-site Mendeley ASD and TD rows to append cleanly
    m_asd = df_front[(df_front["Source"] == "Mendeley Data") & (df_front["diagnostic_group"] == "ASD")][["shannon", "efficiency"]].dropna()
    m_td = df_front[(df_front["Source"] == "Mendeley Data") & (df_front["diagnostic_group"] == "TD")][["shannon", "efficiency"]].dropna()
    def r_with_ci(df_xy):
        r = df_xy["shannon"].corr(df_xy["efficiency"])
        z = np.arctanh(r)
        se = 1.0 / np.sqrt(len(df_xy) - 3)
        return r, np.tanh(z - 1.96 * se), np.tanh(z + 1.96 * se), len(df_xy)

    rm_a, lm_a, hm_a, nm_a = r_with_ci(m_asd)
    rm_t, lm_t, hm_t, nm_t = r_with_ci(m_td)

    subp_plot = df_subp.copy()
    extra = pd.DataFrame([
        {"Subgroup": "Mendeley Within-Site: ASD", "n": nm_a, "r_Shannon_Eff": rm_a, "CI_Shannon_Eff_low": lm_a, "CI_Shannon_Eff_high": hm_a},
        {"Subgroup": "Mendeley Within-Site: TD", "n": nm_t, "r_Shannon_Eff": rm_t, "CI_Shannon_Eff_low": lm_t, "CI_Shannon_Eff_high": hm_t},
    ])
    subp_plot = pd.concat([subp_plot, extra], ignore_index=True).sort_values("r_Shannon_Eff", ascending=True).reset_index(drop=True)

    y_sp = np.arange(len(subp_plot))
    ax.axvline(0.0, color="#333333", ls="--", lw=1.0)
    for i, row in subp_plot.iterrows():
        sname = row["Subgroup"]
        col = COLORS["ASD"] if "ASD" in sname and "Siblings" not in sname else (COLORS["TD"] if "Typically" in sname or ": TD" in sname else COLORS["non-ASD"])
        xerr_low = max(0, row["r_Shannon_Eff"] - row["CI_Shannon_Eff_low"])
        xerr_hi = max(0, row["CI_Shannon_Eff_high"] - row["r_Shannon_Eff"])
        ax.errorbar(row["r_Shannon_Eff"], i, xerr=[[xerr_low], [xerr_hi]], fmt="o", color=col, ms=5.5, lw=1.4, capsize=3)
    sub_short = {
        "Autism Spectrum Disorder (ASD)": "ASD (all sites)",
        "Typically Developing (TD)": "TD (all sites)",
        "non-ASD Neuropathology (All)": "non-ASD (pooled)",
        "Pediatric Epilepsy Control (CHB-MIT)": "Pediatric Epilepsy (CHB-MIT)",
        "Mendeley Within-Site: ASD": "Mendeley site: ASD",
        "Mendeley Within-Site: TD": "Mendeley site: TD",
        "Mendeley restEO Only: ASD": "Mendeley restEO: ASD (1:1)",
        "Mendeley restEO Only: TD": "Mendeley restEO: TD (1:1)",
    }
    ax.set_yticks(y_sp)
    ax.set_yticklabels([f"{sub_short.get(r['Subgroup'], r['Subgroup'])} (n={int(r['n'])})" for _, r in subp_plot.iterrows()], fontsize=6.9)
    ax.set_ylim(-0.75, len(subp_plot) - 0.25)
    ax.set_xlabel("Pearson r (Frontal S vs E_glob, ± 95% CI)")
    ax.set_xlim(-0.92, 0.65)
    ax.set_title("Specificity across clinical sub-pathologies & single-site control")
    ax.grid(axis="x", alpha=0.25)
    add_panel_label(ax, "D", x=-0.52, y=1.07)

    save_fig(fig, "Fig4_Frontal_MesoMacro_Decoupling")


# ===========================================================================
# FIGURE 5: SUPERVISED RANDOM FOREST, BIOMARKERS, ROC & FEATURE ABLATION
# ===========================================================================
def make_fig5():
    print("Generating Figure 5...")
    cm_df = pd.read_csv(os.path.join(ORIG_DIR, "Tabla_Confusion_Frecuencias.csv"))
    imp_df = pd.read_csv(os.path.join(TAB_DIR, "Table6_Top15_Biomarker_Importance.csv"))
    abl_df = pd.read_csv(os.path.join(TAB_DIR, "Table5B_RF_Feature_Ablation_and_ROC.csv"))
    with open(os.path.join(DATA_DIR, "roc_curves.json"), "r") as f:
        rocs = json.load(f)["Full_Hybrid"]

    # Build 3x3 confusion matrix (Rows=Prediction, Cols=Reference) in order ASD, non-ASD, TD
    piv_cm = cm_df.pivot(index="Prediction", columns="Reference", values="Freq").fillna(0).astype(int)
    ord_r = ["ASD", "non_ASD", "TD"]
    piv_cm = piv_cm.loc[ord_r, ord_r]

    fig, axes = plt.subplots(2, 2, figsize=(14.8, 9.5), gridspec_kw={"hspace": 0.44, "wspace": 0.48})

    # Panel A: Hold-out Test Confusion Matrix
    ax = axes[0, 0]
    cm_vals = piv_cm.values
    cm_pct = cm_vals / cm_vals.sum(axis=0, keepdims=True) * 100.0
    ax.imshow(cm_pct, cmap="Blues", vmin=0, vmax=100, aspect="equal")
    lbls_cm = ["ASD", "non-ASD", "TD"]
    for i in range(3):
        for j in range(3):
            tcol = "white" if cm_pct[i, j] > 50 else "black"
            ax.text(j, i, f"{cm_vals[i, j]}\n({cm_pct[i, j]:.1f}%)", ha="center", va="center", fontsize=8.4, fontweight="bold", color=tcol)
    ax.set_xticks(range(3))
    ax.set_xticklabels(lbls_cm, fontsize=8.5)
    ax.set_yticks(range(3))
    ax.set_yticklabels(lbls_cm, fontsize=8.5)
    ax.set_xlabel("Reference diagnosis")
    ax.set_ylabel("Predicted diagnosis")
    ax.set_title("Random Forest hold-out test (n = 965)\nAcc = 96.37%, kappa = 0.935", fontsize=9.2)
    add_panel_label(ax, "A", x=-0.26, y=1.10)

    # Panel B: Top 15 Biomarker Importance (Mean Decrease Accuracy) distinguishing artifact
    ax = axes[0, 1]
    imp_p = imp_df.sort_values("MeanDecreaseAccuracy", ascending=True).copy()
    y_im = np.arange(len(imp_p))
    cols_im = ["#999999" if str(p).startswith("NA_") else ("#D55E00" if "hurst" in str(p) or "shannon" in str(p) else "#0072B2") for p in imp_p["Predictor"]]
    hatches_im = ["///" if str(p).startswith("NA_") else "" for p in imp_p["Predictor"]]
    bars = ax.barh(y_im, imp_p["MeanDecreaseAccuracy"], color=cols_im, edgecolor="black", lw=0.5)
    for b, h in zip(bars, hatches_im):
        if h:
            b.set_hatch(h)
    ax.set_yticks(y_im)
    ax.set_yticklabels([clean_var_label(p) for p in imp_p["Predictor"]], fontsize=7.2)
    ax.set_xlim(0, 27.0)
    ax.set_xlabel("Permutation importance (Mean Decrease Accuracy)")
    ax.set_title("Top 15 predictors & missing-ROI artifact audit", fontsize=9.2)
    from matplotlib.patches import Patch
    ax.legend(handles=[
        Patch(facecolor="#D55E00", edgecolor="black", lw=0.5, label="Nonlinear complexity (H, S)"),
        Patch(facecolor="#0072B2", edgecolor="black", lw=0.5, label="Spectral power / ratio (sigma, A/T)"),
        Patch(facecolor="#999999", edgecolor="black", lw=0.5, hatch="///", label="Missing-O2-label artifact (NA)"),
    ], loc="lower right", fontsize=6.7, framealpha=0.92)
    ax.grid(axis="x", alpha=0.25)
    add_panel_label(ax, "B", x=-0.42, y=1.10)

    # Panel C: Multiclass One-vs-Rest & Pairwise ROC Curves (Leakage-Free Universal Matrix)
    ax = axes[1, 0]
    roc_specs = [
        ("ASD_OVR", "ASD vs Rest", COLORS["ASD"], "-"),
        ("nonASD_OVR", "non-ASD vs Rest", COLORS["non-ASD"], "-."),
        ("TD_OVR", "TD vs Rest", COLORS["TD"], "--"),
        ("ASD_vs_nonASD", "ASD vs non-ASD (pairwise)", COLORS["Accent"], ":"),
    ]
    for key, lbl, col, ls in roc_specs:
        fpr, tpr, auc_v = rocs[key]
        ax.plot(fpr, tpr, color=col, ls=ls, lw=1.9, label=f"{lbl} (AUC = {auc_v:.4f})")
    ax.plot([0, 1], [0, 1], color="#666666", ls=":", lw=0.9)
    ax.set_xlabel("False positive rate (1 - Specificity)")
    ax.set_ylabel("True positive rate (Sensitivity)")
    ax.set_title("Leakage-free multiclass ROC curves (5 universal ROIs)")
    ax.legend(loc="lower right", fontsize=7.1, framealpha=0.94)
    ax.grid(alpha=0.22)
    add_panel_label(ax, "C", x=-0.16, y=1.08)

    # Panel D: Feature-Family Ablation & Multi-Group Site-Sensitivity Benchmark
    ax = axes[1, 1]
    abl_p = abl_df.copy()
    def short_abl_label(name):
        s = str(name)
        if s.startswith("Original Full 65"):
            return "Original 65-Feature (N=4834)"
        if s.startswith("Full Hybrid"):
            return "Full Hybrid (5 Univ ROIs + Macro)"
        if s.startswith("Mesoscale Only"):
            return "Mesoscale Only (30 features)"
        if s.startswith("Nonlinear Complexity"):
            return "Nonlinear Only (H + S, 10 feat)"
        if s.startswith("Spectral Power"):
            return "Spectral Only (Theta/Sigma/A:T, 15)"
        if s.startswith("Macroscale Graph"):
            return "Macro Graph Only (5 features)"
        if s.startswith("Multi-Group Repositories"):
            return "Multi-Group Sites Only (n=1905)"
        if s.startswith("Bio-Participant-Disjoint"):
            return "Bio-Participant Disjoint (515 Unseen)"
        return s
    abl_p["Short"] = abl_p["Model_Configuration"].apply(short_abl_label)
    abl_p = abl_p.iloc[::-1].reset_index(drop=True)
    y_ab = np.arange(len(abl_p))
    h = 0.25
    ax.barh(y_ab + h, abl_p["Accuracy"], height=h, color="#0072B2", edgecolor="black", lw=0.4, label="Accuracy")
    ax.barh(y_ab, abl_p["Macro_OVR_AUC"], height=h, color="#E69F00", edgecolor="black", lw=0.4, label="Macro OVR AUC")
    ax.barh(y_ab - h, abl_p["AUC_ASD_vs_nonASD"], height=h, color="#D55E00", edgecolor="black", lw=0.4, hatch="///", label="ASD vs non-ASD AUC")
    ax.set_yticks(y_ab)
    ax.set_yticklabels(abl_p["Short"], fontsize=7.2)
    ax.set_xlabel("Hold-out classification score (0-1)")
    ax.set_xlim(0.50, 1.04)
    ax.set_title("Feature ablation & site-confound sensitivity audit")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.18), ncol=3, fontsize=7.0, framealpha=0.95)
    ax.grid(axis="x", alpha=0.25)
    add_panel_label(ax, "D", x=-0.42, y=1.08)

    save_fig(fig, "Fig5_Supervised_RandomForest_and_Ablation")


# ===========================================================================
# FIGURE 6: CLINICAL DEFICIT DOMAINS, CONNECTIVITY REGIMES & CONCEPTUAL MODEL
# ===========================================================================
def make_fig6():
    print("Generating Figure 6...")
    def_df = pd.read_csv(os.path.join(DATA_DIR, "Deficit_Domain_Stratification.csv"))
    con_df = pd.read_csv(os.path.join(DATA_DIR, "Connectivity_Profile_Stratification.csv"))

    fig = plt.figure(figsize=(15.4, 5.4))
    gs = gridspec.GridSpec(1, 3, width_ratios=[1.15, 1.0, 1.25], wspace=0.50)

    # Panel A: ASD Symptom-Domain Stratification of H and S
    ax = fig.add_subplot(gs[0, 0])
    asd_def = def_df[(def_df["diagnostic_group"] == "ASD") & (def_df["n_obs"] >= 50)].sort_values("hurst_mean", ascending=True).copy()
    # Shorten domain labels
    dom_short = {
        "Social Only (a)": "Social (a)",
        "Social + Communication (a,b)": "Social + Comm (a,b)",
        "Social + Repetitive (a,c)": "Social + Rep (a,c)",
        "Social + Repetitive + Language (a,b,c)": "Social + Rep + Lang (a,b,c)",
        "Communication/Language (b)": "Comm / Lang (b)",
        "Stereotyped/Repetitive (c)": "Stereotyped / Rep (c)",
    }
    asd_def["lbl"] = asd_def["def_domain"].map(lambda x: dom_short.get(x, x))
    y_d = np.arange(len(asd_def))
    se_h = asd_def["hurst_sd"] / np.sqrt(asd_def["n_obs"])
    se_s = asd_def["shannon_sd"] / np.sqrt(asd_def["n_obs"])
    ax.errorbar(asd_def["hurst_mean"], y_d + 0.14, xerr=1.96 * se_h, fmt="o", color="#D55E00", ms=5.5, capsize=2.5, label="Hurst exponent (H)")
    ax.set_yticks(y_d)
    ax.set_yticklabels(asd_def["lbl"], fontsize=7.2)
    ax.set_xlabel("Mean ROI Hurst exponent, H (± 95% CI)", color="#D55E00")
    ax.set_xlim(0.84, 0.91)
    ax_s = ax.twiny()
    ax_s.spines["right"].set_visible(False)
    ax_s.errorbar(asd_def["shannon_mean"], y_d - 0.14, xerr=1.96 * se_s, fmt="s", color="#0072B2", ms=5.2, capsize=2.5, label="Shannon entropy (S)")
    ax_s.set_xlabel("Mean ROI Shannon entropy, S (± 95% CI)", color="#0072B2")
    ax_s.set_xlim(2.5, 3.3)
    ax.set_ylim(-1.35, len(asd_def) - 0.35)
    ax.set_title("ASD symptom-domain stratification", pad=26)
    from matplotlib.lines import Line2D
    ax.legend(handles=[
        Line2D([0], [0], marker="o", color="#D55E00", lw=1.2, label="Hurst H (bottom axis)"),
        Line2D([0], [0], marker="s", color="#0072B2", lw=1.2, label="Shannon S (top axis)"),
    ], loc="lower left", fontsize=6.8, framealpha=0.92)
    ax.grid(axis="x", alpha=0.25)
    add_panel_label(ax, "A", x=-0.46, y=1.14)

    # Panel B: Connectivity State Regime (Hypo vs Hyper vs Mixed)
    ax = fig.add_subplot(gs[0, 1])
    con_map = {
        "Hypoconnected (Stable)": "Hypoconnected\n(Stable)",
        "Hyperconnected (Critical)": "Hyperconnected\n(Critical)",
        "Hypoconnected": "Hypoconnected",
        "Hyperconnected": "Hyperconnected",
        "Mixed (Local Hyper / Long Hypo)": "Mixed",
    }
    con_df["c_en"] = con_df["connectivity_profile"].map(lambda x: con_map.get(x, str(x)))
    # Filter top informative connectivity states
    keep_c = con_df[con_df["n_obs"] >= 200].sort_values(["diagnostic_group", "hurst_mean"]).copy()
    labels_c = [f"{r['c_en']}\n({r['diagnostic_group']})" for _, r in keep_c.iterrows()]
    y_k = np.arange(len(keep_c))
    bar_cols_k = [COLORS[g] for g in keep_c["diagnostic_group"]]
    se_hk = keep_c["hurst_sd"] / np.sqrt(keep_c["n_obs"])
    ax.barh(y_k, keep_c["hurst_mean"], xerr=1.96 * se_hk, color=bar_cols_k, edgecolor="black", lw=0.5, capsize=2.5, alpha=0.9)
    ax.axvspan(0.70, 0.80, color="#E5F5E0", alpha=0.55, zorder=0, label="SOC band (0.70-0.80)")
    ax.set_yticks(y_k)
    ax.set_yticklabels(labels_c, fontsize=7.0)
    ax.set_xlabel("Hurst exponent, H (mean ± 95% CI)")
    ax.set_xlim(0.40, 0.90)
    ax.set_title("Criticality across connectivity phenotypes", pad=40)
    ax.legend(loc="lower right", fontsize=6.9, framealpha=0.92)
    ax.grid(axis="x", alpha=0.25)
    add_panel_label(ax, "B", x=-0.42, y=1.16)

    # Panel C: Mechanistic Summary Schematic (Meso-Macro Decoupling Model, dynamically populated from verified CSVs)
    decoup = pd.read_csv(os.path.join(TAB_DIR, "Table4_Frontal_MesoMacro_Decoupling_FisherZ.csv"))
    hub_cnt = pd.read_csv(os.path.join(DATA_DIR, "Centrality_Hub_Counts.csv")).set_index("diagnostic_group")
    hub_pct = pd.read_csv(os.path.join(DATA_DIR, "Centrality_Hub_Percentages.csv")).set_index("diagnostic_group")
    f78_tab = pd.DataFrame({
        "f78": hub_cnt["F7"] + hub_cnt["F8"],
        "other": hub_cnt.sum(axis=1) - (hub_cnt["F7"] + hub_cnt["F8"]),
    })
    chi2_h, _, _, _ = stats.chi2_contingency(f78_tab.values)
    r_row = decoup[(decoup["Definition"] == "OFC+IFG (Refined Frontal)") & (decoup["Pair"] == "Shannon_Frontal vs Global_Efficiency")].iloc[0]
    r_ofc = decoup[(decoup["Definition"] == "OFC (Original Session004 Match)") & (decoup["Pair"] == "Shannon_Frontal vs Global_Efficiency")].iloc[0]

    asd_f78_pct = (hub_cnt.loc["ASD", "F7"] + hub_cnt.loc["ASD", "F8"]) / hub_cnt.loc["ASD"].sum() * 100.0
    td_f78_pct = (hub_cnt.loc["TD", "F7"] + hub_cnt.loc["TD", "F8"]) / hub_cnt.loc["TD"].sum() * 100.0
    non_f78_pct = (hub_cnt.loc["non-ASD", "F7"] + hub_cnt.loc["non-ASD", "F8"]) / hub_cnt.loc["non-ASD"].sum() * 100.0

    ax = fig.add_subplot(gs[0, 2])
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis("off")
    ax.set_title("Multiscale biophysical model of ASD", fontsize=9.5, fontweight="bold", pad=40)

    boxes = [
        (0.3, 7.3, 9.4, 2.0, "#FFF3E0", COLORS["ASD"],
         f"ASD: Meso-Macro Decoupling & Lateral Frontal Hub Trap\n"
         f"• {asd_f78_pct:.2f}% max centrality trapped at F7/F8 (chi2 = {chi2_h:.1f})\n"
         f"• Frontal S vs E_glob uncoupled: r = {r_row['r_ASD']:.4f} (OFC {r_ofc['r_ASD']:.4f}; z = {r_row['Fisher_z_ASD_vs_TD']:.2f})"),
        (0.3, 4.1, 9.4, 2.0, "#E3F2FD", COLORS["TD"],
         f"TD: Physiological Self-Organized Criticality (SOC)\n"
         f"• Balanced hub topology (F7/F8 = {td_f78_pct:.2f}%; Fp1 = {hub_pct.loc['TD','Fp1']:.2f}%)\n"
         f"• Strong inverse meso-macro coupling: r(S, E_glob) = {r_row['r_TD']:.4f}"),
        (0.3, 0.9, 9.4, 2.0, "#E8F5E9", COLORS["non-ASD"],
         f"non-ASD Neuropathology: Preserved-Pathway Hyper-Coupling\n"
         f"• Posterior-anterior routing (P3 = {hub_pct.loc['non-ASD','P3']:.2f}%, F7/F8 = {non_f78_pct:.2f}%)\n"
         f"• Tightest meso-macro coupling: r(S, E_glob) = {r_row['r_nonASD']:.4f} (z = {r_row['Fisher_z_ASD_vs_nonASD']:.2f})"),
    ]
    for bx, by, bw, bh, fc, ec, txt in boxes:
        rect = matplotlib.patches.FancyBboxPatch((bx, by), bw, bh, boxstyle="round,pad=0.22,rounding_size=0.35",
                                               facecolor=fc, edgecolor=ec, linewidth=1.6)
        ax.add_patch(rect)
        ax.text(bx + 0.25, by + bh / 2, txt, va="center", ha="left", fontsize=6.6, color="#111111", linespacing=1.35)

    # Bidirectional contrast arrows between boxes
    ax.annotate("", xy=(5.0, 6.32), xytext=(5.0, 7.08), arrowprops=dict(arrowstyle="<->", color="#444444", lw=1.3))
    ax.annotate("", xy=(5.0, 3.12), xytext=(5.0, 3.88), arrowprops=dict(arrowstyle="<->", color="#444444", lw=1.3))
    add_panel_label(ax, "C", x=-0.06, y=1.16)

    save_fig(fig, "Fig6_Biophysical_Conceptual_Model_and_Clinical_Domains")


if __name__ == "__main__":
    print("Building all 6 Nature-style multi-panel figures...")
    make_fig1()
    make_fig2()
    make_fig3()
    make_fig4()
    make_fig5()
    make_fig6()
    print("[DONE] All 6 PDF & 600-DPI PNG figures written to:", FIG_DIR)
