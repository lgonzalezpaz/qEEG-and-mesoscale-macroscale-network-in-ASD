# Refinement & Reproducibility Changelog (`Session001`–`Session006b` → `01`–`05`)

This document summarizes every technical, statistical, and reproducibility bug audited in the original R scripts (`raw_data_directory/Session001`–`Session006b`) and documents how each defect was resolved in the refactored publication-grade pipeline under `GitHub_Zenodo_Repository/R/`.

---

## Script Mapping Overview

| Legacy Script(s) | Refactored Script | Primary Role |
|---|---|---|
| `Session001_Database_Construction.R` & `(Corrected).R` | `01_build_master_database.R` | Excel workbook ingestion, schema validation, `O2` ROI mapping, empty-row QC |
| `Session002`, `Session003`, `Session006`, `Session006b` | `02_harmonization_and_roi_aggregation.R` | 3-sheet metadata join, graph type integrity, Empirical Bayes ComBat, `ICC_source`, ROI pivoting |
| `Session002b_PCA_Cluster_Analysis.R` | `03_unsupervised_pca_hcpc.R` | Clean numeric PCA/HCPC, Chi-square/Cramér's V/ARI validation, colorblind-safe plots |
| `Session004_Phase3_Multilevel_Modeling_Graph_Integration.R` | `04_multilevel_lme_and_decoupling.R` | Continuous LME with `(1 \| Source) + (1 \| record_id)`, `emmeans`, `OFC+IFG` decoupling & Fisher's $z$-tests |
| `Session005_MachineLearning.R` | `05_supervised_random_forest_validation.R` | Leakage-free RF, OOF/test ROC-AUC & PR-AUC, 95% Wilson/bootstrap CIs, 6-arm feature ablation |

---

## Documented Bugs & Verified Resolutions

### Bug 1 — Raw Excel Ingestion Defects (`Session001` → `01_build_master_database.R`)
- **17th clinical pathology column (`Diagnosis`) in `non-ASD` Excel workbooks:** All `1,179` `no-ASD*.xlsx` files in `training_dataset/` contain 17 columns (including `Diagnosis`: `Seizures`, `Epilepsy`, `PD`, `AD`, `FTD`, `ASD SIBLING`), whereas `3,655` `ASD`/`TD` files contain 16 columns. The legacy pipeline discarded the extra diagnosis column.
- **Missing `ROI` on `O2` electrodes:** While `O1` was mapped to `"PN"` in `4,001/4,001` rows and `O2` was mapped to `"PN"` in `589/589` Mendeley `ASD` rows, `3,276` `O2` rows (`2,307 TD`, `954 non-ASD`, `15 ASD`) carried `NaN`/`NA` for `ROI`.
- **225 empty placeholder `non-ASD` files:** `225` `non-ASD` workbooks (`OpenNeuro ds003555`, `Epilepsy`) contained a single row with `NaN` across all biophysical and graph metrics (`theta`–`node_weight`, `electrode`, `roi`, `mean_degree`–`clustering`), inflating the cohort from `4,609` valid subjects to `4,834`.
- **Resolution:** `01_build_master_database.R` safely ingests the optional 17th `Diagnosis` column (`file_diagnosis`), enforces `record_id` and `cohort` across both tables, maps `O2` missing `roi` to `"PN"` with full QC logging (`MAP_O2_MISSING_TO_PN = TRUE`), exports `QC_01_Empty_Placeholder_Subjects.csv`, and drops the `225` empty placeholder subjects by default (`REPRODUCE_ORIGINAL_4834 = FALSE`), while preserving `REPRODUCE_ORIGINAL_4834 = TRUE` (`--reproduce-4834=TRUE`) to reproduce the original `4,834`-subject matrix.

---

### Bug 2 — Metadata Truncation, Graph Column Misalignment, Missing ComBat & `NA_*_roi` Leakage (`Session002` + `Session003` + `Session006` → `02_harmonization_and_roi_aggregation.R`)
- **Truncated legacy metadata & Recording-vs-Participant Hierarchy:** `Session006` joined `source_metadata_legacy.csv` (only `702` `ASD` rows from 5 sources), omitting all `2,953` `TD` and `1,179` `non-ASD` metadata records present in the complete 3-sheet workbook `complete_metadata.xlsx` (archived identically as `complete_metadata.zip`, spanning `4,834` standardized recordings across `11` `Source` repositories and `6` `non-ASD` `Pathology` sub-diagnoses). Furthermore, inspection of `Subject_ID` inside `complete_metadata.xlsx` establishes a two-tier hierarchical structure nesting `4,834` EEG recordings (`4,609` valid) inside `2,576` total / `2,569` valid unique biological participants (`144` ASD, `2,198` TD, `227` non-ASD): Mendeley Data (`31` ASD + `31` TD participants × `19` tasks/loads including `restEO`), OpenNeuro `ds006780` (`41` TD across `209` runs), OpenNeuro `ds004504` (`2` epochs per subject across `29` TD, `36` Alzheimer's, `23` FTD), PhysioNet `CHB-MIT` (`24` patients `chb01`–`chb24` across `686` segments), and OpenNeuro `ds003555` (`30` total / `23` valid patients across `254` total / `29` valid runs), whereas all remaining cohorts (`ds006777`, `ORDA`, `BCIAUT-P300`, `Figshare`, `NMT`, `ds004584`, `ds006780` siblings) are strictly `1:1`.
- **Graph column misalignment (`Session006`):** The graph table already stores `(record_id, cohort, mean_degree, centrality, efficiency, path_length, modularity, clustering)`, where `centrality` is the categorical hub electrode (`"F7"`, `"Fp1"`, etc.). `Session006` mistakenly ran `select(-data) %>% rename(electrode = centrality, centrality = efficiency, efficiency = path_length, path_length = modularity, modularity = clustering)`, shifting and corrupting all five continuous graph metrics.
- **Character-matrix coercion & absent harmonization (`Session002`):** `Session002` converted `df_graphs_final` (including categorical `centrality`) via `as.matrix()`, silently coercing `mean_degree`, `efficiency`, `path_length`, `modularity`, and `clustering` into `character` strings. Despite its filename (`Neurocombat`), `Session002` performed only column-mean imputation without any Empirical Bayes batch correction, leaving large acquisition-site variance (`ICC_within_TD = 92.99%` for `hurst` and `62.46%` for `shannon`, plus `64–71%` for graph `mean_degree`/`efficiency`/`modularity`).
- **`NA_*_roi` and `nan_*_roi` wide-pivot artifacts (`Session003`):** Unmapped `O2` (`"nan"`) and empty `non-ASD` rows (`""`/`NA`) generated `12` spurious columns (`NA_*_roi`, `nan_*_roi`), causing `NA_ratio.at_roi` to become the #1 "biomarker" in `Session005` (`MeanDecreaseAccuracy = 18.25`) strictly via missingness leakage.
- **Resolution:** `02_harmonization_and_roi_aggregation.R` and `python/01_statistical_audit_and_modeling.py` integrate all 3 sheets (`ASD`, `TD`, `non-ASD`) of `complete_metadata.xlsx`, parse `Bio_Participant` and `Is_RestEO` to enforce biological-participant-clustered LME, `restEO` `1:1` decoupling checks, and `StratifiedGroupKFold` participant-disjoint Random Forest sensitivity audits (`Metadata_Complete_Recording_to_Participant_Map.csv`), preserve `centrality` as categorical `character`/`factor`, immediately coerce `mean_degree, efficiency, path_length, modularity, clustering` to `numeric`, perform genuine Empirical Bayes location-scale batch harmonization (`sva::ComBat` / `neuroCombat`, with an exact Johnson et al. 2007 pure-R Empirical Bayes fallback) across `Source` protecting `diagnostic_group` (with variance-stabilizing signed `log1p` on multi-order spectral/weight metrics), log pre- vs. post-harmonization `ICC_source` (`ICC_Pre_vs_Post_Harmonization.csv`), and eliminate all `NA_*_roi` / `nan_*_roi` artifact columns via assertions.

---

### Bug 3 — Factor Dummy Coding in LME, Missing Multi-Site Random Intercept, Broken Export Names & PCA Zero-Variance Column (`Session004` & `Session002b` → `03_unsupervised_pca_hcpc.R` & `04_multilevel_lme_and_decoupling.R`)
- **Dummy-coded continuous covariates in `lmer()` (`Session004`):** Inheriting `character` graph columns from `Session002`, `Session004` passed string-typed `efficiency` and `modularity` into `lmer()`, causing R to fit `1,340` and `4,457` categorical dummy coefficients (`Df = 1340` for `efficiency`, `Df = 4457` for `modularity`) instead of `Df = 1` continuous slopes. It also lacked a `(1 | Source)` random intercept.
- **Export object-name mismatch (`Session004`):** Export guards checked `exists("model_lme_shannon")` and `exists("model_lme_hurst")` while the fitted models were named `model_shannon` and `model_hurst`, causing `LME_Inferential_Statistics_Report.txt` to print `Warning: Object 'model_lme_shannon' was not found` and suppressing all ANOVA/coefficient/post-hoc CSV exports.
- **Categorical `centrality` coercion in PCA (`Session002b`):** Coercing `centrality` (`"F7"`, `"Fp1"`, etc.) via `as.numeric(as.character(.))` created an all-`NA`/constant zero column (`comp 66 = 6.47e-32`).
- **Resolution:**
  - `03_unsupervised_pca_hcpc.R` cleanly excludes categorical `centrality` from numeric PCA/HCPC (evaluating hub-electrode association separately), restricts primary clustering to cross-cohort core ROIs (`<= 25%` missingness) to prevent montage-missingness artifacts, adds Chi-square, Cramér's V, and Adjusted Rand Index validation, and produces colorblind-safe Okabe-Ito/Viridis plots.
  - `04_multilevel_lme_and_decoupling.R` forces numeric types on `efficiency` and `modularity` prior to `lmer()` (asserting `Df == 1`), adds `(1 | Source) + (1 | record_id)` random intercepts, fixes export references (`model_shannon`, `model_hurst`), adds Tukey-adjusted `emmeans` post-hoc contrasts, and runs Fisher's $r$-to-$z$ tests across `ASD`, `TD`, `non-ASD`, and all `non-ASD` sub-pathologies (`Seizures`, `Epilepsy`, `Parkinson`, `Alzheimer`, `Frontotemporal`, `ASD_Sibling`).

---

### Bug 4 — Regex Precedence Bug Swallowing `"IFG"` into `"STS/FG"` (`Session004` → `04_multilevel_lme_and_decoupling.R`)
- **Defect:** In `Session004` `case_when()`, the `STS|FG` pattern preceded `IFG`. Because `"IFG"` contains the substring `"FG"`, every `"IFG (Inferior Frontal Gyrus)"` row was misclassified as `"STS/FG"`. Consequently, `df_frontal` (`filter(roi_abbrev %in% c("OFC", "IFG"))`) analyzed **OFC-only** (`r_ASD(shannon, efficiency) = -0.0365` in unharmonized clean data) instead of combined **OFC + IFG** (`r_ASD = -0.0409` in unharmonized clean data).
- **Resolution:** `04_multilevel_lme_and_decoupling.R` evaluates `str_detect(roi, "(?i)\\bIFG\\b|Inferior Frontal|Frontal Inferior") ~ "IFG"` **before** `str_detect(roi, "(?i)\\bSTS\\b|\\bFG\\b|Fusiform|Fusiforme") ~ "STS/FG"`, enforces `stopifnot(sum(df_lme_long$roi_abbrev == "IFG") > 0)`, and explicitly exports **both** combined `OFC + IFG` and `OFC-only` correlation matrices and Fisher's $z$-tests (for both ComBat-harmonized primary data and pre-ComBat audit data when available).

---

### Additional Refinements in Supervised Machine Learning (`Session005` → `05_supervised_random_forest_validation.R`)
- **Fixed `caret` metric name:** `Session005` passed `metric = "Mac_F1"`, which does not exist in `caret::multiClassSummary` (causing `caret` to fall back silently to `logLoss`); corrected to `metric = "Mean_F1"`.
- **Zero-leakage train-only imputation & matrix interface:** Stratified 80/20 split is performed prior to computing feature medians (applying training medians to test data) and uses `caret::train(x, y)` to avoid formula backtick-mangling on ROI names.
- **Complete probabilistic & ablation validation:** Added out-of-fold (OOF) and blind test-set Hand–Till multi-class ROC-AUC, one-vs-rest & pairwise (`ASD vs non_ASD`, `ASD vs TD`) ROC-AUC with 95% DeLong CIs, PR-AUC, 95% Wilson score and stratified bootstrap (`B = 500`) CIs, and a systematic 6-arm feature-ablation suite (`Full_Hybrid`, `Core_Hybrid_LeakageFree`, `Mesoscale_Only`, `Macroscale_Only`, `Nonlinear_Only`, `Spectral_Only`).
