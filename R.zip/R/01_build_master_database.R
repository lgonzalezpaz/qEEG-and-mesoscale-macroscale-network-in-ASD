# ==============================================================================
# 01_build_master_database.R
# ==============================================================================
# Refactored from: Session001_Database_Construction (Corrected).R
#
# Purpose:
#   Ingests individual subject-level qEEG Excel workbooks from
#   `training_dataset/` (or legacy raw dataset directory) and consolidates
#   two structurally clean tables:
#     1) `biophysical`: Electrode x ROI biophysical & connectivity records
#     2) `graphs`:      Subject-level global functional graph topology metrics
#
# Key Refinements & Bug Fixes over Session001:
#   - Portable CLI/env/relative path resolution (no hardcoded home directory).
#   - Safe handling of the 17th clinical Diagnosis column present in `non-ASD`
#     Excel files (retained cleanly as `file_diagnosis`, NA for ASD/TD files).
#   - Strict preservation of `record_id` (recording ID) and `cohort` (batch
#     prefix: "ASD", "TD", "non") across both biophysical and graph tables.
#   - Immediate numeric coercion on biophysical & graph continuous metrics while
#     preserving `centrality` (max betweenness centrality electrode) as categorical.
#   - Normalization of literal "nan"/"NaN"/"" strings to NA, plus mapping of
#     `O2` electrodes with missing `roi` to `"PN"` (matching `O1` and Mendeley ASD)
#     with full quality-control logging.
#   - Detection and removal of the 225 pure empty placeholder `non-ASD` rows
#     (where all biophysical and graph metrics are NaN), controlled via the flag
#     `REPRODUCE_ORIGINAL_4834` (FALSE = clean N=4,609 cohort; TRUE = N=4,834).
# ==============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(readxl)
})

# ------------------------------------------------------------------------------
# 0. PORTABLE CONFIGURATION & CLI ARGUMENT PARSING
# ------------------------------------------------------------------------------
parse_cli_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  opts <- list(
    input_dir = Sys.getenv("ASD_EEG_DATA_DIR", unset = ""),
    output_dir = Sys.getenv("ASD_EEG_OUT_DIR", unset = ""),
    reproduce_4834 = tolower(Sys.getenv("ASD_REPRODUCE_4834", unset = "false")) %in% c("true", "1", "yes"),
    map_o2_to_pn = !tolower(Sys.getenv("ASD_MAP_O2_PN", unset = "true")) %in% c("false", "0", "no"),
    write_xlsx = tolower(Sys.getenv("ASD_WRITE_XLSX", unset = "false")) %in% c("true", "1", "yes")
  )
  for (arg in args) {
    if (grepl("^--input-dir=", arg))      opts$input_dir <- sub("^--input-dir=", "", arg)
    if (grepl("^--output-dir=", arg))     opts$output_dir <- sub("^--output-dir=", "", arg)
    if (grepl("^--reproduce-4834=", arg)) opts$reproduce_4834 <- tolower(sub("^--reproduce-4834=", "", arg)) %in% c("true", "1", "yes")
    if (grepl("^--map-o2-pn=", arg))      opts$map_o2_to_pn <- tolower(sub("^--map-o2-pn=", "", arg)) %in% c("true", "1", "yes")
    if (grepl("^--write-xlsx=", arg))     opts$write_xlsx <- tolower(sub("^--write-xlsx=", "", arg)) %in% c("true", "1", "yes")
  }
  opts
}

resolve_data_dir <- function(user_dir = "") {
  candidates <- c(
    user_dir,
    getwd(),
    file.path(getwd(), "data"),
    file.path(getwd(), "..", "data"),
    file.path(getwd(), "..", ".."),
    file.path(getwd(), "..", "..", "Directorio 20260518"),
    file.path(getwd(), "..", "..", "..", "Directorio 20260518")
  )
  candidates <- unique(candidates[nzchar(candidates)])
  for (cand in candidates) {
    if (dir.exists(file.path(cand, "training_dataset")) ||
        dir.exists(file.path(cand, "DataSet_entrenamiento"))) {
      return(normalizePath(cand, winslash = "/", mustWork = FALSE))
    }
  }
  stop(
    "Could not locate raw Excel workbook folder ('training_dataset/' or legacy dataset folder). ",
    "Pass --input-dir=/path/to/data or set ASD_EEG_DATA_DIR."
  )
}

resolve_output_dir <- function(user_out = "", data_dir = getwd()) {
  if (nzchar(user_out)) {
    out_dir <- user_out
  } else {
    out_dir <- file.path(getwd(), "outputs")
    if (basename(getwd()) == "R") {
      out_dir <- file.path(dirname(getwd()), "outputs")
    }
  }
  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  normalizePath(out_dir, winslash = "/", mustWork = FALSE)
}

opts <- parse_cli_args()
REPRODUCE_ORIGINAL_4834 <- opts$reproduce_4834
MAP_O2_MISSING_TO_PN    <- opts$map_o2_to_pn
WRITE_XLSX_OUTPUT       <- opts$write_xlsx

DATA_DIR <- resolve_data_dir(opts$input_dir)
OUT_DIR  <- resolve_output_dir(opts$output_dir, DATA_DIR)

input_folder <- if (dir.exists(file.path(DATA_DIR, "training_dataset"))) {
  file.path(DATA_DIR, "training_dataset")
} else {
  file.path(DATA_DIR, "DataSet_entrenamiento")
}
all_files   <- sort(list.files(path = input_folder, pattern = "\\.xlsx$", full.names = TRUE))
total_files <- length(all_files)

if (total_files == 0) {
  stop("No .xlsx files found inside: ", input_folder)
}

cat("==============================================================================\n")
cat("  01_build_master_database.R | Multi-Cohort qEEG Ingestion Pipeline\n")
cat("==============================================================================\n")
cat("Input directory        :", input_folder, "\n")
cat("Output directory       :", OUT_DIR, "\n")
cat("Total Excel files      :", total_files, "\n")
cat("MAP_O2_MISSING_TO_PN   :", MAP_O2_MISSING_TO_PN, "\n")
cat("REPRODUCE_ORIGINAL_4834:", REPRODUCE_ORIGINAL_4834, "\n\n")

# ------------------------------------------------------------------------------
# 1. DEFENSIVE PARSING HELPERS (SUPPORTS ENGLISH & LEGACY RAW WORKBOOK HEADERS)
# ------------------------------------------------------------------------------
clean_chr_na <- function(x) {
  x_chr <- trimws(as.character(x))
  x_chr[is.na(x) | x_chr == "" | tolower(x_chr) %in% c("nan", "na", "null", "none")] <- NA_character_
  x_chr
}

safe_as_numeric <- function(x) {
  if (is.numeric(x)) {
    x[!is.finite(x)] <- NA_real_
    return(as.numeric(x))
  }
  x_chr <- clean_chr_na(x)
  x_chr <- gsub(",", ".", x_chr, fixed = TRUE)
  suppressWarnings(as.numeric(x_chr))
}

pick_col <- function(df, candidates, file_path) {
  hit <- intersect(candidates, names(df))
  if (length(hit) == 0) {
    stop("File ", basename(file_path), " is missing required column (tried: ",
         paste(candidates, collapse = " / "), ")")
  }
  df[[hit[1]]]
}

normalize_record_id <- function(x) {
  sub("^no-ASD", "non-ASD", clean_chr_na(x))
}

translate_roi_raw <- function(x) {
  s <- clean_chr_na(x)
  dplyr::case_when(
    is.na(s) ~ NA_character_,
    stringr::str_detect(s, "(?i)\\bOFC\\b|Orbitofrontal")         ~ "OFC",
    stringr::str_detect(s, "(?i)\\bIFG\\b|Frontal Inferior|Inferior Frontal") ~ "IFG",
    stringr::str_detect(s, "(?i)\\bACC\\b|Cingulado|Cingulate|\\bSMA\\b")    ~ "ACC/SMA",
    stringr::str_detect(s, "(?i)\\bPPC\\b|Parietal Post")         ~ "PPC",
    stringr::str_detect(s, "(?i)\\bSTS\\b|\\bFG\\b|Fusiform")     ~ "STS/FG",
    stringr::str_detect(s, "(?i)Subcortical|\\bBG\\b")            ~ "BG/SN/Th/PN",
    stringr::str_detect(s, "(?i)Am[ií]gdala|Amygdala|^A\\s*\\(")  ~ "Amygdala",
    stringr::str_detect(s, "(?i)^PN$")                            ~ "PN",
    TRUE ~ s
  )
}

translate_connectivity_raw <- function(x) {
  s <- clean_chr_na(x)
  dplyr::case_when(
    is.na(s) ~ NA_character_,
    stringr::str_detect(s, "(?i)Hipo-conectivo")    ~ "Hypoconnected (Stable)",
    stringr::str_detect(s, "(?i)H[ií]per-conectivo") ~ "Hyperconnected (Critical)",
    stringr::str_detect(s, "(?i)Hipoconectividad")   ~ "Hypoconnected",
    stringr::str_detect(s, "(?i)Hiperconectividad")  ~ "Hyperconnected",
    stringr::str_detect(s, "(?i)Mixta")              ~ "Mixed (Local Hyper / Long Hypo)",
    TRUE ~ s
  )
}

process_excel_workbook <- function(file_path) {
  case_id      <- normalize_record_id(tools::file_path_sans_ext(basename(file_path)))
  batch_prefix <- stringr::str_extract(case_id, "^[A-Za-z]+")

  df <- tryCatch(
    readxl::read_excel(file_path, .name_repair = "minimal"),
    error = function(e) {
      warning("Failed to read Excel file: ", file_path, " | ", conditionMessage(e))
      return(NULL)
    }
  )
  if (is.null(df) || nrow(df) == 0) return(NULL)

  # Handle optional 17th clinical Diagnosis column present in non-ASD Excel files
  diag_hit <- intersect(c("Diagnosis", "Diagnóstico", "Diagnostico"), names(df))
  diag_col <- if (length(diag_hit) > 0) clean_chr_na(df[[diag_hit[1]]]) else rep(NA_character_, nrow(df))

  df_renamed <- tibble::tibble(
    theta                = safe_as_numeric(pick_col(df, c("Theta (θ)", "theta"), file_path)),
    sigma                = safe_as_numeric(pick_col(df, c("Sigma (σ)", "sigma"), file_path)),
    hurst                = safe_as_numeric(pick_col(df, c("Hurst (H)", "hurst"), file_path)),
    shannon              = safe_as_numeric(pick_col(df, c("Shannon Ent.", "shannon"), file_path)),
    ratio.at             = safe_as_numeric(pick_col(df, c("Ratio A/T", "ratio.at"), file_path)),
    node_weight          = safe_as_numeric(pick_col(df, c("Node_Weight", "Nodo_Peso", "node_weight"), file_path)),
    electrode            = clean_chr_na(pick_col(df, c("Electrode", "Electrodo", "electrode"), file_path)),
    roi                  = translate_roi_raw(pick_col(df, c("ROI", "roi"), file_path)),
    deficits             = clean_chr_na(pick_col(df, c("Deficits", "Déficits", "deficits"), file_path)),
    connectivity_profile = translate_connectivity_raw(pick_col(df, c("Connectivity Profile", "Perfil Conectividad", "connectivity_profile"), file_path)),
    mean_degree          = safe_as_numeric(pick_col(df, c("Mean Degree", "Grado Medio (Midgrade)", "mean_degree"), file_path)),
    centrality           = clean_chr_na(pick_col(df, c("Max Centrality (Electrode)", "Centralidad Max (Electrodo)", "centrality"), file_path)),
    efficiency           = safe_as_numeric(pick_col(df, c("Global Efficiency", "Eficiencia Global", "efficiency"), file_path)),
    path_length          = safe_as_numeric(pick_col(df, c("Characteristic Path Length (L)", "Longitud de Camino (L)", "path_length"), file_path)),
    modularity           = safe_as_numeric(pick_col(df, c("Modularity (Q)", "Modularidad (Q)", "modularity"), file_path)),
    clustering           = safe_as_numeric(pick_col(df, c("Clustering Coefficient", "Coef. Agrupamiento (Clustering)", "clustering"), file_path)),
    file_diagnosis       = diag_col
  )

  biophysical_tbl <- df_renamed %>%
    dplyr::select(theta, sigma, hurst, shannon, ratio.at, node_weight, electrode, roi, deficits, connectivity_profile, file_diagnosis) %>%
    dplyr::mutate(
      record_id = case_id,
      cohort    = batch_prefix
    ) %>%
    dplyr::select(record_id, cohort, dplyr::everything())

  graphs_tbl <- df_renamed %>%
    dplyr::select(mean_degree, centrality, efficiency, path_length, modularity, clustering, file_diagnosis) %>%
    dplyr::slice(1) %>%
    dplyr::mutate(
      record_id = case_id,
      cohort    = batch_prefix
    ) %>%
    dplyr::select(record_id, cohort, dplyr::everything())

  list(biophysical = biophysical_tbl, graphs = graphs_tbl)
}

# ------------------------------------------------------------------------------
# 2. BATCH INGESTION
# ------------------------------------------------------------------------------
batch_size <- 500L
n_batches  <- ceiling(total_files / batch_size)

biophysical_list <- vector("list", n_batches)
graphs_list      <- vector("list", n_batches)

for (i in seq_len(n_batches)) {
  cat(sprintf("--- Processing batch %d of %d ---\n", i, n_batches))
  start_idx <- (i - 1L) * batch_size + 1L
  end_idx   <- min(i * batch_size, total_files)
  batch_files <- all_files[start_idx:end_idx]

  batch_results <- lapply(batch_files, process_excel_workbook) %>% purrr::compact()
  biophysical_list[[i]] <- dplyr::bind_rows(lapply(batch_results, `[[`, "biophysical"))
  graphs_list[[i]]      <- dplyr::bind_rows(lapply(batch_results, `[[`, "graphs"))
}

df_biophysical_raw <- dplyr::bind_rows(biophysical_list)
df_graphs_raw      <- dplyr::bind_rows(graphs_list)

# ------------------------------------------------------------------------------
# 3. QUALITY CONTROL: O2 -> PN MAPPING & EMPTY PLACEHOLDER DETECTION
# ------------------------------------------------------------------------------
bio_metric_cols  <- c("theta", "sigma", "hurst", "shannon", "ratio.at", "node_weight")
graf_metric_cols <- c("mean_degree", "efficiency", "path_length", "modularity", "clustering")

# A) Audit O2 rows with missing ROI
o2_missing_mask <- !is.na(df_biophysical_raw$electrode) &
  df_biophysical_raw$electrode == "O2" &
  is.na(df_biophysical_raw$roi)

o2_missing_counts <- df_biophysical_raw %>%
  dplyr::filter(o2_missing_mask) %>%
  dplyr::count(cohort, name = "n_o2_missing_roi")

cat("\n>>> Audit: O2 rows with missing ROI before mapping:\n")
print(o2_missing_counts)

if (MAP_O2_MISSING_TO_PN) {
  df_biophysical_raw <- df_biophysical_raw %>%
    dplyr::mutate(
      roi = dplyr::if_else(electrode == "O2" & is.na(roi), "PN", roi)
    )
  cat(sprintf("✔ Mapped %d O2 rows with missing ROI -> 'PN'.\n", sum(o2_missing_mask)))
}

# B) Identify pure empty placeholder subjects (all biophysical + all graph values NA)
bio_subject_empty <- df_biophysical_raw %>%
  dplyr::mutate(
    .row_has_bio = rowSums(!is.na(as.matrix(dplyr::select(., dplyr::all_of(bio_metric_cols))))) > 0
  ) %>%
  dplyr::group_by(record_id, cohort, file_diagnosis) %>%
  dplyr::summarise(
    n_rows      = dplyr::n(),
    all_bio_na  = !any(.row_has_bio),
    all_elec_na = all(is.na(electrode)),
    .groups     = "drop"
  )

graf_subject_empty <- df_graphs_raw %>%
  dplyr::mutate(
    all_graf_na = (rowSums(!is.na(as.matrix(dplyr::select(., dplyr::all_of(graf_metric_cols))))) == 0) &
      is.na(centrality)
  ) %>%
  dplyr::select(record_id, all_graf_na)

subject_qc <- bio_subject_empty %>%
  dplyr::left_join(graf_subject_empty, by = "record_id") %>%
  dplyr::mutate(is_empty_placeholder = all_bio_na & all_graf_na)

empty_subjects <- subject_qc %>% dplyr::filter(is_empty_placeholder)
cat(sprintf("\n>>> Audit: Pure empty placeholder subjects detected: %d (out of %d total files)\n",
            nrow(empty_subjects), nrow(subject_qc)))
if (nrow(empty_subjects) > 0) {
  print(dplyr::count(empty_subjects, cohort, file_diagnosis, name = "n_empty"))
}

write.csv(
  empty_subjects,
  file.path(OUT_DIR, "QC_01_Empty_Placeholder_Subjects.csv"),
  row.names = FALSE
)

if (!REPRODUCE_ORIGINAL_4834) {
  valid_ids <- subject_qc %>%
    dplyr::filter(!is_empty_placeholder) %>%
    dplyr::pull(record_id)

  df_biophysical_final <- df_biophysical_raw %>% dplyr::filter(record_id %in% valid_ids)
  df_graphs_final      <- df_graphs_raw %>% dplyr::filter(record_id %in% valid_ids)
  cat(sprintf("✔ Clean cohort mode active: retained %d valid subjects (dropped %d empty placeholders).\n",
              length(valid_ids), nrow(empty_subjects)))
} else {
  df_biophysical_final <- df_biophysical_raw
  df_graphs_final      <- df_graphs_raw
  cat(sprintf("✔ Legacy reproduction mode active (REPRODUCE_ORIGINAL_4834 = TRUE): retained all %d subjects.\n",
              nrow(subject_qc)))
}

# Log any residual missing ROI rows after O2 mapping
residual_na_roi <- df_biophysical_final %>% dplyr::filter(is.na(roi))
cat(sprintf("-> Residual rows with NA roi in final biophysical table: %d\n", nrow(residual_na_roi)))

# ------------------------------------------------------------------------------
# 4. EXPORT CONSOLIDATED MASTER DATABASE
# ------------------------------------------------------------------------------
qc_summary <- list(
  total_files_read         = total_files,
  o2_missing_roi_mapped    = sum(o2_missing_mask),
  empty_placeholders_found = nrow(empty_subjects),
  reproduce_original_4834  = REPRODUCE_ORIGINAL_4834,
  map_o2_missing_to_pn     = MAP_O2_MISSING_TO_PN,
  final_subjects           = nrow(df_graphs_final),
  final_biophysical_rows   = nrow(df_biophysical_final),
  cohort_counts            = table(df_graphs_final$cohort, useNA = "ifany")
)

saveRDS(
  list(biophysical = df_biophysical_final, graphs = df_graphs_final, qc = qc_summary),
  file = file.path(OUT_DIR, "Database_master_raw_list.rds")
)

write.csv(
  df_biophysical_final,
  file.path(OUT_DIR, "Database_trainingdata_biof_clean.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)
write.csv(
  df_graphs_final,
  file.path(OUT_DIR, "Database_trainingdata_graf_clean.csv"),
  row.names = FALSE,
  fileEncoding = "UTF-8"
)

if (WRITE_XLSX_OUTPUT) {
  if (!requireNamespace("openxlsx", quietly = TRUE)) {
    warning("Package 'openxlsx' not installed; skipping .xlsx export.")
  } else {
    wb <- openxlsx::createWorkbook()
    openxlsx::addWorksheet(wb, "biophysical")
    openxlsx::addWorksheet(wb, "graphs")
    openxlsx::writeData(wb, "biophysical", df_biophysical_final)
    openxlsx::writeData(wb, "graphs", df_graphs_final)
    openxlsx::saveWorkbook(
      wb,
      file.path(OUT_DIR, "Database_trainingdata_complete_clean.xlsx"),
      overwrite = TRUE
    )
  }
}

sink(file.path(OUT_DIR, "QC_01_Ingestion_Summary.txt"))
cat("==============================================================================\n")
cat("  01_build_master_database.R - INGESTION & QUALITY CONTROL REPORT\n")
cat("==============================================================================\n")
cat("Timestamp               :", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")
cat("Total Excel files read  :", qc_summary$total_files_read, "\n")
cat("O2 missing ROI mapped   :", qc_summary$o2_missing_roi_mapped, "\n")
cat("Empty placeholders found:", qc_summary$empty_placeholders_found, "\n")
cat("REPRODUCE_ORIGINAL_4834 :", qc_summary$reproduce_original_4834, "\n")
cat("Final unique subjects   :", qc_summary$final_subjects, "\n")
cat("Final biophysical rows  :", qc_summary$final_biophysical_rows, "\n")
cat("\nCohort distribution (`cohort`):\n")
print(qc_summary$cohort_counts)
cat("\nResidual NA roi rows    :", nrow(residual_na_roi), "\n")
sink()

cat("\n✔ 01_build_master_database.R completed successfully.\n")
cat("  Saved RDS : ", file.path(OUT_DIR, "Database_master_raw_list.rds"), "\n")
cat("  Saved CSVs: Database_trainingdata_biof_clean.csv, Database_trainingdata_graf_clean.csv\n")
