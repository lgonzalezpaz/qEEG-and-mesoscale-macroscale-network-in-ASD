# ==============================================================================
# 04_multilevel_lme_and_decoupling.R
# ==============================================================================
# Refactored from: Session004_Phase3_Multilevel_Modeling_Graph_Integration.R
#
# Purpose:
#   Fits Multilevel Linear Mixed-Effects (LME) models testing how clinical
#   diagnosis, anatomical ROI, and global functional graph topology modulate
#   local cortical entropy (Shannon) and fractal persistence (Hurst), and
#   quantifies frontal meso-macro decoupling across ASD, TD, non-ASD, and
#   non-ASD clinical sub-pathologies via Fisher's r-to-z tests.
#
# Key Refinements & Bug Fixes over Session004:
#   1. Numeric coercion BEFORE `lmer()`: coerces `mean_degree`, `efficiency`,
#      `path_length`, `modularity`, `clustering` to `numeric` prior to LME fitting
#      so `efficiency` and `modularity` enter with `Df = 1` continuous slope
#      rather than factor dummy coding (`Df = 1340` and `4457` in Session004).
#   2. Multi-site random intercept control: adds `(1 | Source)` alongside
#      `(1 | record_id)` in both LME models (`REML = TRUE`, `bobyqa` optimizer).
#   3. Regex order fix (Bug 4): matches `"IFG"` BEFORE `"STS|FG|Fusiform"` in
#      `roi_abbrev` assignment. Previously `"IFG"` matched `"FG"` first, causing
#      all IFG observations to be misclassified as `"STS/FG"` and restricting
#      `df_frontal` to OFC-only (`r_ASD = -0.0365`). Now reports BOTH combined
#      `OFC + IFG` (primary, `r_ASD = -0.0409` pre-ComBat / harmonized value) and
#      `OFC-only` matrices for full transparency.
#   4. Export variable-name fix: references `model_shannon` and `model_hurst`
#      consistently, adds `emmeans` post-hoc contrasts, and exports all ANOVA,
#      fixed-effect, post-hoc, sub-pathology correlation, and Fisher's z-test tables.
# ==============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(lme4)
  library(car)
  library(broom)
  library(broom.mixed)
  library(emmeans)
})

HAS_LMERTEST <- requireNamespace("lmerTest", quietly = TRUE)

# ------------------------------------------------------------------------------
# 0. PORTABLE PATH RESOLUTION
# ------------------------------------------------------------------------------
parse_cli_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  opts <- list(
    input_dir  = Sys.getenv("ASD_EEG_DATA_DIR", unset = ""),
    output_dir = Sys.getenv("ASD_EEG_OUT_DIR", unset = "")
  )
  for (arg in args) {
    if (grepl("^--input-dir=", arg))  opts$input_dir <- sub("^--input-dir=", "", arg)
    if (grepl("^--output-dir=", arg)) opts$output_dir <- sub("^--output-dir=", "", arg)
  }
  opts
}

resolve_rds_path <- function(filename, user_dir = "", user_out = "", required = TRUE) {
  candidates <- unique(c(
    if (nzchar(user_out)) file.path(user_out, filename) else "",
    if (nzchar(user_dir)) file.path(user_dir, filename) else "",
    file.path(getwd(), "outputs", filename),
    file.path(getwd(), filename),
    file.path(dirname(getwd()), "outputs", filename)
  ))
  candidates <- candidates[nzchar(candidates)]
  for (p in candidates) {
    if (file.exists(p)) return(normalizePath(p, winslash = "/", mustWork = FALSE))
  }
  if (required) stop("Missing required RDS file '", filename, "'. Run 02_harmonization_and_roi_aggregation.R first.")
  ""
}

resolve_output_dir <- function(user_out = "") {
  if (nzchar(user_out)) {
    out_dir <- user_out
  } else {
    out_dir <- file.path(getwd(), "outputs")
    if (basename(getwd()) == "R") out_dir <- file.path(dirname(getwd()), "outputs")
  }
  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  normalizePath(out_dir, winslash = "/", mustWork = FALSE)
}

opts <- parse_cli_args()
OUT_DIR <- resolve_output_dir(opts$output_dir)
RDS_HARM_PATH <- resolve_rds_path("master_harmonized_roi.rds", opts$input_dir, OUT_DIR, required = TRUE)
RDS_RAW_PATH  <- resolve_rds_path("master_unharmonized_roi.rds", opts$input_dir, OUT_DIR, required = FALSE)

cat("==============================================================================\n")
cat("  04_multilevel_lme_and_decoupling.R | LME & Meso-Macro Decoupling\n")
cat("==============================================================================\n")
cat("Harmonized RDS   :", RDS_HARM_PATH, "\n")
cat("Unharmonized RDS :", if (nzchar(RDS_RAW_PATH)) RDS_RAW_PATH else "(not found; skipping pre-ComBat audit)", "\n")
cat("Output directory :", OUT_DIR, "\n\n")

# ------------------------------------------------------------------------------
# 1. LOAD DATA & FIX NUMERIC COERCION + ROI REGEX CLASSIFICATION
# ------------------------------------------------------------------------------
prepare_long_lme <- function(df_master) {
  graf_num_cols <- intersect(c("mean_degree", "efficiency", "path_length", "modularity", "clustering"), names(df_master))
  df_master <- df_master %>%
    dplyr::mutate(
      dplyr::across(dplyr::all_of(graf_num_cols), ~ suppressWarnings(as.numeric(as.character(.))))
    )

  roi_cols <- grep("_roi$", names(df_master), value = TRUE)
  if (length(roi_cols) == 0) {
    stop("No *_roi columns detected in input wide matrix.")
  }

  # Pivot only observed (record_id, roi) rows (`values_drop_na = TRUE`)
  df_long <- df_master %>%
    tidyr::pivot_longer(
      cols           = dplyr::all_of(roi_cols),
      names_to       = c("roi", ".value"),
      names_pattern  = "^(.+)_(theta_roi|sigma_roi|hurst_roi|shannon_roi|ratio\\.at_roi|node_weight_roi)$",
      values_drop_na = TRUE
    ) %>%
    dplyr::mutate(
      # BUG 4 FIX: Match IFG BEFORE STS|FG|Fusiform ("IFG" contains substring "FG"!)
      roi_abbrev = dplyr::case_when(
        stringr::str_detect(roi, "(?i)\\bOFC\\b|Orbitofrontal")                 ~ "OFC",
        stringr::str_detect(roi, "(?i)\\bIFG\\b|Inferior Frontal|Frontal Inferior") ~ "IFG",
        stringr::str_detect(roi, "(?i)\\bPPC\\b|Parietal Post")                 ~ "PPC",
        stringr::str_detect(roi, "(?i)\\bACC\\b|Cingulate|Cingulado|\\bSMA\\b") ~ "ACC/SMA",
        stringr::str_detect(roi, "(?i)\\bSTS\\b|\\bFG\\b|Fusiform|Fusiforme")   ~ "STS/FG",
        stringr::str_detect(roi, "(?i)Subcortical|\\bBG\\b")                    ~ "Subcortical",
        stringr::str_detect(roi, "(?i)Amygdala|Am[ií]gdala|^A\\s*\\(")          ~ "Amygdala",
        stringr::str_detect(roi, "(?i)^PN$")                                    ~ "PN",
        TRUE ~ as.character(roi)
      ),
      diagnostic_group = factor(diagnostic_group, levels = c("TD", "ASD", "non-ASD")),
      roi_abbrev       = as.factor(roi_abbrev),
      record_id        = as.factor(record_id),
      Source           = as.factor(Source)
    )

  # Strict assertions against Bug 3 & Bug 4 regressions
  stopifnot(is.numeric(df_long$efficiency))
  stopifnot(is.numeric(df_long$modularity))
  stopifnot(sum(df_long$roi_abbrev == "IFG") > 0)
  stopifnot(sum(df_long$roi_abbrev == "STS/FG") > 0)

  df_long
}

df_master_harm <- readRDS(RDS_HARM_PATH)
df_lme_long    <- prepare_long_lme(df_master_harm)

cat(">>> Observations per normalized ROI (`roi_abbrev`):\n")
print(table(df_lme_long$roi_abbrev, df_lme_long$diagnostic_group))

# ------------------------------------------------------------------------------
# 2. FIT MULTILEVEL LINEAR MIXED-EFFECTS MODELS (WITH `1 | Source` + `1 | record_id`)
# ------------------------------------------------------------------------------
cat("\n--- Step 2: Fitting Multilevel LME Models (REML + Multi-Site Control) ---\n")

fit_lme <- function(formula, data) {
  ctrl <- lme4::lmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 2e5))
  if (HAS_LMERTEST) {
    lmerTest::lmer(formula, data = data, REML = TRUE, control = ctrl)
  } else {
    lme4::lmer(formula, data = data, REML = TRUE, control = ctrl)
  }
}

model_shannon <- fit_lme(
  shannon_roi ~ diagnostic_group * roi_abbrev + efficiency + (1 | Source) + (1 | record_id),
  data = df_lme_long
)

model_hurst <- fit_lme(
  hurst_roi ~ diagnostic_group * roi_abbrev + modularity + (1 | Source) + (1 | record_id),
  data = df_lme_long
)

safe_anova_type3 <- function(model) {
  tryCatch(
    car::Anova(model, type = "III"),
    error = function(e) {
      message("car::Anova(type='III') encountered rank-deficient interaction cells (",
              conditionMessage(e), "); falling back to Satterthwaite/Type-III anova() or Type-II Wald.")
      if (HAS_LMERTEST && inherits(model, "lmerModLmerTest")) {
        as.data.frame(stats::anova(model, type = 3))
      } else {
        car::Anova(model, type = "II")
      }
    }
  )
}

anova_shannon <- safe_anova_type3(model_shannon)
anova_hurst   <- safe_anova_type3(model_hurst)

cat("\n=== TYPE III ANOVA: SHANNON ENTROPY ===\n")
print(anova_shannon)
cat("\n=== TYPE III ANOVA: HURST EXPONENT ===\n")
print(anova_hurst)

# Critical regression assertion: continuous covariates MUST have Df == 1 (never factor dummy coded!)
df_col_sh <- if ("Df" %in% names(anova_shannon)) "Df" else if ("NumDF" %in% names(anova_shannon)) "NumDF" else names(anova_shannon)[1]
df_col_hu <- if ("Df" %in% names(anova_hurst)) "Df" else if ("NumDF" %in% names(anova_hurst)) "NumDF" else names(anova_hurst)[1]
stopifnot(anova_shannon["efficiency", df_col_sh] == 1)
stopifnot(anova_hurst["modularity", df_col_hu] == 1)
cat("\n✔ Verified continuous Df = 1 for `efficiency` and `modularity` (dummy-coding bug eliminated).\n")

# Sensitivity LME restricted to the 5 Core Cross-Diagnostic ROIs (zero empty cells across groups)
core_rois <- c("OFC", "ACC/SMA", "PPC", "STS/FG", "PN")
df_lme_core <- df_lme_long %>%
  dplyr::filter(roi_abbrev %in% core_rois) %>%
  dplyr::mutate(roi_abbrev = droplevels(roi_abbrev))

model_shannon_core <- fit_lme(
  shannon_roi ~ diagnostic_group * roi_abbrev + efficiency + (1 | Source) + (1 | record_id),
  data = df_lme_core
)
model_hurst_core <- fit_lme(
  hurst_roi ~ diagnostic_group * roi_abbrev + modularity + (1 | Source) + (1 | record_id),
  data = df_lme_core
)
anova_shannon_core <- safe_anova_type3(model_shannon_core)
anova_hurst_core   <- safe_anova_type3(model_hurst_core)
df_col_sh_core <- if ("Df" %in% names(anova_shannon_core)) "Df" else if ("NumDF" %in% names(anova_shannon_core)) "NumDF" else names(anova_shannon_core)[1]
df_col_hu_core <- if ("Df" %in% names(anova_hurst_core)) "Df" else if ("NumDF" %in% names(anova_hurst_core)) "NumDF" else names(anova_hurst_core)[1]
stopifnot(anova_shannon_core["efficiency", df_col_sh_core] == 1)
stopifnot(anova_hurst_core["modularity", df_col_hu_core] == 1)

# ------------------------------------------------------------------------------
# 3. POST-HOC CONTRASTS (`emmeans`)
# ------------------------------------------------------------------------------
cat("\n--- Step 3: Computing Post-Hoc Contrasts (`emmeans`) ---\n")
emmeans::emm_options(lmer.df = "asymptotic")

posthoc_shannon_by_roi <- emmeans::emmeans(
  model_shannon, pairwise ~ diagnostic_group | roi_abbrev, adjust = "tukey"
)
posthoc_hurst_by_roi <- emmeans::emmeans(
  model_hurst, pairwise ~ diagnostic_group | roi_abbrev, adjust = "tukey"
)
posthoc_shannon_global <- emmeans::emmeans(
  model_shannon, pairwise ~ diagnostic_group, adjust = "tukey"
)
posthoc_hurst_global <- emmeans::emmeans(
  model_hurst, pairwise ~ diagnostic_group, adjust = "tukey"
)

df_posthoc_shannon <- dplyr::bind_rows(
  as.data.frame(posthoc_shannon_global$contrasts) %>% dplyr::mutate(roi_abbrev = "GLOBAL_MARGINAL", .before = 1),
  as.data.frame(posthoc_shannon_by_roi$contrasts)
)
df_posthoc_hurst <- dplyr::bind_rows(
  as.data.frame(posthoc_hurst_global$contrasts) %>% dplyr::mutate(roi_abbrev = "GLOBAL_MARGINAL", .before = 1),
  as.data.frame(posthoc_hurst_by_roi$contrasts)
)

# ------------------------------------------------------------------------------
# 4. FRONTAL MESO-MACRO DECOUPLING & FISHER'S Z-TESTS (OFC+IFG vs OFC-ONLY)
# ------------------------------------------------------------------------------
cat("\n--- Step 4: Frontal Meso-Macro Correlation & Fisher's z-Tests ---\n")

fisher_r_to_z <- function(r1, n1, r2, n2) {
  if (any(is.na(c(r1, n1, r2, n2))) || n1 <= 3 || n2 <= 3) {
    return(list(z = NA_real_, p = NA_real_))
  }
  r1_c <- max(min(r1, 0.999999), -0.999999)
  r2_c <- max(min(r2, 0.999999), -0.999999)
  z1   <- atanh(r1_c)
  z2   <- atanh(r2_c)
  se   <- sqrt(1 / (n1 - 3) + 1 / (n2 - 3))
  z    <- (z1 - z2) / se
  p    <- 2 * stats::pnorm(-abs(z))
  list(z = z, p = p)
}

compute_frontal_decoupling <- function(df_long, stage_label = "ComBat_Harmonized") {
  region_defs <- list(
    "OFC+IFG_Combined" = c("OFC", "IFG"),
    "OFC_Only"         = c("OFC")
  )

  corr_rows   <- list()
  fisher_rows <- list()

  for (reg_name in names(region_defs)) {
    rois_use <- region_defs[[reg_name]]
    df_front <- df_long %>%
      dplyr::filter(roi_abbrev %in% rois_use) %>%
      dplyr::group_by(record_id, diagnostic_group, subpathology) %>%
      dplyr::summarise(
        shannon_frontal = mean(shannon_roi, na.rm = TRUE),
        hurst_frontal   = mean(hurst_roi, na.rm = TRUE),
        efficiency      = mean(efficiency, na.rm = TRUE),
        modularity      = mean(modularity, na.rm = TRUE),
        .groups         = "drop"
      )

    # A) Diagnostic group summary correlations
    groups_check <- c("ASD", "TD", "non-ASD")
    group_stats  <- list()
    for (g in groups_check) {
      sg <- df_front %>%
        dplyr::filter(diagnostic_group == g) %>%
        dplyr::select(shannon_frontal, hurst_frontal, efficiency, modularity) %>%
        tidyr::drop_na()
      n_g <- nrow(sg)
      r_se <- if (n_g > 3) stats::cor(sg$shannon_frontal, sg$efficiency, method = "pearson") else NA_real_
      r_hm <- if (n_g > 3) stats::cor(sg$hurst_frontal, sg$modularity, method = "pearson") else NA_real_
      r_sh <- if (n_g > 3) stats::cor(sg$shannon_frontal, sg$hurst_frontal, method = "pearson") else NA_real_
      r_em <- if (n_g > 3) stats::cor(sg$efficiency, sg$modularity, method = "pearson") else NA_real_
      p_se <- if (n_g > 3) stats::cor.test(sg$shannon_frontal, sg$efficiency)$p.value else NA_real_
      p_hm <- if (n_g > 3) stats::cor.test(sg$hurst_frontal, sg$modularity)$p.value else NA_real_

      group_stats[[g]] <- list(n = n_g, r_se = r_se, r_hm = r_hm)
      corr_rows[[length(corr_rows) + 1]] <- tibble::tibble(
        Stage              = stage_label,
        Frontal_Definition = reg_name,
        Stratum_Type       = "Diagnostic_Group",
        Group              = g,
        N                  = n_g,
        r_Shannon_Eff      = r_se,
        p_Shannon_Eff      = p_se,
        r_Hurst_Mod        = r_hm,
        p_Hurst_Mod        = p_hm,
        r_Shannon_Hurst    = r_sh,
        r_Eff_Mod          = r_em
      )
    }

    # B) non-ASD sub-pathologies
    subpaths <- df_front %>%
      dplyr::filter(diagnostic_group == "non-ASD", !is.na(subpathology)) %>%
      dplyr::pull(subpathology) %>%
      unique() %>%
      sort()

    for (sp in subpaths) {
      sg <- df_front %>%
        dplyr::filter(diagnostic_group == "non-ASD", subpathology == sp) %>%
        dplyr::select(shannon_frontal, hurst_frontal, efficiency, modularity) %>%
        tidyr::drop_na()
      n_sp <- nrow(sg)
      if (n_sp < 6) next
      r_se <- stats::cor(sg$shannon_frontal, sg$efficiency, method = "pearson")
      r_hm <- stats::cor(sg$hurst_frontal, sg$modularity, method = "pearson")
      r_sh <- stats::cor(sg$shannon_frontal, sg$hurst_frontal, method = "pearson")
      r_em <- stats::cor(sg$efficiency, sg$modularity, method = "pearson")
      p_se <- stats::cor.test(sg$shannon_frontal, sg$efficiency)$p.value
      p_hm <- stats::cor.test(sg$hurst_frontal, sg$modularity)$p.value

      corr_rows[[length(corr_rows) + 1]] <- tibble::tibble(
        Stage              = stage_label,
        Frontal_Definition = reg_name,
        Stratum_Type       = "nonASD_Subpathology",
        Group              = sp,
        N                  = n_sp,
        r_Shannon_Eff      = r_se,
        p_Shannon_Eff      = p_se,
        r_Hurst_Mod        = r_hm,
        p_Hurst_Mod        = p_hm,
        r_Shannon_Hurst    = r_sh,
        r_Eff_Mod          = r_em
      )

      # Fisher's z vs ASD
      fz_se <- fisher_r_to_z(group_stats[["ASD"]]$r_se, group_stats[["ASD"]]$n, r_se, n_sp)
      fz_hm <- fisher_r_to_z(group_stats[["ASD"]]$r_hm, group_stats[["ASD"]]$n, r_hm, n_sp)
      fisher_rows[[length(fisher_rows) + 1]] <- tibble::tibble(
        Stage              = stage_label,
        Frontal_Definition = reg_name,
        Comparison         = paste("ASD vs", sp),
        N1 = group_stats[["ASD"]]$n, r1_Shannon_Eff = group_stats[["ASD"]]$r_se,
        N2 = n_sp, r2_Shannon_Eff = r_se,
        Fisher_z_Shannon_Eff = fz_se$z, p_Shannon_Eff = fz_se$p,
        r1_Hurst_Mod = group_stats[["ASD"]]$r_hm, r2_Hurst_Mod = r_hm,
        Fisher_z_Hurst_Mod = fz_hm$z, p_Hurst_Mod = fz_hm$p
      )
    }

    # C) Pairwise Fisher's z among main diagnostic groups
    pairs <- list(c("ASD", "TD"), c("ASD", "non-ASD"), c("TD", "non-ASD"))
    for (pr in pairs) {
      g1 <- pr[1]; g2 <- pr[2]
      fz_se <- fisher_r_to_z(group_stats[[g1]]$r_se, group_stats[[g1]]$n, group_stats[[g2]]$r_se, group_stats[[g2]]$n)
      fz_hm <- fisher_r_to_z(group_stats[[g1]]$r_hm, group_stats[[g1]]$n, group_stats[[g2]]$r_hm, group_stats[[g2]]$n)
      fisher_rows[[length(fisher_rows) + 1]] <- tibble::tibble(
        Stage              = stage_label,
        Frontal_Definition = reg_name,
        Comparison         = paste(g1, "vs", g2),
        N1 = group_stats[[g1]]$n, r1_Shannon_Eff = group_stats[[g1]]$r_se,
        N2 = group_stats[[g2]]$n, r2_Shannon_Eff = group_stats[[g2]]$r_se,
        Fisher_z_Shannon_Eff = fz_se$z, p_Shannon_Eff = fz_se$p,
        r1_Hurst_Mod = group_stats[[g1]]$r_hm, r2_Hurst_Mod = group_stats[[g2]]$r_hm,
        Fisher_z_Hurst_Mod = fz_hm$z, p_Hurst_Mod = fz_hm$p
      )
    }
  }

  df_corr <- dplyr::bind_rows(corr_rows)
  df_fz   <- dplyr::bind_rows(fisher_rows) %>%
    dplyr::group_by(Stage, Frontal_Definition) %>%
    dplyr::mutate(
      p_adj_BH_Shannon_Eff = stats::p.adjust(p_Shannon_Eff, method = "BH"),
      p_adj_BH_Hurst_Mod   = stats::p.adjust(p_Hurst_Mod, method = "BH")
    ) %>%
    dplyr::ungroup()

  list(correlations = df_corr, fisher_z = df_fz)
}

decoupling_harm <- compute_frontal_decoupling(df_lme_long, stage_label = "ComBat_Harmonized")
print(decoupling_harm$correlations %>% dplyr::mutate(dplyr::across(where(is.numeric), ~ round(., 4))))
print(decoupling_harm$fisher_z %>% dplyr::select(Frontal_Definition, Comparison, r1_Shannon_Eff, r2_Shannon_Eff, Fisher_z_Shannon_Eff, p_adj_BH_Shannon_Eff))

write.csv(decoupling_harm$correlations, file.path(OUT_DIR, "Frontal_Decoupling_Correlations_ByGroup.csv"), row.names = FALSE)
write.csv(decoupling_harm$fisher_z,     file.path(OUT_DIR, "Frontal_Decoupling_FisherZ_Tests.csv"), row.names = FALSE)

if (nzchar(RDS_RAW_PATH)) {
  df_lme_raw_long <- prepare_long_lme(readRDS(RDS_RAW_PATH))
  decoupling_raw  <- compute_frontal_decoupling(df_lme_raw_long, stage_label = "PreComBat_Unharmonized")
  write.csv(decoupling_raw$correlations, file.path(OUT_DIR, "Frontal_Decoupling_Unharmonized_Audit.csv"), row.names = FALSE)
  write.csv(decoupling_raw$fisher_z,     file.path(OUT_DIR, "Frontal_Decoupling_Unharmonized_FisherZ.csv"), row.names = FALSE)
}

# ------------------------------------------------------------------------------
# 5. EXPORT LME TABLES & REPORT
# ------------------------------------------------------------------------------
cat("\n--- Step 5: Exporting LME Tables, Post-Hoc Contrasts, and Text Report ---\n")

saveRDS(df_lme_long, file = file.path(OUT_DIR, "phase3_lme_ready_long.rds"))

write.csv(as.data.frame(anova_shannon) %>% tibble::rownames_to_column("Term"),
          file.path(OUT_DIR, "LME_ANOVA_Shannon.csv"), row.names = FALSE)
write.csv(as.data.frame(anova_hurst) %>% tibble::rownames_to_column("Term"),
          file.path(OUT_DIR, "LME_ANOVA_Hurst.csv"), row.names = FALSE)
write.csv(as.data.frame(anova_shannon_core) %>% tibble::rownames_to_column("Term"),
          file.path(OUT_DIR, "LME_ANOVA_Shannon_CoreROIs.csv"), row.names = FALSE)
write.csv(as.data.frame(anova_hurst_core) %>% tibble::rownames_to_column("Term"),
          file.path(OUT_DIR, "LME_ANOVA_Hurst_CoreROIs.csv"), row.names = FALSE)

write.csv(broom.mixed::tidy(model_shannon, effects = "fixed", conf.int = TRUE),
          file.path(OUT_DIR, "LME_Regression_Coefficients_Shannon.csv"), row.names = FALSE)
write.csv(broom.mixed::tidy(model_hurst, effects = "fixed", conf.int = TRUE),
          file.path(OUT_DIR, "LME_Regression_Coefficients_Hurst.csv"), row.names = FALSE)

write.csv(df_posthoc_shannon, file.path(OUT_DIR, "PostHoc_Comparisons_Shannon.csv"), row.names = FALSE)
write.csv(df_posthoc_hurst,   file.path(OUT_DIR, "PostHoc_Comparisons_Hurst.csv"),   row.names = FALSE)

sink(file.path(OUT_DIR, "LME_Inferential_Statistics_Report.txt"))
cat("==============================================================================\n")
cat("  MULTISCALE INFERENTIAL REPORT: LINEAR MIXED-EFFECTS MODELS & DECOUPLING\n")
cat("==============================================================================\n")
cat("Timestamp       :", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")
cat("Estimation      : REML (lme4/lmerTest, bobyqa optimizer)\n")
cat("Random Effects  : (1 | Source) + (1 | record_id)\n")
cat("Long Rows (N)   :", nrow(df_lme_long), "| Unique Subjects:", dplyr::n_distinct(df_lme_long$record_id), "\n")
cat("==============================================================================\n\n")

cat(">>> 1. LME MODEL: SHANNON ENTROPY (ALL ROIs) <<<\n")
print(summary(model_shannon))
cat("\n[Type III Wald Chi-Square Table - Shannon]\n")
print(anova_shannon)
cat("\n[Sensitivity Type III Wald Chi-Square - Core 5 Cross-Cohort ROIs]\n")
print(anova_shannon_core)
cat("\n------------------------------------------------------------------------------\n\n")

cat(">>> 2. LME MODEL: HURST EXPONENT (ALL ROIs) <<<\n")
print(summary(model_hurst))
cat("\n[Type III Wald Chi-Square Table - Hurst]\n")
print(anova_hurst)
cat("\n[Sensitivity Type III Wald Chi-Square - Core 5 Cross-Cohort ROIs]\n")
print(anova_hurst_core)
cat("\n------------------------------------------------------------------------------\n\n")

cat(">>> 3. EMMEANS POST-HOC CONTRASTS (TUKEY-ADJUSTED) <<<\n")
cat("[Shannon Entropy - Global & By ROI]\n")
print(df_posthoc_shannon)
cat("\n[Hurst Exponent - Global & By ROI]\n")
print(df_posthoc_hurst)
cat("\n------------------------------------------------------------------------------\n\n")

cat(">>> 4. FRONTAL MESO-MACRO DECOUPLING (OFC+IFG vs OFC-ONLY) & FISHER'S Z <<<\n")
print(decoupling_harm$correlations)
cat("\n[Fisher's r-to-z Contrasts (BH-Adjusted)]\n")
print(decoupling_harm$fisher_z)
cat("==============================================================================\n")
sink()

# Colorblind-safe decoupling visualization
df_plot_front <- df_lme_long %>%
  dplyr::filter(roi_abbrev %in% c("OFC", "IFG")) %>%
  dplyr::group_by(record_id, diagnostic_group) %>%
  dplyr::summarise(
    shannon_frontal = mean(shannon_roi, na.rm = TRUE),
    efficiency      = mean(efficiency, na.rm = TRUE),
    .groups         = "drop"
  ) %>%
  tidyr::drop_na()

p_decoupling <- ggplot2::ggplot(df_plot_front, ggplot2::aes(x = efficiency, y = shannon_frontal, color = diagnostic_group)) +
  ggplot2::geom_point(alpha = 0.25, size = 0.9) +
  ggplot2::geom_smooth(method = "lm", se = TRUE, linewidth = 1.1) +
  ggplot2::facet_wrap(~ diagnostic_group, scales = "free") +
  ggplot2::scale_color_manual(values = c("TD" = "#0072B2", "ASD" = "#D55E00", "non-ASD" = "#009E73"), guide = "none") +
  ggplot2::labs(
    title    = "Frontal (OFC + IFG) Meso-Macro Coupling vs. ASD Decoupling",
    subtitle = "Post-ComBat relationship between Global Efficiency and Frontal Shannon Entropy",
    x        = "Global Graph Efficiency (Harmonized)",
    y        = "Frontal Shannon Entropy (OFC + IFG Mean)"
  ) +
  ggplot2::theme_minimal(base_size = 12)
ggplot2::ggsave(file.path(OUT_DIR, "Fig_Frontal_MesoMacro_Decoupling.pdf"), plot = p_decoupling, width = 10, height = 4.5)

cat("\n✔ 04_multilevel_lme_and_decoupling.R completed successfully.\n")
