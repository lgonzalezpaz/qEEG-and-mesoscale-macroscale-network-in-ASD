# ==============================================================================
# 02_harmonization_and_roi_aggregation.R
# ==============================================================================
# Combines & refactors:
#   - Session002_Phase1_Neurocombat.R
#   - Session003_Phase2_ROI_Reduction.R
#   - Session006_Unify_Cohort_Metadata.R
#
# Key Refinements & Bug Fixes:
#   1. Full multi-repository metadata integration from ALL 3 sheets ("ASD", "TD",
#      "non-ASD") of `complete_metadata.xlsx` (preserving `Source`, `Subject_ID`,
#      and `Pathology` / `subpathology`), with automatic fallback for legacy
#      source workbooks.
#   2. Fixes the Session006 graph column misalignment bug: NEVER drops `cohort`
#      carelessly or shifts columns (`electrode = centrality`, `centrality =
#      efficiency`, ...). Preserves `centrality` (max betweenness centrality
#      electrode) as categorical character/factor and coerces `mean_degree`,
#      `efficiency`, `path_length`, `modularity`, `clustering` to `numeric`
#      immediately (never passing `centrality` into `as.matrix()`).
#   3. Implements genuine Empirical Bayes location-scale batch harmonization
#      (`sva::ComBat` / `neuroCombat`, with an exact Johnson et al. 2007 pure-R
#      Empirical Bayes fallback) across all acquisition sources (`Source`)
#      protecting `diagnostic_group`, alongside pre- vs. post-harmonization
#      `ICC_source` quantification (overall, diagnosis-adjusted, and within-TD).
#   4. Eliminates `NA_*_roi` and `nan_*_roi` artifact columns during wide ROI
#      pivoting by mapping `O2` missing `roi` -> `"PN"`, filtering unmapped
#      placeholders, and explicitly asserting zero artifact columns.
# ==============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(readxl)
  library(lme4)
})

# ------------------------------------------------------------------------------
# 0. PORTABLE PATH RESOLUTION & CONFIGURATION
# ------------------------------------------------------------------------------
parse_cli_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  opts <- list(
    input_dir = Sys.getenv("ASD_EEG_DATA_DIR", unset = ""),
    output_dir = Sys.getenv("ASD_EEG_OUT_DIR", unset = ""),
    reproduce_4834 = tolower(Sys.getenv("ASD_REPRODUCE_4834", unset = "false")) %in% c("true", "1", "yes"),
    apply_signed_log1p = !tolower(Sys.getenv("ASD_LOG1P_POWER", unset = "true")) %in% c("false", "0", "no"),
    harmonize_graphs = !tolower(Sys.getenv("ASD_HARMONIZE_GRAPHS", unset = "true")) %in% c("false", "0", "no")
  )
  for (arg in args) {
    if (grepl("^--input-dir=", arg))         opts$input_dir <- sub("^--input-dir=", "", arg)
    if (grepl("^--output-dir=", arg))        opts$output_dir <- sub("^--output-dir=", "", arg)
    if (grepl("^--reproduce-4834=", arg))    opts$reproduce_4834 <- tolower(sub("^--reproduce-4834=", "", arg)) %in% c("true", "1", "yes")
    if (grepl("^--apply-signed-log1p=", arg)) opts$apply_signed_log1p <- tolower(sub("^--apply-signed-log1p=", "", arg)) %in% c("true", "1", "yes")
    if (grepl("^--harmonize-graphs=", arg))  opts$harmonize_graphs <- tolower(sub("^--harmonize-graphs=", "", arg)) %in% c("true", "1", "yes")
  }
  opts
}

resolve_data_dir <- function(user_dir = "") {
  candidates <- c(
    user_dir,
    getwd(),
    file.path(getwd(), "data"),
    file.path(getwd(), "..", "data"),
    file.path(getwd(), "..", "data_summary"),
    file.path(getwd(), "data_summary"),
    file.path(getwd(), "..", "..", "Directorio 20260518"),
    file.path(getwd(), "..", "..", "..", "Directorio 20260518")
  )
  candidates <- unique(candidates[nzchar(candidates)])
  for (cand in candidates) {
    if (file.exists(file.path(cand, "complete_metadata.xlsx")) ||
        file.exists(file.path(cand, "metadatos_completos (1).xlsx")) ||
        file.exists(file.path(cand, "Database_trainningdata_biof.csv"))) {
      return(normalizePath(cand, winslash = "/", mustWork = FALSE))
    }
  }
  stop("Could not locate data directory containing 'complete_metadata.xlsx'. Set --input-dir or ASD_EEG_DATA_DIR.")
}

resolve_output_dir <- function(user_out = "") {
  if (nzchar(user_out)) {
    out_dir <- user_out
  } else {
    out_dir <- file.path(getwd(), "outputs")
    if (basename(getwd()) == "R") out_dir <- file.path(dirname(getwd()), "outputs")
  }
  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  normalizePath(out_dir, winslash = "/", mustWork = FALSE)
}

opts <- parse_cli_args()
DATA_DIR <- resolve_data_dir(opts$input_dir)
OUT_DIR  <- resolve_output_dir(opts$output_dir)

cat("==============================================================================\n")
cat("  02_harmonization_and_roi_aggregation.R\n")
cat("==============================================================================\n")
cat("Data directory      :", DATA_DIR, "\n")
cat("Output directory    :", OUT_DIR, "\n")
cat("Signed log1p power  :", opts$apply_signed_log1p, "\n")
cat("Harmonize graphs    :", opts$harmonize_graphs, "\n\n")

# ------------------------------------------------------------------------------
# 1. DEFENSIVE HELPERS & EMPIRICAL BAYES COMBAT ENGINE
# ------------------------------------------------------------------------------
clean_chr_na <- function(x) {
  x_chr <- trimws(as.character(x))
  x_chr[is.na(x) | x_chr == "" | tolower(x_chr) %in% c("nan", "na", "null", "none")] <- NA_character_
  x_chr
}

safe_as_numeric <- function(x) {
  if (is.numeric(x)) {
    x[!is.finite(x)] <- NA_real_
    return(as.numeric(x))
  }
  x_chr <- clean_chr_na(x)
  x_chr <- gsub(",", ".", x_chr, fixed = TRUE)
  suppressWarnings(as.numeric(x_chr))
}

safe_mean <- function(x) {
  if (all(is.na(x))) NA_real_ else mean(x, na.rm = TRUE)
}

signed_log1p <- function(x) {
  sign(x) * log1p(abs(x))
}

normalize_record_id <- function(x) {
  sub("^no-ASD", "non-ASD", clean_chr_na(x))
}

#' Pure-R Parametric Empirical Bayes ComBat (Johnson et al., 2007)
#' Used automatically only if neither `sva::ComBat` nor `neuroCombat::neuroCombat` is installed.
combat_eb_r <- function(dat, batch, mod = NULL) {
  dat <- as.matrix(dat)
  storage.mode(dat) <- "double"
  n_features <- nrow(dat)
  n_samples  <- ncol(dat)

  batch_f <- droplevels(as.factor(batch))
  batches <- levels(batch_f)
  n_batch <- length(batches)
  if (n_batch < 2L) return(dat)

  batch_design <- stats::model.matrix(~ 0 + batch_f)
  colnames(batch_design) <- batches

  if (!is.null(mod) && ncol(mod) > 0L) {
    mod_mat <- as.matrix(mod)
    is_intercept <- apply(mod_mat, 2, function(col) all(abs(col - 1) < 1e-12))
    mod_cov <- mod_mat[, !is_intercept, drop = FALSE]
    design <- cbind(batch_design, mod_cov)
  } else {
    mod_cov <- NULL
    design <- batch_design
  }

  qr_des <- qr(design)
  if (qr_des$rank < ncol(design)) {
    stop("Design matrix in ComBat is rank-deficient (rank = ", qr_des$rank, " < ", ncol(design), ").")
  }
  B_hat <- qr.solve(qr_des, t(dat))

  n_per_batch <- colSums(batch_design)
  grand_mean  <- as.numeric((n_per_batch / n_samples) %*% B_hat[seq_len(n_batch), , drop = FALSE])

  stand_mean <- matrix(grand_mean, nrow = n_features, ncol = n_samples, byrow = FALSE)
  if (!is.null(mod_cov) && ncol(mod_cov) > 0L) {
    bio_beta   <- B_hat[-seq_len(n_batch), , drop = FALSE]
    stand_mean <- stand_mean + t(mod_cov %*% bio_beta)
  }

  resid_full <- dat - t(design %*% B_hat)
  var_pooled <- rowMeans(resid_full^2)
  var_pooled[var_pooled < 1e-18] <- 1e-18
  sd_pooled  <- sqrt(var_pooled)

  s_data <- (dat - stand_mean) / sd_pooled

  gamma_hat <- matrix(0, nrow = n_batch, ncol = n_features)
  delta_hat <- matrix(1, nrow = n_batch, ncol = n_features)
  for (i in seq_len(n_batch)) {
    idx <- which(batch_f == batches[i])
    gamma_hat[i, ] <- rowMeans(s_data[, idx, drop = FALSE])
    if (length(idx) > 1L) {
      delta_hat[i, ] <- apply(s_data[, idx, drop = FALSE], 1, stats::var)
    }
  }
  delta_hat[is.na(delta_hat) | delta_hat < 1e-12] <- 1e-12

  gamma_bar <- rowMeans(gamma_hat)
  t2 <- apply(gamma_hat, 1, stats::var)
  t2[is.na(t2) | t2 < 1e-12] <- 1e-12

  aprior <- function(d) {
    m  <- mean(d)
    s2 <- stats::var(d)
    if (is.na(s2) || s2 < 1e-18) return(2.0)
    (2 * s2 + m^2) / s2
  }
  bprior <- function(d) {
    m  <- mean(d)
    s2 <- stats::var(d)
    if (is.na(s2) || s2 < 1e-18) return(max(m, 1.0))
    (m * s2 + m^3) / s2
  }

  a_prior <- apply(delta_hat, 1, aprior)
  b_prior <- apply(delta_hat, 1, bprior)

  gamma_star <- gamma_hat
  delta_star <- delta_hat

  for (i in seq_len(n_batch)) {
    idx  <- which(batch_f == batches[i])
    n_i  <- length(idx)
    sdat <- s_data[, idx, drop = FALSE]
    g_old <- gamma_hat[i, ]
    d_old <- delta_hat[i, ]

    for (iter in seq_len(200L)) {
      g_new <- (t2[i] * n_i * gamma_hat[i, ] + d_old * gamma_bar[i]) / (t2[i] * n_i + d_old)
      sum2  <- rowSums((sdat - g_new)^2)
      d_new <- (0.5 * sum2 + b_prior[i]) / (n_i / 2.0 + a_prior[i] - 1.0)
      d_new[d_new < 1e-12] <- 1e-12

      chg <- max(
        max(abs(g_new - g_old) / (abs(g_old) + 1e-8)),
        max(abs(d_new - d_old) / (abs(d_old) + 1e-8))
      )
      g_old <- g_new
      d_old <- d_new
      if (chg < 1e-5) break
    }
    gamma_star[i, ] <- g_old
    delta_star[i, ] <- d_old
  }

  bayesdata <- s_data
  for (i in seq_len(n_batch)) {
    idx <- which(batch_f == batches[i])
    bayesdata[, idx] <- (s_data[, idx, drop = FALSE] - gamma_star[i, ]) / sqrt(delta_star[i, ])
  }

  bayesdata * sd_pooled + stand_mean
}

run_combat <- function(dat, batch, mod = NULL) {
  batch_f <- droplevels(as.factor(batch))
  if (nlevels(batch_f) < 2L) {
    return(list(dat = dat, backend = "single_batch_skip"))
  }

  row_vars <- apply(dat, 1, stats::var, na.rm = TRUE)
  active   <- which(!is.na(row_vars) & row_vars > 1e-18)
  if (length(active) < 2L) {
    return(list(dat = dat, backend = "insufficient_active_features"))
  }

  dat_act <- dat[active, , drop = FALSE]
  out_act <- NULL
  backend_used <- NULL

  if (requireNamespace("sva", quietly = TRUE)) {
    out_act <- tryCatch({
      backend_used <- "sva::ComBat"
      sva::ComBat(dat = dat_act, batch = batch_f, mod = mod, par.prior = TRUE, prior.plots = FALSE)
    }, error = function(e) {
      message("sva::ComBat failed (", conditionMessage(e), "); trying fallback.")
      NULL
    })
  }

  if (is.null(out_act) && requireNamespace("neuroCombat", quietly = TRUE)) {
    out_act <- tryCatch({
      backend_used <- "neuroCombat::neuroCombat"
      res <- neuroCombat::neuroCombat(dat = dat_act, batch = batch_f, mod = mod)
      res$dat.combat
    }, error = function(e) {
      message("neuroCombat failed (", conditionMessage(e), "); trying pure-R EB ComBat.")
      NULL
    })
  }

  if (is.null(out_act)) {
    backend_used <- "pureR::combat_eb_r (Johnson 2007)"
    out_act <- combat_eb_r(dat = dat_act, batch = batch_f, mod = mod)
  }

  res_full <- dat
  res_full[active, ] <- out_act
  list(dat = res_full, backend = backend_used)
}

compute_icc_source <- function(df, value_col, group_col = "Source", adjust_col = NULL) {
  sub <- df %>%
    dplyr::select(val = dplyr::all_of(value_col), grp = dplyr::all_of(group_col),
                  dplyr::any_of(adjust_col)) %>%
    dplyr::filter(!is.na(val), is.finite(val), !is.na(grp)) %>%
    dplyr::mutate(grp = droplevels(as.factor(grp)))

  if (nrow(sub) < 10 || nlevels(sub$grp) < 2) return(NA_real_)

  fml <- if (is.null(adjust_col)) {
    stats::as.formula("val ~ 1 + (1 | grp)")
  } else {
    sub$adj <- droplevels(as.factor(sub[[adjust_col]]))
    if (nlevels(sub$adj) < 2) {
      stats::as.formula("val ~ 1 + (1 | grp)")
    } else {
      stats::as.formula("val ~ adj + (1 | grp)")
    }
  }

  icc_val <- tryCatch({
    fit <- suppressMessages(suppressWarnings(lme4::lmer(fml, data = sub, REML = TRUE)))
    vc  <- as.data.frame(lme4::VarCorr(fit))
    v_b <- vc$vcov[vc$grp == "grp"]
    v_r <- vc$vcov[vc$grp == "Residual"]
    if (length(v_b) == 0 || (v_b + v_r) <= 0) 0 else v_b / (v_b + v_r)
  }, error = function(e) NA_real_)

  icc_val
}

# ------------------------------------------------------------------------------
# 2. INGEST FULL MULTI-REPOSITORY METADATA (ALL 3 SHEETS)
# ------------------------------------------------------------------------------
meta_xlsx_en <- file.path(DATA_DIR, "complete_metadata.xlsx")
meta_xlsx_legacy <- file.path(DATA_DIR, "metadatos_completos (1).xlsx")
meta_xlsx_path <- if (file.exists(meta_xlsx_en)) meta_xlsx_en else meta_xlsx_legacy
if (!file.exists(meta_xlsx_path)) {
  stop("Missing required full metadata file ('complete_metadata.xlsx') in: ", DATA_DIR)
}

cat("--- Step 1: Loading Full Multi-Repository Metadata (3 Sheets) ---\n")
sheets_meta <- readxl::excel_sheets(meta_xlsx_path)
third_sheet <- if ("non-ASD" %in% sheets_meta) "non-ASD" else "no-ASD"
expected_sheets <- c("ASD", "TD", third_sheet)
if (!all(expected_sheets %in% sheets_meta)) {
  stop("Expected sheets ", paste(expected_sheets, collapse = ", "), " in ", meta_xlsx_path)
}

read_meta_sheet <- function(sheet_name) {
  d <- readxl::read_excel(meta_xlsx_path, sheet = sheet_name)
  id_col  <- intersect(c("Metadata_ID", "Metadato"), names(d))[1]
  src_col <- intersect(c("Source", "Fuente"), names(d))[1]
  sub_col <- intersect(c("Subject_ID", "Sujeto"), names(d))[1]
  pat_hit <- intersect(c("Pathology", "Patología", "Patologia"), names(d))
  d %>%
    dplyr::transmute(
      record_id = normalize_record_id(.data[[id_col]]),
      Source    = clean_chr_na(.data[[src_col]]),
      Subject_ID = clean_chr_na(.data[[sub_col]]),
      diagnostic_group = dplyr::case_when(
        sheet_name == "ASD"                  ~ "ASD",
        sheet_name == "TD"                   ~ "TD",
        sheet_name %in% c("non-ASD", "no-ASD") ~ "non-ASD",
        TRUE                                 ~ NA_character_
      ),
      Pathology = if (length(pat_hit) > 0) clean_chr_na(.data[[pat_hit[1]]]) else NA_character_
    )
}

metadata_full <- dplyr::bind_rows(lapply(expected_sheets, read_meta_sheet)) %>%
  dplyr::mutate(
    subpathology = dplyr::case_when(
      diagnostic_group == "ASD" ~ "ASD",
      diagnostic_group == "TD"  ~ "TD",
      tolower(Pathology) %in% c("convulsiones", "seizures / epilepsy") ~ "Seizures",
      tolower(Pathology) %in% c("epilepsia", "epilepsy")               ~ "Epilepsy",
      tolower(Pathology) %in% c("parkinson", "parkinson's disease")    ~ "Parkinson",
      tolower(Pathology) %in% c("alzheimer", "alzheimer's disease")    ~ "Alzheimer",
      tolower(Pathology) %in% c("frontotemporal", "frontotemporal dementia") ~ "Frontotemporal",
      tolower(Pathology) %in% c("sibling asd", "unaffected asd sibling")     ~ "ASD_Sibling",
      TRUE ~ Pathology
    ),
    diagnostic_group = factor(diagnostic_group, levels = c("TD", "ASD", "non-ASD")),
    Source           = as.factor(Source)
  ) %>%
  dplyr::distinct(record_id, .keep_all = TRUE)

cat(sprintf("✔ Loaded metadata for %d subjects across %d acquisition sources (`Source`).\n",
            nrow(metadata_full), nlevels(metadata_full$Source)))
print(table(metadata_full$Source, metadata_full$diagnostic_group))

# ------------------------------------------------------------------------------
# 3. LOAD BIOPHYSICAL & GRAPH TABLES (FROM SCRIPT 01 OR LEGACY CSVs)
# ------------------------------------------------------------------------------
cat("\n--- Step 2: Loading Biophysical & Graph Data ---\n")
rds_path_out  <- file.path(OUT_DIR, "Database_master_raw_list.rds")
rds_path_data <- file.path(DATA_DIR, "Database_master_raw_list.rds")
biof_csv_path <- file.path(DATA_DIR, "Database_trainningdata_biof.csv")
graf_csv_path <- file.path(DATA_DIR, "Database_trainningdata_graf.csv")

if (file.exists(rds_path_out) || file.exists(rds_path_data)) {
  rds_use <- if (file.exists(rds_path_out)) rds_path_out else rds_path_data
  cat("-> Reading clean RDS from Script 01:", rds_use, "\n")
  raw_list <- readRDS(rds_use)
  df_biophysical_in <- raw_list$biophysical
  df_graphs_in      <- raw_list$graphs
} else if (file.exists(biof_csv_path) && file.exists(graf_csv_path)) {
  cat("-> Reading raw semicolon CSVs from:", DATA_DIR, "\n")
  df_biophysical_in <- readr::read_delim(
    biof_csv_path,
    delim = ";",
    col_types = readr::cols(.default = readr::col_character()),
    locale = readr::locale(encoding = "Latin1", decimal_mark = ","),
    show_col_types = FALSE
  ) %>%
    dplyr::rename(
      record_id            = cod,
      cohort               = data,
      node_weight          = peso,
      electrode            = electrodo,
      deficits             = def,
      connectivity_profile = conect
    )
  df_graphs_in <- readr::read_delim(
    graf_csv_path,
    delim = ";",
    col_types = readr::cols(.default = readr::col_character()),
    locale = readr::locale(encoding = "Latin1", decimal_mark = ","),
    show_col_types = FALSE
  ) %>%
    dplyr::rename(
      record_id   = cod,
      cohort      = data,
      mean_degree = midgrade,
      path_length = long
    )
} else {
  stop("No input database found. Run 01_build_master_database.R first or provide data CSVs.")
}

bio_cols  <- c("theta", "sigma", "hurst", "shannon", "ratio.at", "node_weight")
graf_cols <- c("mean_degree", "efficiency", "path_length", "modularity", "clustering")

df_biophysical_clean <- df_biophysical_in %>%
  dplyr::mutate(
    record_id            = normalize_record_id(record_id),
    cohort               = clean_chr_na(cohort),
    electrode            = clean_chr_na(electrode),
    roi                  = clean_chr_na(roi),
    deficits             = clean_chr_na(deficits),
    connectivity_profile = clean_chr_na(connectivity_profile),
    dplyr::across(dplyr::all_of(bio_cols), safe_as_numeric)
  )

# Map O2 missing ROI -> "PN"
o2_fix_count <- sum(!is.na(df_biophysical_clean$electrode) &
                    df_biophysical_clean$electrode == "O2" &
                    is.na(df_biophysical_clean$roi))
if (o2_fix_count > 0) {
  df_biophysical_clean <- df_biophysical_clean %>%
    dplyr::mutate(roi = dplyr::if_else(electrode == "O2" & is.na(roi), "PN", roi))
  cat(sprintf("✔ Mapped %d O2 rows with missing ROI -> 'PN'.\n", o2_fix_count))
}

# Fix Session006 bug: keep `centrality` as categorical hub electrode & numeric graph metrics
expected_graf_cols <- c("record_id", "cohort", "mean_degree", "centrality", "efficiency", "path_length", "modularity", "clustering")
if (!all(expected_graf_cols %in% names(df_graphs_in))) {
  stop("Graph table missing expected columns: ", paste(setdiff(expected_graf_cols, names(df_graphs_in)), collapse = ", "))
}

df_graphs_clean <- df_graphs_in %>%
  dplyr::mutate(
    record_id  = normalize_record_id(record_id),
    cohort     = clean_chr_na(cohort),
    centrality = clean_chr_na(centrality),
    dplyr::across(dplyr::all_of(graf_cols), safe_as_numeric)
  ) %>%
  dplyr::distinct(record_id, .keep_all = TRUE)

stopifnot(is.character(df_graphs_clean$centrality))
stopifnot(all(vapply(df_graphs_clean[, graf_cols], is.numeric, logical(1))))

# Identify and remove pure empty placeholder subjects (225 non-ASD all-NaN files)
valid_bio_ids <- df_biophysical_clean %>%
  dplyr::mutate(.has_val = rowSums(!is.na(as.matrix(dplyr::select(., dplyr::all_of(bio_cols))))) > 0) %>%
  dplyr::group_by(record_id) %>%
  dplyr::summarise(keep = any(.has_val), .groups = "drop") %>%
  dplyr::filter(keep) %>%
  dplyr::pull(record_id)

df_biophysical_clean <- df_biophysical_clean %>%
  dplyr::filter(record_id %in% valid_bio_ids, !is.na(electrode), !is.na(roi))
df_graphs_clean <- df_graphs_clean %>%
  dplyr::filter(record_id %in% valid_bio_ids)
n_before <- dplyr::n_distinct(df_biophysical_in$record_id)
if (n_before > length(valid_bio_ids)) {
  cat(sprintf("✔ Filtered empty placeholder subjects before harmonization: %d -> %d valid subjects.\n",
              n_before, length(valid_bio_ids)))
}

# Join full metadata (all 3 diagnosis groups across all repositories)
df_biophysical_joined <- df_biophysical_clean %>%
  dplyr::inner_join(
    metadata_full %>% dplyr::select(record_id, Source, Subject_ID, diagnostic_group, Pathology, subpathology),
    by = "record_id"
  )

df_graphs_joined <- df_graphs_clean %>%
  dplyr::inner_join(
    metadata_full %>% dplyr::select(record_id, Source, Subject_ID, diagnostic_group, Pathology, subpathology),
    by = "record_id"
  )

cat(sprintf("✔ Joined metadata: %d biophysical rows across %d subjects; %d graph rows.\n",
            nrow(df_biophysical_joined), dplyr::n_distinct(df_biophysical_joined$record_id), nrow(df_graphs_joined)))

# Handle sporadic missingness in graph metrics (e.g. 8 disconnected TD graphs where path_length = NaN)
n_missing_len <- sum(is.na(df_graphs_joined$path_length))
if (n_missing_len > 0) {
  cat(sprintf("-> Imputing %d NA values in `path_length` (disconnected empty graphs) using site/global median.\n", n_missing_len))
  global_med_len <- stats::median(df_graphs_joined$path_length, na.rm = TRUE)
  df_graphs_joined <- df_graphs_joined %>%
    dplyr::group_by(Source) %>%
    dplyr::mutate(
      path_length = dplyr::if_else(
        is.na(path_length),
        dplyr::coalesce(stats::median(path_length, na.rm = TRUE), global_med_len),
        path_length
      )
    ) %>%
    dplyr::ungroup()
}
df_graphs_joined <- df_graphs_joined %>%
  dplyr::mutate(
    centrality = dplyr::coalesce(centrality, "None"),
    dplyr::across(dplyr::all_of(graf_cols), ~ dplyr::if_else(is.na(.), stats::median(., na.rm = TRUE), .))
  )

# ------------------------------------------------------------------------------
# 4. EMPIRICAL BAYES COMBAT HARMONIZATION (BIOPHYSICAL + GRAPH)
# ------------------------------------------------------------------------------
cat("\n--- Step 3: Empirical Bayes Batch Harmonization (`Source`, protecting `diagnostic_group`) ---\n")

# Deduplicate (record_id, electrode) before ComBat so electrodes projecting to 2 ROIs are NOT double-counted
df_elec_unique <- df_biophysical_joined %>%
  dplyr::group_by(record_id, cohort, Source, Subject_ID, diagnostic_group, Pathology, subpathology, electrode) %>%
  dplyr::summarise(
    dplyr::across(dplyr::all_of(bio_cols), safe_mean),
    .groups = "drop"
  )

# Transform multi-scale spectral/weight metrics to stabilize extreme V^2 vs uV^2 variance prior to ComBat
df_elec_pre <- df_elec_unique
if (opts$apply_signed_log1p) {
  scale_cols <- c("theta", "sigma", "ratio.at", "node_weight")
  df_elec_pre <- df_elec_pre %>%
    dplyr::mutate(dplyr::across(dplyr::all_of(scale_cols), signed_log1p))
  cat("✔ Applied variance-stabilizing signed log1p transform to:", paste(scale_cols, collapse = ", "), "\n")
}

# Per-electrode ComBat across observed acquisition sources
df_elec_post <- df_elec_pre
electrodes_list <- sort(unique(df_elec_pre$electrode))
backends_used <- character(0)

for (el in electrodes_list) {
  idx <- which(df_elec_pre$electrode == el)
  sub <- df_elec_pre[idx, , drop = FALSE]
  sub_batch <- droplevels(as.factor(sub$Source))
  sub_diag  <- droplevels(as.factor(sub$diagnostic_group))

  if (nlevels(sub_batch) >= 2L) {
    mod_el <- if (nlevels(sub_diag) >= 2L) {
      stats::model.matrix(~ sub_diag)
    } else {
      NULL
    }
    Y_el <- t(as.matrix(sub[, bio_cols, drop = FALSE]))
    res_c <- run_combat(dat = Y_el, batch = sub_batch, mod = mod_el)
    backends_used <- unique(c(backends_used, res_c$backend))
    df_elec_post[idx, bio_cols] <- t(res_c$dat)
  }
}
cat("✔ Electrode-level ComBat completed. Backend(s) used:", paste(backends_used, collapse = ", "), "\n")

# Harmonize continuous macroscale graph metrics across `Source`
df_graphs_post <- df_graphs_joined
if (opts$harmonize_graphs) {
  g_batch <- droplevels(as.factor(df_graphs_joined$Source))
  g_diag  <- droplevels(as.factor(df_graphs_joined$diagnostic_group))
  mod_g   <- stats::model.matrix(~ g_diag)
  Y_g     <- t(as.matrix(df_graphs_joined[, graf_cols, drop = FALSE]))
  res_gc  <- run_combat(dat = Y_g, batch = g_batch, mod = mod_g)
  df_graphs_post[, graf_cols] <- t(res_gc$dat)
  cat("✔ Macroscale graph ComBat completed. Backend:", res_gc$backend, "\n")
}

# ------------------------------------------------------------------------------
# 5. PRE- VS. POST-HARMONIZATION ICC_SOURCE QUANTIFICATION
# ------------------------------------------------------------------------------
cat("\n--- Step 4: Computing Pre- vs. Post-Harmonization ICC_source ---\n")

icc_bio_rows <- purrr::map_dfr(bio_cols, function(col_nm) {
  pre_td  <- df_elec_pre %>% dplyr::filter(diagnostic_group == "TD")
  post_td <- df_elec_post %>% dplyr::filter(diagnostic_group == "TD")
  tibble::tibble(
    Domain                = "Mesoscale_Electrode",
    Metric                = col_nm,
    ICC_Uncond_Pre        = compute_icc_source(df_elec_pre, col_nm, "Source", NULL),
    ICC_Uncond_Post       = compute_icc_source(df_elec_post, col_nm, "Source", NULL),
    ICC_DiagAdj_Pre       = compute_icc_source(df_elec_pre, col_nm, "Source", "diagnostic_group"),
    ICC_DiagAdj_Post      = compute_icc_source(df_elec_post, col_nm, "Source", "diagnostic_group"),
    ICC_WithinTD_Pre      = compute_icc_source(pre_td, col_nm, "Source", NULL),
    ICC_WithinTD_Post     = compute_icc_source(post_td, col_nm, "Source", NULL)
  )
})

icc_graf_rows <- purrr::map_dfr(graf_cols, function(col_nm) {
  pre_td  <- df_graphs_joined %>% dplyr::filter(diagnostic_group == "TD")
  post_td <- df_graphs_post %>% dplyr::filter(diagnostic_group == "TD")
  tibble::tibble(
    Domain                = "Macroscale_Graph",
    Metric                = col_nm,
    ICC_Uncond_Pre        = compute_icc_source(df_graphs_joined, col_nm, "Source", NULL),
    ICC_Uncond_Post       = compute_icc_source(df_graphs_post, col_nm, "Source", NULL),
    ICC_DiagAdj_Pre       = compute_icc_source(df_graphs_joined, col_nm, "Source", "diagnostic_group"),
    ICC_DiagAdj_Post      = compute_icc_source(df_graphs_post, col_nm, "Source", "diagnostic_group"),
    ICC_WithinTD_Pre      = compute_icc_source(pre_td, col_nm, "Source", NULL),
    ICC_WithinTD_Post     = compute_icc_source(post_td, col_nm, "Source", NULL)
  )
})

df_icc_summary <- dplyr::bind_rows(icc_bio_rows, icc_graf_rows) %>%
  dplyr::mutate(
    Pct_Reduction_WithinTD = round(100 * (ICC_WithinTD_Pre - ICC_WithinTD_Post) / pmax(ICC_WithinTD_Pre, 1e-9), 2)
  )

print(df_icc_summary %>% dplyr::mutate(dplyr::across(where(is.numeric), ~ round(., 4))))
write.csv(df_icc_summary, file.path(OUT_DIR, "ICC_Pre_vs_Post_Harmonization.csv"), row.names = FALSE)

# ------------------------------------------------------------------------------
# 6. RE-ATTACH ANATOMICAL ROIs, AGGREGATE & PIVOT WIDE (ZERO NA_*/nan_* ARTIFACTS)
# ------------------------------------------------------------------------------
cat("\n--- Step 5: ROI Aggregation & Wide Matrix Assembly ---\n")

build_wide_master <- function(df_elec_table, df_graf_table, df_roi_map_src) {
  roi_map <- df_roi_map_src %>%
    dplyr::select(record_id, electrode, roi, deficits, connectivity_profile) %>%
    dplyr::filter(!is.na(roi), !tolower(trimws(roi)) %in% c("", "na", "nan")) %>%
    dplyr::distinct(record_id, electrode, roi, .keep_all = TRUE)

  df_long_roi <- roi_map %>%
    dplyr::inner_join(df_elec_table, by = c("record_id", "electrode"))

  df_roi_agg <- df_long_roi %>%
    dplyr::group_by(record_id, cohort, Source, Subject_ID, diagnostic_group, Pathology, subpathology, roi) %>%
    dplyr::summarise(
      theta_roi       = safe_mean(theta),
      sigma_roi       = safe_mean(sigma),
      hurst_roi       = safe_mean(hurst),
      shannon_roi     = safe_mean(shannon),
      ratio.at_roi    = safe_mean(ratio.at),
      node_weight_roi = safe_mean(node_weight),
      .groups         = "drop"
    )

  df_roi_wide <- df_roi_agg %>%
    tidyr::pivot_wider(
      id_cols     = c(record_id, cohort, Source, Subject_ID, diagnostic_group, Pathology, subpathology),
      names_from  = roi,
      values_from = c(theta_roi, sigma_roi, hurst_roi, shannon_roi, ratio.at_roi, node_weight_roi),
      names_glue  = "{roi}_{.value}"
    )

  df_out <- df_roi_wide %>%
    dplyr::inner_join(
      df_graf_table %>%
        dplyr::select(record_id, mean_degree, centrality, efficiency, path_length, modularity, clustering),
      by = "record_id"
    ) %>%
    dplyr::mutate(
      centrality = as.factor(centrality),
      dplyr::across(dplyr::all_of(graf_cols), as.numeric)
    )

  # Strict artifact column assertions
  bad_cols <- grep("^(NA|nan|na)_", names(df_out), value = TRUE, ignore.case = TRUE)
  if (length(bad_cols) > 0) {
    stop("Artifact ROI columns detected: ", paste(bad_cols, collapse = ", "))
  }

  list(wide = df_out, roi_long = df_roi_agg, elec_roi_long = df_long_roi)
}

res_harmonized   <- build_wide_master(df_elec_post, df_graphs_post, df_biophysical_joined)
res_unharmonized <- build_wide_master(df_elec_unique, df_graphs_joined, df_biophysical_joined)

df_master_harmonized   <- res_harmonized$wide
df_master_unharmonized <- res_unharmonized$wide

# Assert numeric integrity on all continuous graph columns & categorical centrality
stopifnot(is.factor(df_master_harmonized$centrality) || is.character(df_master_harmonized$centrality))
stopifnot(all(vapply(df_master_harmonized[, graf_cols], is.numeric, logical(1))))

# ------------------------------------------------------------------------------
# 7. EXPORT OUTPUTS & QC REPORT
# ------------------------------------------------------------------------------
saveRDS(df_master_harmonized,         file = file.path(OUT_DIR, "master_harmonized_roi.rds"))
saveRDS(df_master_unharmonized,       file = file.path(OUT_DIR, "master_unharmonized_roi.rds"))
saveRDS(res_harmonized$elec_roi_long, file = file.path(OUT_DIR, "biophysical_harmonized_long.rds"))

sink(file.path(OUT_DIR, "QC_02_Harmonization_Report.txt"))
cat("==============================================================================\n")
cat("  02_harmonization_and_roi_aggregation.R - HARMONIZATION & QC SUMMARY\n")
cat("==============================================================================\n")
cat("Timestamp               :", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")
cat("Total subjects exported :", nrow(df_master_harmonized), "\n")
cat("Total columns in wide   :", ncol(df_master_harmonized), "\n")
cat("Unique Source count     :", nlevels(droplevels(df_master_harmonized$Source)), "\n")
cat("ComBat backend(s)       :", paste(backends_used, collapse = ", "), "\n")
cat("O2 missing ROI mapped   :", o2_fix_count, "\n")
cat("Signed log1p applied    :", opts$apply_signed_log1p, "\n")
cat("Graphs harmonized       :", opts$harmonize_graphs, "\n\n")
cat("Diagnostic group distribution:\n")
print(table(df_master_harmonized$diagnostic_group, useNA = "ifany"))
cat("\nSubpathology breakdown:\n")
print(table(df_master_harmonized$subpathology, useNA = "ifany"))
cat("\nPre- vs. Post-Harmonization ICC_source:\n")
print(df_icc_summary %>% dplyr::mutate(dplyr::across(where(is.numeric), ~ round(., 4))))
sink()

cat("\n✔ 02_harmonization_and_roi_aggregation.R completed successfully.\n")
cat("  Subjects:", nrow(df_master_harmonized), "| Columns:", ncol(df_master_harmonized), "\n")
cat("  Saved: master_harmonized_roi.rds, master_unharmonized_roi.rds, ICC_Pre_vs_Post_Harmonization.csv\n")
