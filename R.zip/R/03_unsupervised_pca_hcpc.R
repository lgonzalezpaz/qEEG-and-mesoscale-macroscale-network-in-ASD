# ==============================================================================
# 03_unsupervised_pca_hcpc.R
# ==============================================================================
# Refactored from: Session002b_PCA_Cluster_Analysis.R
#
# Purpose:
#   Executes unsupervised orthogonal Principal Component Analysis (PCA) and
#   Hierarchical Clustering on Principal Components (HCPC) on the
#   ComBat-harmonized multi-scale qEEG matrix without using clinical labels.
#
# Key Refinements & Bug Fixes over Session002b:
#   1. Portable CLI/env/relative path resolution.
#   2. Fixes categorical `centrality` coercion bug: cleanly excludes `centrality`
#      (hub electrode string) from the numeric PCA matrix (eliminating the
#      zero-variance dummy dimension `comp 66 = 0` present in Session002b), while
#      testing categorical hub electrode distribution vs. diagnosis separately.
#   3. Coerces continuous graph metrics (`mean_degree, efficiency, path_length,
#      modularity, clustering`) to numeric cleanly and restricts primary PCA/HCPC
#      to cross-cohort core ROIs (<= 25% missingness across ASD/TD/non-ASD) to
#      prevent site-specific montage missingness (A/IFG/BG) from driving clusters,
#      with an explicit missingness audit logged.
#   4. Adds Pearson Chi-square, Cramér's V, and Adjusted Rand Index (ARI)
#      validation of unsupervised HCPC clusters against clinical diagnosis.
#   5. Exports colorblind-safe Okabe-Ito / Viridis publication-grade plots.
# ==============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(FactoMineR)
  library(factoextra)
})

# ------------------------------------------------------------------------------
# 0. PORTABLE PATH RESOLUTION & COLORBLIND-SAFE PALETTES
# ------------------------------------------------------------------------------
parse_cli_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  opts <- list(
    input_dir  = Sys.getenv("ASD_EEG_DATA_DIR", unset = ""),
    output_dir = Sys.getenv("ASD_EEG_OUT_DIR", unset = ""),
    max_missing_frac = 0.25
  )
  for (arg in args) {
    if (grepl("^--input-dir=", arg))        opts$input_dir <- sub("^--input-dir=", "", arg)
    if (grepl("^--output-dir=", arg))       opts$output_dir <- sub("^--output-dir=", "", arg)
    if (grepl("^--max-missing-frac=", arg)) opts$max_missing_frac <- as.numeric(sub("^--max-missing-frac=", "", arg))
  }
  opts
}

resolve_rds_path <- function(filename, user_dir = "", user_out = "") {
  candidates <- unique(c(
    if (nzchar(user_out)) file.path(user_out, filename) else "",
    if (nzchar(user_dir)) file.path(user_dir, filename) else "",
    file.path(getwd(), "outputs", filename),
    file.path(getwd(), filename),
    file.path(dirname(getwd()), "outputs", filename)
  ))
  candidates <- candidates[nzchar(candidates)]
  for (p in candidates) {
    if (file.exists(p)) return(normalizePath(p, winslash = "/", mustWork = FALSE))
  }
  stop("Could not find '", filename, "'. Run 02_harmonization_and_roi_aggregation.R first or specify --output-dir.")
}

resolve_output_dir <- function(user_out = "") {
  if (nzchar(user_out)) {
    out_dir <- user_out
  } else {
    out_dir <- file.path(getwd(), "outputs")
    if (basename(getwd()) == "R") out_dir <- file.path(dirname(getwd()), "outputs")
  }
  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  normalizePath(out_dir, winslash = "/", mustWork = FALSE)
}

opts <- parse_cli_args()
OUT_DIR  <- resolve_output_dir(opts$output_dir)
RDS_PATH <- resolve_rds_path("master_harmonized_roi.rds", opts$input_dir, OUT_DIR)

# Okabe-Ito colorblind-safe discrete palette (extended cleanly for up to 8 clusters)
OKABE_ITO <- c(
  "#0072B2", "#D55E00", "#009E73", "#CC79A7",
  "#E69F00", "#56B4E9", "#F0E442", "#333333"
)

DIAG_COLORS <- c(
  "TD"      = "#0072B2",
  "ASD"     = "#D55E00",
  "non-ASD" = "#009E73"
)

cat("==============================================================================\n")
cat("  03_unsupervised_pca_hcpc.R | Unsupervised PCA & HCPC Phenotyping\n")
cat("==============================================================================\n")
cat("Input RDS        :", RDS_PATH, "\n")
cat("Output directory :", OUT_DIR, "\n\n")

# ------------------------------------------------------------------------------
# 1. LOAD HARMONIZED MATRIX & SANITIZE NUMERIC FEATURE SPACE
# ------------------------------------------------------------------------------
df_master_raw <- readRDS(RDS_PATH)

meta_cols <- intersect(
  c("record_id", "cohort", "Source", "Subject_ID", "diagnostic_group", "Pathology", "subpathology", "centrality"),
  names(df_master_raw)
)
graf_num_cols <- intersect(c("mean_degree", "efficiency", "path_length", "modularity", "clustering"), names(df_master_raw))

df_master <- df_master_raw %>%
  dplyr::mutate(
    dplyr::across(dplyr::all_of(graf_num_cols), ~ suppressWarnings(as.numeric(as.character(.)))),
    diagnostic_group = factor(diagnostic_group, levels = c("TD", "ASD", "non-ASD"))
  )

clinical_labels <- df_master %>%
  dplyr::select(dplyr::any_of(c("record_id", "diagnostic_group", "Source", "Pathology", "subpathology", "centrality")))

# Candidate numeric predictors (strictly excluding metadata & categorical `centrality`)
candidate_num_cols <- setdiff(names(df_master), meta_cols)
df_candidates <- df_master %>%
  dplyr::select(dplyr::all_of(candidate_num_cols)) %>%
  dplyr::select(where(is.numeric))

# Audit missingness per feature; retain features observed across broad cohort (<= max_missing_frac)
missing_rates <- vapply(df_candidates, function(x) mean(is.na(x) | !is.finite(x)), numeric(1))
kept_cols     <- names(missing_rates)[missing_rates <= opts$max_missing_frac]
dropped_cols  <- names(missing_rates)[missing_rates > opts$max_missing_frac]

cat(sprintf("-> Total numeric predictors evaluated: %d\n", ncol(df_candidates)))
cat(sprintf("-> Retained (missingness <= %.0f%%)  : %d\n", opts$max_missing_frac * 100, length(kept_cols)))
if (length(dropped_cols) > 0) {
  cat(sprintf("-> Excluded site-restricted ROIs (> %.0f%% missing): %d columns\n",
              opts$max_missing_frac * 100, length(dropped_cols)))
}

df_numeric <- df_candidates %>%
  dplyr::select(dplyr::all_of(kept_cols)) %>%
  dplyr::mutate(dplyr::across(dplyr::everything(), ~ {
    x <- ifelse(is.finite(.), ., NA_real_)
    ifelse(is.na(x), stats::median(x, na.rm = TRUE), x)
  }))

# Remove zero-variance columns defensively
col_sds <- vapply(df_numeric, stats::sd, numeric(1))
zero_var_cols <- names(col_sds)[is.na(col_sds) | col_sds <= 1e-12]
if (length(zero_var_cols) > 0) {
  cat("-> Removing zero-variance columns:", paste(zero_var_cols, collapse = ", "), "\n")
  df_numeric <- df_numeric %>% dplyr::select(-dplyr::all_of(zero_var_cols))
}

stopifnot(ncol(df_numeric) >= 3)
stopifnot(all(vapply(df_numeric, is.numeric, logical(1))))
stopifnot(!anyNA(df_numeric))

cat(sprintf("✔ Clean numeric PCA matrix ready: %d subjects x %d predictors\n\n",
            nrow(df_numeric), ncol(df_numeric)))

# ------------------------------------------------------------------------------
# 2. ORTHOGONAL PCA (UNIT VARIANCE SCALING)
# ------------------------------------------------------------------------------
cat("--- Step 2: Computing Orthogonal PCA ---\n")
n_pcs_keep <- min(10L, ncol(df_numeric))
res_pca <- FactoMineR::PCA(df_numeric, scale.unit = TRUE, ncp = n_pcs_keep, graph = FALSE)

eig_df <- as.data.frame(res_pca$eig) %>%
  tibble::rownames_to_column("Component")
print(head(eig_df, 10))
write.csv(eig_df, file.path(OUT_DIR, "PCA_Eigenvalues_Variance.csv"), row.names = FALSE)

var_stats <- factoextra::get_pca_var(res_pca)
df_contributions <- as.data.frame(var_stats$contrib) %>%
  tibble::rownames_to_column("Variable") %>%
  dplyr::arrange(dplyr::desc(Dim.1))
df_cos2 <- as.data.frame(var_stats$cos2) %>%
  tibble::rownames_to_column("Variable") %>%
  dplyr::arrange(dplyr::desc(Dim.1))

write.csv(df_contributions, file.path(OUT_DIR, "PCA_Variable_Contributions_Full.csv"), row.names = FALSE)
write.csv(df_cos2,          file.path(OUT_DIR, "PCA_Variable_Quality_Cos2.csv"), row.names = FALSE)

cat("\n>>> Top 10 Variable Contributions to PC1:\n")
print(head(df_contributions %>% dplyr::select(Variable, Dim.1, Dim.2), 10))

# ------------------------------------------------------------------------------
# 3. HCPC CLUSTERING & STATISTICAL VALIDATION (CHI-SQUARE, CRAMER'S V, ARI)
# ------------------------------------------------------------------------------
cat("\n--- Step 3: Running HCPC & Clinical Concordance Validation ---\n")
set.seed(42)
res_hcpc <- FactoMineR::HCPC(res_pca, nb.clust = -1, consol = TRUE, graph = FALSE)

df_clusters_vs_real <- clinical_labels %>%
  dplyr::mutate(Cluster_HCPC = as.factor(res_hcpc$data.clust$clust))

cross_tab <- table(
  Diagnosis = df_clusters_vs_real$diagnostic_group,
  Cluster   = df_clusters_vs_real$Cluster_HCPC
)
print(cross_tab)

# Chi-square + Cramer's V
chi_test <- tryCatch(
  stats::chisq.test(cross_tab),
  warning = function(w) stats::chisq.test(cross_tab, simulate.p.value = TRUE, B = 5000)
)
n_total   <- sum(cross_tab)
min_dim   <- min(nrow(cross_tab), ncol(cross_tab)) - 1
cramers_v <- sqrt(as.numeric(chi_test$statistic) / (n_total * max(min_dim, 1)))

# Pure-R Adjusted Rand Index (Hubert & Arabie, 1985)
compute_ari <- function(a, b) {
  tab <- table(a, b)
  choose2 <- function(x) sum(x * (x - 1) / 2)
  sum_ij <- choose2(tab)
  sum_i  <- choose2(rowSums(tab))
  sum_j  <- choose2(colSums(tab))
  n_c2   <- choose2(sum(tab))
  expected <- (sum_i * sum_j) / n_c2
  max_idx  <- 0.5 * (sum_i + sum_j)
  if (max_idx == expected) return(0)
  (sum_ij - expected) / (max_idx - expected)
}
ari_val <- compute_ari(df_clusters_vs_real$diagnostic_group, df_clusters_vs_real$Cluster_HCPC)

# Auxiliary validation for categorical `centrality` (hub electrode) vs Diagnosis
centrality_stats <- if ("centrality" %in% names(df_clusters_vs_real)) {
  tab_cent <- table(df_clusters_vs_real$diagnostic_group, df_clusters_vs_real$centrality)
  chi_c <- suppressWarnings(stats::chisq.test(tab_cent, simulate.p.value = TRUE, B = 2000))
  cv_c  <- sqrt(as.numeric(chi_c$statistic) / (sum(tab_cent) * (min(dim(tab_cent)) - 1)))
  list(chisq = as.numeric(chi_c$statistic), p = chi_c$p.value, cramers_v = cv_c)
} else {
  list(chisq = NA_real_, p = NA_real_, cramers_v = NA_real_)
}

df_hcpc_metrics <- tibble::tibble(
  Comparison = c("HCPC_Clusters_vs_Diagnosis", "HubElectrode_Centrality_vs_Diagnosis"),
  N_Subjects = c(n_total, n_total),
  N_Clusters_or_Levels = c(nlevels(df_clusters_vs_real$Cluster_HCPC),
                           if ("centrality" %in% names(df_clusters_vs_real)) nlevels(droplevels(as.factor(df_clusters_vs_real$centrality))) else NA_integer_),
  Chi_Square = c(as.numeric(chi_test$statistic), centrality_stats$chisq),
  DF         = c(as.numeric(chi_test$parameter), NA_real_),
  P_Value    = c(chi_test$p.value, centrality_stats$p),
  Cramers_V  = c(cramers_v, centrality_stats$cramers_v),
  Adjusted_Rand_Index = c(ari_val, NA_real_)
)

print(df_hcpc_metrics)

write.csv(as.data.frame(cross_tab), file.path(OUT_DIR, "HCPC_Validation_Clusters_Vs_Diagnosis.csv"), row.names = FALSE)
write.csv(df_hcpc_metrics,          file.path(OUT_DIR, "HCPC_Chi2_CramersV_Metrics.csv"), row.names = FALSE)

# ------------------------------------------------------------------------------
# 4. COLORBLIND-SAFE PUBLICATION PLOTS
# ------------------------------------------------------------------------------
cat("\n--- Step 4: Exporting Colorblind-Safe Publication Plots ---\n")

p_scree <- factoextra::fviz_eig(
  res_pca,
  addlabels = TRUE,
  barfill   = "#0072B2",
  barcolor  = "#0072B2",
  linecolor = "#D55E00"
) +
  ggplot2::labs(
    title    = "PCA Scree Plot (ComBat-Harmonized Multi-Scale Features)",
    subtitle = sprintf("N = %d subjects | p = %d cross-cohort features", nrow(df_numeric), ncol(df_numeric)),
    x        = "Principal Components",
    y        = "% of Variance Explained"
  ) +
  ggplot2::theme_minimal(base_size = 12)
ggplot2::ggsave(file.path(OUT_DIR, "PCA_01_ScreePlot.pdf"), plot = p_scree, width = 7.5, height = 5)
ggplot2::ggsave(file.path(OUT_DIR, "PCA_01_ScreePlot.png"), plot = p_scree, width = 7.5, height = 5, dpi = 300)

p_var_biplot <- factoextra::fviz_pca_var(
  res_pca,
  col.var       = "contrib",
  gradient.cols = c("#440154", "#21908C", "#FDE725"),
  select.var    = list(contrib = min(25, ncol(df_numeric))),
  repel         = TRUE
) +
  ggplot2::labs(
    title    = "Top 25 Variable Loadings in Principal Component Space",
    subtitle = "Colored by contribution (%) using Viridis colorblind-safe scale",
    x        = sprintf("PC1 (%.1f%%)", res_pca$eig[1, 2]),
    y        = sprintf("PC2 (%.1f%%)", res_pca$eig[2, 2])
  ) +
  ggplot2::theme_minimal(base_size = 12)
ggplot2::ggsave(file.path(OUT_DIR, "PCA_02_Biplot_Variables.pdf"), plot = p_var_biplot, width = 9.5, height = 8)
ggplot2::ggsave(file.path(OUT_DIR, "PCA_02_Biplot_Variables.png"), plot = p_var_biplot, width = 9.5, height = 8, dpi = 300)

n_clust <- nlevels(df_clusters_vs_real$Cluster_HCPC)
clust_pal <- rep(OKABE_ITO, length.out = n_clust)

p_cluster_map <- factoextra::fviz_cluster(
  res_hcpc,
  geom         = "point",
  pointsize    = 0.9,
  alpha        = 0.65,
  palette      = clust_pal,
  ellipse.type = "convex",
  ggtheme      = ggplot2::theme_minimal(base_size = 12),
  main         = sprintf("Unsupervised HCPC Clusters (k = %d, Cramer's V = %.3f)", n_clust, cramers_v)
)
ggplot2::ggsave(file.path(OUT_DIR, "PCA_03_Cluster_Map_Individuals.pdf"), plot = p_cluster_map, width = 9.5, height = 7.5)
ggplot2::ggsave(file.path(OUT_DIR, "PCA_03_Cluster_Map_Individuals.png"), plot = p_cluster_map, width = 9.5, height = 7.5, dpi = 300)

# Individuals mapped by Clinical Diagnosis & Acquisition Site (post-ComBat mixing check)
ind_coords <- as.data.frame(res_pca$ind$coord[, 1:2]) %>%
  dplyr::bind_cols(clinical_labels)

p_diag_map <- ggplot2::ggplot(ind_coords, ggplot2::aes(x = Dim.1, y = Dim.2, color = diagnostic_group)) +
  ggplot2::geom_point(alpha = 0.45, size = 1.1) +
  ggplot2::stat_ellipse(level = 0.95, linewidth = 0.9) +
  ggplot2::scale_color_manual(values = DIAG_COLORS, name = "Clinical Group") +
  ggplot2::labs(
    title    = "Individual Distribution in Harmonized PCA Space by Clinical Diagnosis",
    x        = sprintf("PC1 (%.1f%%)", res_pca$eig[1, 2]),
    y        = sprintf("PC2 (%.1f%%)", res_pca$eig[2, 2])
  ) +
  ggplot2::theme_minimal(base_size = 12)
ggplot2::ggsave(file.path(OUT_DIR, "PCA_04_Individuals_by_Diagnosis.pdf"), plot = p_diag_map, width = 9, height = 7)

if ("Source" %in% names(ind_coords)) {
  p_site_map <- ggplot2::ggplot(ind_coords, ggplot2::aes(x = Dim.1, y = Dim.2, color = Source)) +
    ggplot2::geom_point(alpha = 0.40, size = 1.0) +
    ggplot2::stat_ellipse(level = 0.95, linewidth = 0.7) +
    ggplot2::scale_color_viridis_d(option = "viridis", name = "Acquisition Source") +
    ggplot2::labs(
      title    = "Multi-Repository Mixing Check in PCA Space (Post-ComBat)",
      x        = sprintf("PC1 (%.1f%%)", res_pca$eig[1, 2]),
      y        = sprintf("PC2 (%.1f%%)", res_pca$eig[2, 2])
    ) +
    ggplot2::theme_minimal(base_size = 12)
  ggplot2::ggsave(file.path(OUT_DIR, "PCA_05_Individuals_by_Source_PostComBat.pdf"), plot = p_site_map, width = 10, height = 7)
}

# ------------------------------------------------------------------------------
# 5. TEXT REPORT EXPORT
# ------------------------------------------------------------------------------
sink(file.path(OUT_DIR, "PCA_Clustering_Console_Report.txt"))
cat("==============================================================================\n")
cat("  UNSUPERVISED MULTIVARIATE REPORT: PCA + HCPC (POST-COMBAT)\n")
cat("==============================================================================\n")
cat("Timestamp          :", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")
cat("Subjects (N)       :", nrow(df_numeric), "\n")
cat("Numeric Features(p):", ncol(df_numeric), "\n")
cat("Excluded Cols      :", length(dropped_cols), "(missingness >", opts$max_missing_frac, ") + categorical `centrality`\n\n")
cat(">>> 1. EIGENVALUES & EXPLAINED VARIANCE <<<\n")
print(head(eig_df, 15))
cat("\n>>> 2. TOP 15 VARIABLE CONTRIBUTIONS (PC1 & PC2) <<<\n")
print(head(df_contributions[, seq_len(min(4L, ncol(df_contributions))), drop = FALSE], 15))
cat("\n>>> 3. HCPC CONTINGENCY TABLE VS. CLINICAL DIAGNOSIS <<<\n")
print(cross_tab)
cat("\n>>> 4. CHI-SQUARE, CRAMER'S V & ADJUSTED RAND INDEX <<<\n")
print(df_hcpc_metrics)
cat("==============================================================================\n")
sink()

cat("\n✔ 03_unsupervised_pca_hcpc.R completed successfully.\n")
