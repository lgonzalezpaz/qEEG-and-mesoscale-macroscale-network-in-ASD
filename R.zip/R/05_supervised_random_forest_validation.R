# ==============================================================================
# 05_supervised_random_forest_validation.R
# ==============================================================================
# Refactored from: Session005_MachineLearning.R
#
# Purpose:
#   Trains and rigorously evaluates multi-class Random Forest classifiers
#   (ASD vs. non_ASD vs. TD) with stratified 80/20 holdout, 10-fold repeated CV
#   (3 repeats) with within-fold down-sampling, out-of-fold & blind-test
#   multi-class ROC-AUC, PR-AUC, 95% Wilson/bootstrap CIs, and systematic
#   feature-ablation experiments.
#
# Key Refinements & Bug Fixes over Session005:
#   1. Portable CLI/env/relative path resolution & safe parallel cluster cleanup.
#   2. Fixes zero-leakage preprocessing: excludes categorical `centrality` and
#      metadata, coerces continuous graph metrics cleanly, and computes median
#      imputation parameters STRICTLY inside the 80% training split (applying
#      training medians to the blind 20% test set).
#   3. Fixes caret optimization metric bug: Session005 passed `metric = "Mac_F1"`
#      which does not exist in `caret::multiClassSummary` (forcing silent fallback
#      to `logLoss`); fixed to `metric = "Mean_F1"`.
#   4. Adds out-of-fold (OOF) and blind test-set multi-class ROC-AUC (`pROC`),
#      pairwise ASD-vs-non_ASD and ASD-vs-TD ROC-AUC (95% DeLong/bootstrap CIs),
#      Precision-Recall AUC (PR-AUC), and 95% Wilson score + bootstrap CIs.
#   5. Adds systematic 6-arm feature-ablation suite:
#      Full_Hybrid, Core_Hybrid_LeakageFree (cross-cohort core ROIs free of
#      site-specific montage missingness), Mesoscale_Only, Macroscale_Only,
#      Nonlinear_Only, and Spectral_Only.
# ==============================================================================

suppressPackageStartupMessages({
  library(tidyverse)
  library(caret)
  library(randomForest)
  library(MLmetrics)
  library(pROC)
  library(doParallel)
})

HAS_PRROC <- requireNamespace("PRROC", quietly = TRUE)

# ------------------------------------------------------------------------------
# 0. PORTABLE PATH RESOLUTION & CONFIGURATION
# ------------------------------------------------------------------------------
parse_cli_args <- function(args = commandArgs(trailingOnly = TRUE)) {
  opts <- list(
    input_dir  = Sys.getenv("ASD_EEG_DATA_DIR", unset = ""),
    output_dir = Sys.getenv("ASD_EEG_OUT_DIR", unset = ""),
    cv_folds   = 10L,
    cv_repeats = 3L,
    ntree      = 600L,
    n_boot     = 500L,
    seed       = 42L
  )
  for (arg in args) {
    if (grepl("^--input-dir=", arg))  opts$input_dir  <- sub("^--input-dir=", "", arg)
    if (grepl("^--output-dir=", arg)) opts$output_dir <- sub("^--output-dir=", "", arg)
    if (grepl("^--cv-folds=", arg))   opts$cv_folds   <- as.integer(sub("^--cv-folds=", "", arg))
    if (grepl("^--cv-repeats=", arg)) opts$cv_repeats <- as.integer(sub("^--cv-repeats=", "", arg))
    if (grepl("^--ntree=", arg))      opts$ntree      <- as.integer(sub("^--ntree=", "", arg))
    if (grepl("^--n-boot=", arg))     opts$n_boot     <- as.integer(sub("^--n-boot=", "", arg))
    if (grepl("^--seed=", arg))       opts$seed       <- as.integer(sub("^--seed=", "", arg))
  }
  opts
}

resolve_rds_path <- function(filename, user_dir = "", user_out = "") {
  candidates <- unique(c(
    if (nzchar(user_out)) file.path(user_out, filename) else "",
    if (nzchar(user_dir)) file.path(user_dir, filename) else "",
    file.path(getwd(), "outputs", filename),
    file.path(getwd(), filename),
    file.path(dirname(getwd()), "outputs", filename)
  ))
  candidates <- candidates[nzchar(candidates)]
  for (p in candidates) {
    if (file.exists(p)) return(normalizePath(p, winslash = "/", mustWork = FALSE))
  }
  stop("Missing required file '", filename, "'. Run 02_harmonization_and_roi_aggregation.R first.")
}

resolve_output_dir <- function(user_out = "") {
  if (nzchar(user_out)) {
    out_dir <- user_out
  } else {
    out_dir <- file.path(getwd(), "outputs")
    if (basename(getwd()) == "R") out_dir <- file.path(dirname(getwd()), "outputs")
  }
  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  normalizePath(out_dir, winslash = "/", mustWork = FALSE)
}

opts     <- parse_cli_args()
OUT_DIR  <- resolve_output_dir(opts$output_dir)
RDS_PATH <- resolve_rds_path("master_harmonized_roi.rds", opts$input_dir, OUT_DIR)

cat("==============================================================================\n")
cat("  05_supervised_random_forest_validation.R | Multi-Class RF & Ablations\n")
cat("==============================================================================\n")
cat("Input RDS        :", RDS_PATH, "\n")
cat("Output directory :", OUT_DIR, "\n")
cat("CV scheme        :", opts$cv_folds, "-fold x", opts$cv_repeats, "repeats | ntree =", opts$ntree, "\n\n")

# ------------------------------------------------------------------------------
# 1. METRIC HELPERS (WILSON CI, ROC-AUC, PR-AUC, STRATIFIED BOOTSTRAP)
# ------------------------------------------------------------------------------
wilson_ci <- function(k, n, z = 1.959964) {
  if (n <= 0) return(c(est = NA_real_, lower = NA_real_, upper = NA_real_))
  p <- k / n
  denom  <- 1 + z^2 / n
  center <- (p + z^2 / (2 * n)) / denom
  half   <- (z * sqrt((p * (1 - p) + z^2 / (4 * n)) / n)) / denom
  c(est = p, lower = max(0, center - half), upper = min(1, center + half))
}

compute_pr_auc <- function(y_bin, scores) {
  if (length(unique(y_bin)) < 2) return(NA_real_)
  if (HAS_PRROC) {
    return(PRROC::pr.curve(
      scores.class0 = scores[y_bin == 1],
      scores.class1 = scores[y_bin == 0],
      curve = FALSE
    )$auc.integral)
  }
  # Exact step-wise Precision-Recall AUC fallback in pure R
  ord <- order(scores, decreasing = TRUE)
  y_s <- y_bin[ord]
  tp  <- cumsum(y_s == 1)
  fp  <- cumsum(y_s == 0)
  prec <- tp / (tp + fp)
  rec  <- tp / sum(y_s == 1)
  rec_prev  <- c(0, rec[-length(rec)])
  sum((rec - rec_prev) * prec)
}

compute_multiclass_aucs <- function(y_true, prob_df) {
  y_true <- droplevels(as.factor(y_true))
  cls    <- levels(y_true)
  prob_df <- prob_df[, cls, drop = FALSE]

  # Hand & Till multiclass AUC
  mc_auc <- tryCatch(
    as.numeric(pROC::multiclass.roc(response = y_true, predictor = as.matrix(prob_df), quiet = TRUE)$auc),
    error = function(e) NA_real_
  )

  # One-vs-Rest ROC-AUC (with DeLong 95% CI) and PR-AUC per class
  ovr_roc <- numeric(length(cls))
  ovr_roc_lo <- numeric(length(cls))
  ovr_roc_hi <- numeric(length(cls))
  ovr_pr  <- numeric(length(cls))
  names(ovr_roc) <- names(ovr_roc_lo) <- names(ovr_roc_hi) <- names(ovr_pr) <- cls

  for (c_nm in cls) {
    y_bin <- as.integer(y_true == c_nm)
    sc    <- prob_df[[c_nm]]
    roc_obj <- tryCatch(
      pROC::roc(response = y_bin, predictor = sc, direction = "<", quiet = TRUE),
      error = function(e) NULL
    )
    if (!is.null(roc_obj)) {
      ci_obj <- tryCatch(as.numeric(pROC::ci.auc(roc_obj, method = "delong", quiet = TRUE)),
                         error = function(e) c(NA_real_, as.numeric(pROC::auc(roc_obj)), NA_real_))
      ovr_roc[c_nm]    <- ci_obj[2]
      ovr_roc_lo[c_nm] <- ci_obj[1]
      ovr_roc_hi[c_nm] <- ci_obj[3]
    } else {
      ovr_roc[c_nm] <- ovr_roc_lo[c_nm] <- ovr_roc_hi[c_nm] <- NA_real_
    }
    ovr_pr[c_nm] <- compute_pr_auc(y_bin, sc)
  }

  # Pairwise clinical specificity AUCs: ASD vs non_ASD and ASD vs TD
  pairwise_auc <- function(pos_cls, neg_cls) {
    sub_idx <- which(y_true %in% c(pos_cls, neg_cls))
    if (length(sub_idx) < 10) return(c(auc = NA_real_, lo = NA_real_, hi = NA_real_))
    y_sub <- factor(y_true[sub_idx] == pos_cls, levels = c(FALSE, TRUE))
    sc_sub <- prob_df[sub_idx, pos_cls] / pmax(prob_df[sub_idx, pos_cls] + prob_df[sub_idx, neg_cls], 1e-12)
    r_obj <- tryCatch(pROC::roc(y_sub, sc_sub, direction = "<", quiet = TRUE), error = function(e) NULL)
    if (is.null(r_obj)) return(c(auc = NA_real_, lo = NA_real_, hi = NA_real_))
    ci_o <- tryCatch(as.numeric(pROC::ci.auc(r_obj, method = "delong", quiet = TRUE)),
                     error = function(e) c(NA_real_, as.numeric(pROC::auc(r_obj)), NA_real_))
    c(auc = ci_o[2], lo = ci_o[1], hi = ci_o[3])
  }

  asd_vs_non <- pairwise_auc("ASD", "non_ASD")
  asd_vs_td  <- pairwise_auc("ASD", "TD")

  list(
    hand_till_auc  = mc_auc,
    macro_ovr_roc  = mean(ovr_roc, na.rm = TRUE),
    macro_ovr_pr   = mean(ovr_pr, na.rm = TRUE),
    ovr_roc        = ovr_roc,
    ovr_roc_lo     = ovr_roc_lo,
    ovr_roc_hi     = ovr_roc_hi,
    ovr_pr         = ovr_pr,
    asd_vs_non_asd = asd_vs_non,
    asd_vs_td      = asd_vs_td
  )
}

bootstrap_eval_cis <- function(y_true, y_pred, prob_df, n_boot = 500L, seed = 42L) {
  set.seed(seed)
  y_true <- droplevels(as.factor(y_true))
  cls    <- levels(y_true)
  idx_by_cls <- lapply(cls, function(c_nm) which(y_true == c_nm))

  boot_mat <- matrix(NA_real_, nrow = n_boot, ncol = 4L)
  colnames(boot_mat) <- c("Accuracy", "Macro_F1", "Macro_OVR_ROC", "Macro_OVR_PR")

  for (b in seq_len(n_boot)) {
    b_idx <- unlist(lapply(idx_by_cls, function(ix) sample(ix, size = length(ix), replace = TRUE)), use.names = FALSE)
    yb    <- y_true[b_idx]
    pb    <- factor(y_pred[b_idx], levels = cls)
    prb   <- prob_df[b_idx, , drop = FALSE]

    acc <- mean(pb == yb)
    f1s <- vapply(cls, function(c_nm) {
      tp <- sum(pb == c_nm & yb == c_nm)
      fp <- sum(pb == c_nm & yb != c_nm)
      fn <- sum(pb != c_nm & yb == c_nm)
      if ((2 * tp + fp + fn) == 0) 0 else (2 * tp) / (2 * tp + fp + fn)
    }, numeric(1))

    rocs <- vapply(cls, function(c_nm) {
      tryCatch(as.numeric(pROC::auc(pROC::roc(as.integer(yb == c_nm), prb[[c_nm]], direction = "<", quiet = TRUE))),
               error = function(e) NA_real_)
    }, numeric(1))
    prs <- vapply(cls, function(c_nm) {
      compute_pr_auc(as.integer(yb == c_nm), prb[[c_nm]])
    }, numeric(1))

    boot_mat[b, ] <- c(acc, mean(f1s), mean(rocs, na.rm = TRUE), mean(prs, na.rm = TRUE))
  }

  apply(boot_mat, 2, stats::quantile, probs = c(0.025, 0.975), na.rm = TRUE)
}

# ------------------------------------------------------------------------------
# 2. LOAD HARMONIZED DATA & DEFINE LEAKAGE-FREE TRAIN/TEST SPLIT
# ------------------------------------------------------------------------------
df_raw <- readRDS(RDS_PATH)

meta_exclude <- intersect(
  c("record_id", "cohort", "Source", "Subject_ID", "Pathology", "subpathology", "centrality"),
  names(df_raw)
)
graf_num_cols <- intersect(c("mean_degree", "efficiency", "path_length", "modularity", "clustering"), names(df_raw))

df_ml_base <- df_raw %>%
  dplyr::mutate(
    diagnostic_group = stringr::str_replace(as.character(diagnostic_group), "non-ASD", "non_ASD"),
    diagnostic_group = factor(diagnostic_group, levels = c("ASD", "non_ASD", "TD")),
    dplyr::across(dplyr::all_of(graf_num_cols), ~ suppressWarnings(as.numeric(as.character(.))))
  ) %>%
  dplyr::select(-dplyr::any_of(meta_exclude))

all_predictor_cols <- setdiff(names(df_ml_base), "diagnostic_group")
stopifnot(all(vapply(df_ml_base[, all_predictor_cols, drop = FALSE], is.numeric, logical(1))))

# Stratified 80/20 Train/Test split BEFORE any imputation
set.seed(opts$seed)
train_idx <- caret::createDataPartition(df_ml_base$diagnostic_group, p = 0.80, list = FALSE)[, 1]
df_train_unimp <- df_ml_base[train_idx, , drop = FALSE]
df_test_unimp  <- df_ml_base[-train_idx, , drop = FALSE]

# Train-only median imputation (zero train->test leakage!)
train_medians <- vapply(df_train_unimp[, all_predictor_cols, drop = FALSE], function(x) {
  m <- stats::median(x[is.finite(x)], na.rm = TRUE)
  if (!is.finite(m)) 0 else m
}, numeric(1))

impute_with_train_medians <- function(df, cols, meds) {
  out <- df
  for (cn in cols) {
    v <- out[[cn]]
    bad <- is.na(v) | !is.finite(v)
    if (any(bad)) v[bad] <- meds[[cn]]
    out[[cn]] <- v
  }
  out
}

df_train_all <- impute_with_train_medians(df_train_unimp, all_predictor_cols, train_medians)
df_test_all  <- impute_with_train_medians(df_test_unimp,  all_predictor_cols, train_medians)

cat("Training set (80%):", nrow(df_train_all), "| Test set (20%):", nrow(df_test_all), "\n")
print(table(df_train_all$diagnostic_group))
print(table(df_test_all$diagnostic_group))

# ------------------------------------------------------------------------------
# 3. DEFINE SYSTEMATIC 6-ARM FEATURE-ABLATION SUITE
# ------------------------------------------------------------------------------
roi_all_cols       <- grep("_roi$", all_predictor_cols, value = TRUE)
macro_cols         <- intersect(graf_num_cols, all_predictor_cols)
nonlinear_cols     <- grep("_(hurst|shannon)_roi$", all_predictor_cols, value = TRUE)
spectral_cols      <- grep("_(theta|sigma|ratio\\.at|node_weight)_roi$", all_predictor_cols, value = TRUE)
core_roi_prefixes  <- c("ACC", "OFC", "PPC", "STS", "PN")
core_roi_pattern   <- paste0("^(", paste(core_roi_prefixes, collapse = "|"), ").*_roi$")
core_meso_cols     <- grep(core_roi_pattern, all_predictor_cols, value = TRUE)

ablation_arms <- list(
  "Full_Hybrid"             = c(roi_all_cols, macro_cols),
  "Core_Hybrid_LeakageFree" = c(core_meso_cols, macro_cols),
  "Mesoscale_Only"          = roi_all_cols,
  "Macroscale_Only"         = macro_cols,
  "Nonlinear_Only"          = nonlinear_cols,
  "Spectral_Only"           = spectral_cols
)

cat("\n>>> Ablation Feature Set Sizes:\n")
for (arm in names(ablation_arms)) {
  cat(sprintf("  %-25s: %d predictors\n", arm, length(ablation_arms[[arm]])))
}

# ------------------------------------------------------------------------------
# 4. TRAIN & EVALUATE EACH ABLATION ARM (OOF CV + BLIND 20% TEST)
# ------------------------------------------------------------------------------
fit_control <- caret::trainControl(
  method          = "repeatedcv",
  number          = opts$cv_folds,
  repeats         = opts$cv_repeats,
  summaryFunction = caret::multiClassSummary,
  classProbs      = TRUE,
  sampling        = "down",
  savePredictions = "final",
  allowParallel   = TRUE,
  verboseIter     = FALSE
)

n_cores <- max(1L, min(parallel::detectCores(logical = TRUE) - 1L, 8L))
cl <- parallel::makePSOCKcluster(n_cores)
doParallel::registerDoParallel(cl)
on.exit({
  try(parallel::stopCluster(cl), silent = TRUE)
  if (requireNamespace("foreach", quietly = TRUE)) foreach::registerDoSEQ()
}, add = TRUE)

cat(sprintf("\nParallel cluster active with %d worker(s).\n", n_cores))

run_ablation_arm <- function(arm_name, feat_cols) {
  cat(sprintf("\n--- Training Ablation Arm: %s (p = %d) ---\n", arm_name, length(feat_cols)))
  x_tr <- as.data.frame(df_train_all[, feat_cols, drop = FALSE])
  y_tr <- df_train_all$diagnostic_group
  x_te <- as.data.frame(df_test_all[, feat_cols, drop = FALSE])
  y_te <- df_test_all$diagnostic_group

  mtry_vals <- sort(unique(pmax(1L, pmin(c(2L, 5L, 10L, 15L, 20L, 25L), length(feat_cols)))))
  tune_grid <- expand.grid(.mtry = mtry_vals)

  set.seed(opts$seed)
  rf_mod <- caret::train(
    x          = x_tr,
    y          = y_tr,
    method     = "rf",
    metric     = "Mean_F1", # Fixes Session005 bug ("Mac_F1" fell back to logLoss)
    trControl  = fit_control,
    tuneGrid   = tune_grid,
    ntree      = opts$ntree,
    importance = TRUE
  )

  # A) Out-of-Fold (OOF) aggregated predictions across repeats for bestTune
  cls_levels <- levels(y_tr)
  oof_raw <- rf_mod$pred
  if ("mtry" %in% names(oof_raw)) {
    oof_raw <- oof_raw[oof_raw$mtry == rf_mod$bestTune$mtry, , drop = FALSE]
  }
  oof_agg <- oof_raw %>%
    dplyr::group_by(rowIndex, obs) %>%
    dplyr::summarise(
      dplyr::across(dplyr::all_of(cls_levels), ~ mean(., na.rm = TRUE)),
      .groups = "drop"
    ) %>%
    dplyr::arrange(rowIndex)

  oof_pred_cls <- factor(cls_levels[max.col(as.matrix(oof_agg[, cls_levels]), ties.method = "first")],
                         levels = cls_levels)
  oof_cm   <- caret::confusionMatrix(oof_pred_cls, oof_agg$obs)
  oof_aucs <- compute_multiclass_aucs(oof_agg$obs, oof_agg[, cls_levels, drop = FALSE])

  # B) Blind Test-Set predictions + Wilson & Bootstrap CIs
  te_prob     <- stats::predict(rf_mod, newdata = x_te, type = "prob")[, cls_levels, drop = FALSE]
  te_pred_cls <- factor(cls_levels[max.col(as.matrix(te_prob), ties.method = "first")],
                        levels = cls_levels)
  te_cm       <- caret::confusionMatrix(te_pred_cls, y_te)
  te_aucs     <- compute_multiclass_aucs(y_te, te_prob)
  te_boot_ci  <- bootstrap_eval_cis(y_te, te_pred_cls, te_prob,
                                    n_boot = opts$n_boot, seed = opts$seed)

  acc_wilson <- wilson_ci(sum(te_pred_cls == y_te), length(y_te))
  macro_f1_te <- mean(te_cm$byClass[, "F1"], na.rm = TRUE)
  macro_f1_oof <- mean(oof_cm$byClass[, "F1"], na.rm = TRUE)

  summary_row <- tibble::tibble(
    Arm                      = arm_name,
    N_Predictors             = length(feat_cols),
    Best_mtry                = rf_mod$bestTune$mtry,
    OOF_Accuracy             = as.numeric(oof_cm$overall["Accuracy"]),
    OOF_Macro_F1             = macro_f1_oof,
    OOF_HandTill_ROC_AUC     = oof_aucs$hand_till_auc,
    OOF_Macro_OVR_ROC_AUC    = oof_aucs$macro_ovr_roc,
    OOF_Macro_PR_AUC         = oof_aucs$macro_ovr_pr,
    Test_Accuracy            = as.numeric(te_cm$overall["Accuracy"]),
    Test_Acc_Wilson_Lo       = acc_wilson["lower"],
    Test_Acc_Wilson_Hi       = acc_wilson["upper"],
    Test_Kappa               = as.numeric(te_cm$overall["Kappa"]),
    Test_Macro_F1            = macro_f1_te,
    Test_Macro_F1_Boot_Lo    = te_boot_ci["2.5%", "Macro_F1"],
    Test_Macro_F1_Boot_Hi    = te_boot_ci["97.5%", "Macro_F1"],
    Test_HandTill_ROC_AUC    = te_aucs$hand_till_auc,
    Test_Macro_OVR_ROC_AUC   = te_aucs$macro_ovr_roc,
    Test_ROC_Boot_Lo         = te_boot_ci["2.5%", "Macro_OVR_ROC"],
    Test_ROC_Boot_Hi         = te_boot_ci["97.5%", "Macro_OVR_ROC"],
    Test_Macro_PR_AUC        = te_aucs$macro_ovr_pr,
    Test_PR_Boot_Lo          = te_boot_ci["2.5%", "Macro_OVR_PR"],
    Test_PR_Boot_Hi          = te_boot_ci["97.5%", "Macro_OVR_PR"],
    Test_AUC_ASD_vs_nonASD   = te_aucs$asd_vs_non_asd["auc"],
    Test_AUC_ASD_vs_nonASD_Lo= te_aucs$asd_vs_non_asd["lo"],
    Test_AUC_ASD_vs_nonASD_Hi= te_aucs$asd_vs_non_asd["hi"],
    Test_AUC_ASD_vs_TD       = te_aucs$asd_vs_td["auc"],
    Test_AUC_ASD_vs_TD_Lo    = te_aucs$asd_vs_td["lo"],
    Test_AUC_ASD_vs_TD_Hi    = te_aucs$asd_vs_td["hi"]
  )

  list(
    arm         = arm_name,
    model       = rf_mod,
    summary     = summary_row,
    test_cm     = te_cm,
    test_aucs   = te_aucs,
    test_prob   = te_prob,
    test_obs    = y_te,
    oof_cm      = oof_cm,
    oof_aucs    = oof_aucs
  )
}

ablation_results <- lapply(names(ablation_arms), function(nm) {
  run_ablation_arm(nm, ablation_arms[[nm]])
})
names(ablation_results) <- names(ablation_arms)

# Explicitly tear down parallel workers cleanly
try(parallel::stopCluster(cl), silent = TRUE)
if (requireNamespace("foreach", quietly = TRUE)) foreach::registerDoSEQ()

df_ablation_table <- dplyr::bind_rows(lapply(ablation_results, `[[`, "summary"))
cat("\n=== SYSTEMATIC ABLATION COMPARISON TABLE (OOF & BLIND 20% TEST) ===\n")
print(df_ablation_table %>% dplyr::mutate(dplyr::across(where(is.numeric), ~ round(., 4))))
write.csv(df_ablation_table, file.path(OUT_DIR, "Ablation_Comparison_Metrics.csv"), row.names = FALSE)

# ------------------------------------------------------------------------------
# 5. EXPORT PRIMARY FULL_HYBRID & LEAKAGE-FREE MODELS, TABLES, AND PLOTS
# ------------------------------------------------------------------------------
primary_res <- ablation_results[["Full_Hybrid"]]
core_res    <- ablation_results[["Core_Hybrid_LeakageFree"]]

saveRDS(
  list(
    full_hybrid = primary_res$model,
    core_hybrid = core_res$model,
    ablation_summary = df_ablation_table,
    train_medians = train_medians
  ),
  file = file.path(OUT_DIR, "multiclass_rf_model_final.rds")
)

# Per-class metrics with Wilson 95% CIs on blind test set for Full_Hybrid
add_class_wilson <- function(cm_obj, aucs_obj, arm_label) {
  tab <- cm_obj$table
  cls <- colnames(tab)
  purrr::map_dfr(cls, function(c_nm) {
    tp <- tab[c_nm, c_nm]
    fn <- sum(tab[, c_nm]) - tp
    fp <- sum(tab[c_nm, ]) - tp
    tn <- sum(tab) - tp - fn - fp
    sens_ci <- wilson_ci(tp, tp + fn)
    spec_ci <- wilson_ci(tn, tn + fp)
    ppv_ci  <- wilson_ci(tp, tp + fp)
    f1_val  <- cm_obj$byClass[paste0("Class: ", c_nm), "F1"]
    tibble::tibble(
      Arm = arm_label,
      Class = c_nm,
      Sensitivity = sens_ci["est"], Sens_95CI_Lo = sens_ci["lower"], Sens_95CI_Hi = sens_ci["upper"],
      Specificity = spec_ci["est"], Spec_95CI_Lo = spec_ci["lower"], Spec_95CI_Hi = spec_ci["upper"],
      Precision   = ppv_ci["est"],  Prec_95CI_Lo = ppv_ci["lower"],  Prec_95CI_Hi = ppv_ci["upper"],
      F1          = as.numeric(f1_val),
      OVR_ROC_AUC = aucs_obj$ovr_roc[c_nm],
      OVR_ROC_Lo  = aucs_obj$ovr_roc_lo[c_nm],
      OVR_ROC_Hi  = aucs_obj$ovr_roc_hi[c_nm],
      OVR_PR_AUC  = aucs_obj$ovr_pr[c_nm]
    )
  })
}

df_class_metrics <- dplyr::bind_rows(
  add_class_wilson(primary_res$test_cm, primary_res$test_aucs, "Full_Hybrid"),
  add_class_wilson(core_res$test_cm,    core_res$test_aucs,    "Core_Hybrid_LeakageFree")
)
write.csv(df_class_metrics, file.path(OUT_DIR, "Class_Diagnostic_Metrics.csv"), row.names = FALSE)
write.csv(as.data.frame(primary_res$test_cm$table), file.path(OUT_DIR, "Confusion_Matrix_Counts.csv"), row.names = FALSE)

# Top-15 Biomarker Importance Plot (Colorblind-safe Okabe-Ito by Biophysical Domain)
imp_mat <- randomForest::importance(core_res$model$finalModel)
df_imp <- as.data.frame(imp_mat) %>%
  tibble::rownames_to_column("Predictor") %>%
  dplyr::mutate(
    Predictor_Clean = gsub("`", "", Predictor),
    Domain = dplyr::case_when(
      grepl("_(hurst|shannon)_roi$", Predictor_Clean)                    ~ "Nonlinear (Hurst / Shannon)",
      grepl("_(theta|sigma|ratio\\.at|node_weight)_roi$", Predictor_Clean) ~ "Spectral / Connectivity",
      TRUE                                                               ~ "Macroscale Graph"
    )
  ) %>%
  dplyr::arrange(dplyr::desc(MeanDecreaseAccuracy))

write.csv(df_imp, file.path(OUT_DIR, "Biomarker_Importance_Table.csv"), row.names = FALSE)

df_imp_top15 <- head(df_imp, 15)
p_imp <- ggplot2::ggplot(
  df_imp_top15,
  ggplot2::aes(x = stats::reorder(Predictor_Clean, MeanDecreaseAccuracy),
               y = MeanDecreaseAccuracy, fill = Domain)
) +
  ggplot2::geom_col(width = 0.72) +
  ggplot2::geom_text(ggplot2::aes(label = round(MeanDecreaseAccuracy, 2)), hjust = -0.15, size = 3.2) +
  ggplot2::coord_flip(clip = "off") +
  ggplot2::scale_y_continuous(expand = ggplot2::expansion(mult = c(0, 0.16))) +
  ggplot2::scale_fill_manual(values = c(
    "Nonlinear (Hurst / Shannon)" = "#D55E00",
    "Spectral / Connectivity"     = "#0072B2",
    "Macroscale Graph"            = "#009E73"
  )) +
  ggplot2::labs(
    title    = "Top 15 Multiscale Biomarkers (Leakage-Free Core Hybrid RF)",
    subtitle = "Ranked by Mean Decrease Accuracy across 10-fold repeated CV",
    x        = NULL,
    y        = "Mean Decrease Accuracy",
    fill     = "Feature Domain"
  ) +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(
    plot.title         = ggplot2::element_text(face = "bold"),
    axis.text.y        = ggplot2::element_text(face = "bold", size = 9),
    panel.grid.major.y = ggplot2::element_blank(),
    legend.position    = "bottom",
    plot.margin        = ggplot2::margin(t = 12, r = 36, b = 12, l = 12)
  )
ggplot2::ggsave(file.path(OUT_DIR, "Biomarker_Importance_Plot.pdf"), plot = p_imp, width = 11, height = 7)

# Pairwise ASD vs non_ASD ROC Curves across all Ablation Arms
roc_curve_df <- purrr::map_dfr(names(ablation_results), function(arm_nm) {
  res <- ablation_results[[arm_nm]]
  idx <- which(res$test_obs %in% c("ASD", "non_ASD"))
  y_b <- factor(res$test_obs[idx] == "ASD", levels = c(FALSE, TRUE))
  sc  <- res$test_prob[idx, "ASD"] / pmax(res$test_prob[idx, "ASD"] + res$test_prob[idx, "non_ASD"], 1e-12)
  r_o <- pROC::roc(y_b, sc, direction = "<", quiet = TRUE)
  tibble::tibble(
    Arm         = sprintf("%s (AUC=%.3f)", arm_nm, as.numeric(pROC::auc(r_o))),
    Specificity = r_o$specificities,
    Sensitivity = r_o$sensitivities,
    FPR         = 1 - r_o$specificities
  )
})

p_roc <- ggplot2::ggplot(roc_curve_df, ggplot2::aes(x = FPR, y = Sensitivity, color = Arm)) +
  ggplot2::geom_line(linewidth = 1.0) +
  ggplot2::geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "grey55") +
  ggplot2::scale_color_manual(values = c("#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9")) +
  ggplot2::labs(
    title    = "Blind Test-Set ROC Curves: ASD vs. non-ASD Specificity Across Feature Ablations",
    x        = "False Positive Rate (1 - Specificity)",
    y        = "True Positive Rate (Sensitivity)",
    color    = "Ablation Model"
  ) +
  ggplot2::theme_minimal(base_size = 11) +
  ggplot2::theme(legend.position = "right")
ggplot2::ggsave(file.path(OUT_DIR, "ROC_Curves_Multiclass_Ablation.pdf"), plot = p_roc, width = 10, height = 6.5)

# Text Executive Summary
sink(file.path(OUT_DIR, "RandomForest_Console_Report.txt"))
cat("==============================================================================\n")
cat("  SUPERVISED RANDOM FOREST VALIDATION & FEATURE-ABLATION REPORT\n")
cat("==============================================================================\n")
cat("Timestamp :", format(Sys.time(), "%Y-%m-%d %H:%M:%S"), "\n")
cat("CV Scheme :", opts$cv_folds, "-fold repeated x", opts$cv_repeats, "| Down-sampling | Metric: Mean_F1\n")
cat("Split     : Stratified 80% Train (n=", nrow(df_train_all), ") / 20% Blind Test (n=", nrow(df_test_all), ")\n\n")
cat(">>> 1. ABLATION COMPARISON (OOF & BLIND TEST WITH 95% CIs) <<<\n")
print(df_ablation_table %>% dplyr::mutate(dplyr::across(where(is.numeric), ~ round(., 4))))
cat("\n>>> 2. PER-CLASS BLIND TEST METRICS (WILSON & DELONG 95% CIs) <<<\n")
print(df_class_metrics %>% dplyr::mutate(dplyr::across(where(is.numeric), ~ round(., 4))))
cat("\n>>> 3. FULL HYBRID CONFUSION MATRIX (BLIND TEST) <<<\n")
print(primary_res$test_cm)
cat("\n>>> 4. CORE LEAKAGE-FREE CONFUSION MATRIX (BLIND TEST) <<<\n")
print(core_res$test_cm)
cat("==============================================================================\n")
sink()

cat("\n✔ 05_supervised_random_forest_validation.R completed successfully.\n")
